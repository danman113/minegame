/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 370);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var core = __webpack_require__(21);
var hide = __webpack_require__(12);
var redefine = __webpack_require__(13);
var ctx = __webpack_require__(18);
var PROTOTYPE = 'prototype';

var $export = function (type, name, source) {
  var IS_FORCED = type & $export.F;
  var IS_GLOBAL = type & $export.G;
  var IS_STATIC = type & $export.S;
  var IS_PROTO = type & $export.P;
  var IS_BIND = type & $export.B;
  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE];
  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
  var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
  var key, own, out, exp;
  if (IS_GLOBAL) source = name;
  for (key in source) {
    // contains in native
    own = !IS_FORCED && target && target[key] !== undefined;
    // export native or passed
    out = (own ? target : source)[key];
    // bind timers to global for call from export context
    exp = IS_BIND && own ? ctx(out, global) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
    // extend global
    if (target) redefine(target, key, out, type & $export.U);
    // export
    if (exports[key] != out) hide(exports, key, exp);
    if (IS_PROTO && expProto[key] != out) expProto[key] = out;
  }
};
global.core = core;
// type bitmap
$export.F = 1;   // forced
$export.G = 2;   // global
$export.S = 4;   // static
$export.P = 8;   // proto
$export.B = 16;  // bind
$export.W = 32;  // wrap
$export.U = 64;  // safe
$export.R = 128; // real proto method for `library`
module.exports = $export;


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
module.exports = function (it) {
  if (!isObject(it)) throw TypeError(it + ' is not an object!');
  return it;
};


/***/ }),
/* 2 */
/***/ (function(module, exports) {

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global = module.exports = typeof window != 'undefined' && window.Math == Math
  ? window : typeof self != 'undefined' && self.Math == Math ? self
  // eslint-disable-next-line no-new-func
  : Function('return this')();
if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (e) {
    return true;
  }
};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

var store = __webpack_require__(50)('wks');
var uid = __webpack_require__(32);
var Symbol = __webpack_require__(2).Symbol;
var USE_SYMBOL = typeof Symbol == 'function';

var $exports = module.exports = function (name) {
  return store[name] || (store[name] =
    USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
};

$exports.store = store;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

// Thank's IE8 for his funny defineProperty
module.exports = !__webpack_require__(3)(function () {
  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(1);
var IE8_DOM_DEFINE = __webpack_require__(93);
var toPrimitive = __webpack_require__(22);
var dP = Object.defineProperty;

exports.f = __webpack_require__(6) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return dP(O, P, Attributes);
  } catch (e) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.15 ToLength
var toInteger = __webpack_require__(24);
var min = Math.min;
module.exports = function (it) {
  return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.13 ToObject(argument)
var defined = __webpack_require__(23);
module.exports = function (it) {
  return Object(defined(it));
};


/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = function (it) {
  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
  return it;
};


/***/ }),
/* 11 */
/***/ (function(module, exports) {

var hasOwnProperty = {}.hasOwnProperty;
module.exports = function (it, key) {
  return hasOwnProperty.call(it, key);
};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(7);
var createDesc = __webpack_require__(31);
module.exports = __webpack_require__(6) ? function (object, key, value) {
  return dP.f(object, key, createDesc(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var hide = __webpack_require__(12);
var has = __webpack_require__(11);
var SRC = __webpack_require__(32)('src');
var TO_STRING = 'toString';
var $toString = Function[TO_STRING];
var TPL = ('' + $toString).split(TO_STRING);

__webpack_require__(21).inspectSource = function (it) {
  return $toString.call(it);
};

(module.exports = function (O, key, val, safe) {
  var isFunction = typeof val == 'function';
  if (isFunction) has(val, 'name') || hide(val, 'name', key);
  if (O[key] === val) return;
  if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
  if (O === global) {
    O[key] = val;
  } else if (!safe) {
    delete O[key];
    hide(O, key, val);
  } else if (O[key]) {
    O[key] = val;
  } else {
    hide(O, key, val);
  }
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, TO_STRING, function toString() {
  return typeof this == 'function' && this[SRC] || $toString.call(this);
});


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var fails = __webpack_require__(3);
var defined = __webpack_require__(23);
var quot = /"/g;
// B.2.3.2.1 CreateHTML(string, tag, attribute, value)
var createHTML = function (string, tag, attribute, value) {
  var S = String(defined(string));
  var p1 = '<' + tag;
  if (attribute !== '') p1 += ' ' + attribute + '="' + String(value).replace(quot, '&quot;') + '"';
  return p1 + '>' + S + '</' + tag + '>';
};
module.exports = function (NAME, exec) {
  var O = {};
  O[NAME] = exec(createHTML);
  $export($export.P + $export.F * fails(function () {
    var test = ''[NAME]('"');
    return test !== test.toLowerCase() || test.split('"').length > 3;
  }), 'String', O);
};


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

// to indexed object, toObject with fallback for non-array-like ES3 strings
var IObject = __webpack_require__(47);
var defined = __webpack_require__(23);
module.exports = function (it) {
  return IObject(defined(it));
};


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

var pIE = __webpack_require__(48);
var createDesc = __webpack_require__(31);
var toIObject = __webpack_require__(15);
var toPrimitive = __webpack_require__(22);
var has = __webpack_require__(11);
var IE8_DOM_DEFINE = __webpack_require__(93);
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = __webpack_require__(6) ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
var has = __webpack_require__(11);
var toObject = __webpack_require__(9);
var IE_PROTO = __webpack_require__(67)('IE_PROTO');
var ObjectProto = Object.prototype;

module.exports = Object.getPrototypeOf || function (O) {
  O = toObject(O);
  if (has(O, IE_PROTO)) return O[IE_PROTO];
  if (typeof O.constructor == 'function' && O instanceof O.constructor) {
    return O.constructor.prototype;
  } return O instanceof Object ? ObjectProto : null;
};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

// optional / simple context binding
var aFunction = __webpack_require__(10);
module.exports = function (fn, that, length) {
  aFunction(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};


/***/ }),
/* 19 */
/***/ (function(module, exports) {

var toString = {}.toString;

module.exports = function (it) {
  return toString.call(it).slice(8, -1);
};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var fails = __webpack_require__(3);

module.exports = function (method, arg) {
  return !!method && fails(function () {
    // eslint-disable-next-line no-useless-call
    arg ? method.call(null, function () { /* empty */ }, 1) : method.call(null);
  });
};


/***/ }),
/* 21 */
/***/ (function(module, exports) {

var core = module.exports = { version: '2.5.3' };
if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

// 7.1.1 ToPrimitive(input [, PreferredType])
var isObject = __webpack_require__(4);
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
module.exports = function (it, S) {
  if (!isObject(it)) return it;
  var fn, val;
  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
  throw TypeError("Can't convert object to primitive value");
};


/***/ }),
/* 23 */
/***/ (function(module, exports) {

// 7.2.1 RequireObjectCoercible(argument)
module.exports = function (it) {
  if (it == undefined) throw TypeError("Can't call method on  " + it);
  return it;
};


/***/ }),
/* 24 */
/***/ (function(module, exports) {

// 7.1.4 ToInteger
var ceil = Math.ceil;
var floor = Math.floor;
module.exports = function (it) {
  return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
};


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(0);
var core = __webpack_require__(21);
var fails = __webpack_require__(3);
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

// 0 -> Array#forEach
// 1 -> Array#map
// 2 -> Array#filter
// 3 -> Array#some
// 4 -> Array#every
// 5 -> Array#find
// 6 -> Array#findIndex
var ctx = __webpack_require__(18);
var IObject = __webpack_require__(47);
var toObject = __webpack_require__(9);
var toLength = __webpack_require__(8);
var asc = __webpack_require__(84);
module.exports = function (TYPE, $create) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  var create = $create || asc;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IObject(O);
    var f = ctx(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var result = IS_MAP ? create($this, length) : IS_FILTER ? create($this, 0) : undefined;
    var val, res;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      val = self[index];
      res = f(val, index, O);
      if (TYPE) {
        if (IS_MAP) result[index] = res;   // map
        else if (res) switch (TYPE) {
          case 3: return true;             // some
          case 5: return val;              // find
          case 6: return index;            // findIndex
          case 2: result.push(val);        // filter
        } else if (IS_EVERY) return false; // every
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : result;
  };
};


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

if (__webpack_require__(6)) {
  var LIBRARY = __webpack_require__(33);
  var global = __webpack_require__(2);
  var fails = __webpack_require__(3);
  var $export = __webpack_require__(0);
  var $typed = __webpack_require__(60);
  var $buffer = __webpack_require__(90);
  var ctx = __webpack_require__(18);
  var anInstance = __webpack_require__(39);
  var propertyDesc = __webpack_require__(31);
  var hide = __webpack_require__(12);
  var redefineAll = __webpack_require__(41);
  var toInteger = __webpack_require__(24);
  var toLength = __webpack_require__(8);
  var toIndex = __webpack_require__(119);
  var toAbsoluteIndex = __webpack_require__(35);
  var toPrimitive = __webpack_require__(22);
  var has = __webpack_require__(11);
  var classof = __webpack_require__(49);
  var isObject = __webpack_require__(4);
  var toObject = __webpack_require__(9);
  var isArrayIter = __webpack_require__(81);
  var create = __webpack_require__(36);
  var getPrototypeOf = __webpack_require__(17);
  var gOPN = __webpack_require__(37).f;
  var getIterFn = __webpack_require__(83);
  var uid = __webpack_require__(32);
  var wks = __webpack_require__(5);
  var createArrayMethod = __webpack_require__(26);
  var createArrayIncludes = __webpack_require__(51);
  var speciesConstructor = __webpack_require__(58);
  var ArrayIterators = __webpack_require__(86);
  var Iterators = __webpack_require__(44);
  var $iterDetect = __webpack_require__(55);
  var setSpecies = __webpack_require__(38);
  var arrayFill = __webpack_require__(85);
  var arrayCopyWithin = __webpack_require__(109);
  var $DP = __webpack_require__(7);
  var $GOPD = __webpack_require__(16);
  var dP = $DP.f;
  var gOPD = $GOPD.f;
  var RangeError = global.RangeError;
  var TypeError = global.TypeError;
  var Uint8Array = global.Uint8Array;
  var ARRAY_BUFFER = 'ArrayBuffer';
  var SHARED_BUFFER = 'Shared' + ARRAY_BUFFER;
  var BYTES_PER_ELEMENT = 'BYTES_PER_ELEMENT';
  var PROTOTYPE = 'prototype';
  var ArrayProto = Array[PROTOTYPE];
  var $ArrayBuffer = $buffer.ArrayBuffer;
  var $DataView = $buffer.DataView;
  var arrayForEach = createArrayMethod(0);
  var arrayFilter = createArrayMethod(2);
  var arraySome = createArrayMethod(3);
  var arrayEvery = createArrayMethod(4);
  var arrayFind = createArrayMethod(5);
  var arrayFindIndex = createArrayMethod(6);
  var arrayIncludes = createArrayIncludes(true);
  var arrayIndexOf = createArrayIncludes(false);
  var arrayValues = ArrayIterators.values;
  var arrayKeys = ArrayIterators.keys;
  var arrayEntries = ArrayIterators.entries;
  var arrayLastIndexOf = ArrayProto.lastIndexOf;
  var arrayReduce = ArrayProto.reduce;
  var arrayReduceRight = ArrayProto.reduceRight;
  var arrayJoin = ArrayProto.join;
  var arraySort = ArrayProto.sort;
  var arraySlice = ArrayProto.slice;
  var arrayToString = ArrayProto.toString;
  var arrayToLocaleString = ArrayProto.toLocaleString;
  var ITERATOR = wks('iterator');
  var TAG = wks('toStringTag');
  var TYPED_CONSTRUCTOR = uid('typed_constructor');
  var DEF_CONSTRUCTOR = uid('def_constructor');
  var ALL_CONSTRUCTORS = $typed.CONSTR;
  var TYPED_ARRAY = $typed.TYPED;
  var VIEW = $typed.VIEW;
  var WRONG_LENGTH = 'Wrong length!';

  var $map = createArrayMethod(1, function (O, length) {
    return allocate(speciesConstructor(O, O[DEF_CONSTRUCTOR]), length);
  });

  var LITTLE_ENDIAN = fails(function () {
    // eslint-disable-next-line no-undef
    return new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
  });

  var FORCED_SET = !!Uint8Array && !!Uint8Array[PROTOTYPE].set && fails(function () {
    new Uint8Array(1).set({});
  });

  var toOffset = function (it, BYTES) {
    var offset = toInteger(it);
    if (offset < 0 || offset % BYTES) throw RangeError('Wrong offset!');
    return offset;
  };

  var validate = function (it) {
    if (isObject(it) && TYPED_ARRAY in it) return it;
    throw TypeError(it + ' is not a typed array!');
  };

  var allocate = function (C, length) {
    if (!(isObject(C) && TYPED_CONSTRUCTOR in C)) {
      throw TypeError('It is not a typed array constructor!');
    } return new C(length);
  };

  var speciesFromList = function (O, list) {
    return fromList(speciesConstructor(O, O[DEF_CONSTRUCTOR]), list);
  };

  var fromList = function (C, list) {
    var index = 0;
    var length = list.length;
    var result = allocate(C, length);
    while (length > index) result[index] = list[index++];
    return result;
  };

  var addGetter = function (it, key, internal) {
    dP(it, key, { get: function () { return this._d[internal]; } });
  };

  var $from = function from(source /* , mapfn, thisArg */) {
    var O = toObject(source);
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var iterFn = getIterFn(O);
    var i, length, values, result, step, iterator;
    if (iterFn != undefined && !isArrayIter(iterFn)) {
      for (iterator = iterFn.call(O), values = [], i = 0; !(step = iterator.next()).done; i++) {
        values.push(step.value);
      } O = values;
    }
    if (mapping && aLen > 2) mapfn = ctx(mapfn, arguments[2], 2);
    for (i = 0, length = toLength(O.length), result = allocate(this, length); length > i; i++) {
      result[i] = mapping ? mapfn(O[i], i) : O[i];
    }
    return result;
  };

  var $of = function of(/* ...items */) {
    var index = 0;
    var length = arguments.length;
    var result = allocate(this, length);
    while (length > index) result[index] = arguments[index++];
    return result;
  };

  // iOS Safari 6.x fails here
  var TO_LOCALE_BUG = !!Uint8Array && fails(function () { arrayToLocaleString.call(new Uint8Array(1)); });

  var $toLocaleString = function toLocaleString() {
    return arrayToLocaleString.apply(TO_LOCALE_BUG ? arraySlice.call(validate(this)) : validate(this), arguments);
  };

  var proto = {
    copyWithin: function copyWithin(target, start /* , end */) {
      return arrayCopyWithin.call(validate(this), target, start, arguments.length > 2 ? arguments[2] : undefined);
    },
    every: function every(callbackfn /* , thisArg */) {
      return arrayEvery(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    fill: function fill(value /* , start, end */) { // eslint-disable-line no-unused-vars
      return arrayFill.apply(validate(this), arguments);
    },
    filter: function filter(callbackfn /* , thisArg */) {
      return speciesFromList(this, arrayFilter(validate(this), callbackfn,
        arguments.length > 1 ? arguments[1] : undefined));
    },
    find: function find(predicate /* , thisArg */) {
      return arrayFind(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    findIndex: function findIndex(predicate /* , thisArg */) {
      return arrayFindIndex(validate(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
    },
    forEach: function forEach(callbackfn /* , thisArg */) {
      arrayForEach(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    indexOf: function indexOf(searchElement /* , fromIndex */) {
      return arrayIndexOf(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    includes: function includes(searchElement /* , fromIndex */) {
      return arrayIncludes(validate(this), searchElement, arguments.length > 1 ? arguments[1] : undefined);
    },
    join: function join(separator) { // eslint-disable-line no-unused-vars
      return arrayJoin.apply(validate(this), arguments);
    },
    lastIndexOf: function lastIndexOf(searchElement /* , fromIndex */) { // eslint-disable-line no-unused-vars
      return arrayLastIndexOf.apply(validate(this), arguments);
    },
    map: function map(mapfn /* , thisArg */) {
      return $map(validate(this), mapfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    reduce: function reduce(callbackfn /* , initialValue */) { // eslint-disable-line no-unused-vars
      return arrayReduce.apply(validate(this), arguments);
    },
    reduceRight: function reduceRight(callbackfn /* , initialValue */) { // eslint-disable-line no-unused-vars
      return arrayReduceRight.apply(validate(this), arguments);
    },
    reverse: function reverse() {
      var that = this;
      var length = validate(that).length;
      var middle = Math.floor(length / 2);
      var index = 0;
      var value;
      while (index < middle) {
        value = that[index];
        that[index++] = that[--length];
        that[length] = value;
      } return that;
    },
    some: function some(callbackfn /* , thisArg */) {
      return arraySome(validate(this), callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    },
    sort: function sort(comparefn) {
      return arraySort.call(validate(this), comparefn);
    },
    subarray: function subarray(begin, end) {
      var O = validate(this);
      var length = O.length;
      var $begin = toAbsoluteIndex(begin, length);
      return new (speciesConstructor(O, O[DEF_CONSTRUCTOR]))(
        O.buffer,
        O.byteOffset + $begin * O.BYTES_PER_ELEMENT,
        toLength((end === undefined ? length : toAbsoluteIndex(end, length)) - $begin)
      );
    }
  };

  var $slice = function slice(start, end) {
    return speciesFromList(this, arraySlice.call(validate(this), start, end));
  };

  var $set = function set(arrayLike /* , offset */) {
    validate(this);
    var offset = toOffset(arguments[1], 1);
    var length = this.length;
    var src = toObject(arrayLike);
    var len = toLength(src.length);
    var index = 0;
    if (len + offset > length) throw RangeError(WRONG_LENGTH);
    while (index < len) this[offset + index] = src[index++];
  };

  var $iterators = {
    entries: function entries() {
      return arrayEntries.call(validate(this));
    },
    keys: function keys() {
      return arrayKeys.call(validate(this));
    },
    values: function values() {
      return arrayValues.call(validate(this));
    }
  };

  var isTAIndex = function (target, key) {
    return isObject(target)
      && target[TYPED_ARRAY]
      && typeof key != 'symbol'
      && key in target
      && String(+key) == String(key);
  };
  var $getDesc = function getOwnPropertyDescriptor(target, key) {
    return isTAIndex(target, key = toPrimitive(key, true))
      ? propertyDesc(2, target[key])
      : gOPD(target, key);
  };
  var $setDesc = function defineProperty(target, key, desc) {
    if (isTAIndex(target, key = toPrimitive(key, true))
      && isObject(desc)
      && has(desc, 'value')
      && !has(desc, 'get')
      && !has(desc, 'set')
      // TODO: add validation descriptor w/o calling accessors
      && !desc.configurable
      && (!has(desc, 'writable') || desc.writable)
      && (!has(desc, 'enumerable') || desc.enumerable)
    ) {
      target[key] = desc.value;
      return target;
    } return dP(target, key, desc);
  };

  if (!ALL_CONSTRUCTORS) {
    $GOPD.f = $getDesc;
    $DP.f = $setDesc;
  }

  $export($export.S + $export.F * !ALL_CONSTRUCTORS, 'Object', {
    getOwnPropertyDescriptor: $getDesc,
    defineProperty: $setDesc
  });

  if (fails(function () { arrayToString.call({}); })) {
    arrayToString = arrayToLocaleString = function toString() {
      return arrayJoin.call(this);
    };
  }

  var $TypedArrayPrototype$ = redefineAll({}, proto);
  redefineAll($TypedArrayPrototype$, $iterators);
  hide($TypedArrayPrototype$, ITERATOR, $iterators.values);
  redefineAll($TypedArrayPrototype$, {
    slice: $slice,
    set: $set,
    constructor: function () { /* noop */ },
    toString: arrayToString,
    toLocaleString: $toLocaleString
  });
  addGetter($TypedArrayPrototype$, 'buffer', 'b');
  addGetter($TypedArrayPrototype$, 'byteOffset', 'o');
  addGetter($TypedArrayPrototype$, 'byteLength', 'l');
  addGetter($TypedArrayPrototype$, 'length', 'e');
  dP($TypedArrayPrototype$, TAG, {
    get: function () { return this[TYPED_ARRAY]; }
  });

  // eslint-disable-next-line max-statements
  module.exports = function (KEY, BYTES, wrapper, CLAMPED) {
    CLAMPED = !!CLAMPED;
    var NAME = KEY + (CLAMPED ? 'Clamped' : '') + 'Array';
    var GETTER = 'get' + KEY;
    var SETTER = 'set' + KEY;
    var TypedArray = global[NAME];
    var Base = TypedArray || {};
    var TAC = TypedArray && getPrototypeOf(TypedArray);
    var FORCED = !TypedArray || !$typed.ABV;
    var O = {};
    var TypedArrayPrototype = TypedArray && TypedArray[PROTOTYPE];
    var getter = function (that, index) {
      var data = that._d;
      return data.v[GETTER](index * BYTES + data.o, LITTLE_ENDIAN);
    };
    var setter = function (that, index, value) {
      var data = that._d;
      if (CLAMPED) value = (value = Math.round(value)) < 0 ? 0 : value > 0xff ? 0xff : value & 0xff;
      data.v[SETTER](index * BYTES + data.o, value, LITTLE_ENDIAN);
    };
    var addElement = function (that, index) {
      dP(that, index, {
        get: function () {
          return getter(this, index);
        },
        set: function (value) {
          return setter(this, index, value);
        },
        enumerable: true
      });
    };
    if (FORCED) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME, '_d');
        var index = 0;
        var offset = 0;
        var buffer, byteLength, length, klass;
        if (!isObject(data)) {
          length = toIndex(data);
          byteLength = length * BYTES;
          buffer = new $ArrayBuffer(byteLength);
        } else if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          buffer = data;
          offset = toOffset($offset, BYTES);
          var $len = data.byteLength;
          if ($length === undefined) {
            if ($len % BYTES) throw RangeError(WRONG_LENGTH);
            byteLength = $len - offset;
            if (byteLength < 0) throw RangeError(WRONG_LENGTH);
          } else {
            byteLength = toLength($length) * BYTES;
            if (byteLength + offset > $len) throw RangeError(WRONG_LENGTH);
          }
          length = byteLength / BYTES;
        } else if (TYPED_ARRAY in data) {
          return fromList(TypedArray, data);
        } else {
          return $from.call(TypedArray, data);
        }
        hide(that, '_d', {
          b: buffer,
          o: offset,
          l: byteLength,
          e: length,
          v: new $DataView(buffer)
        });
        while (index < length) addElement(that, index++);
      });
      TypedArrayPrototype = TypedArray[PROTOTYPE] = create($TypedArrayPrototype$);
      hide(TypedArrayPrototype, 'constructor', TypedArray);
    } else if (!fails(function () {
      TypedArray(1);
    }) || !fails(function () {
      new TypedArray(-1); // eslint-disable-line no-new
    }) || !$iterDetect(function (iter) {
      new TypedArray(); // eslint-disable-line no-new
      new TypedArray(null); // eslint-disable-line no-new
      new TypedArray(1.5); // eslint-disable-line no-new
      new TypedArray(iter); // eslint-disable-line no-new
    }, true)) {
      TypedArray = wrapper(function (that, data, $offset, $length) {
        anInstance(that, TypedArray, NAME);
        var klass;
        // `ws` module bug, temporarily remove validation length for Uint8Array
        // https://github.com/websockets/ws/pull/645
        if (!isObject(data)) return new Base(toIndex(data));
        if (data instanceof $ArrayBuffer || (klass = classof(data)) == ARRAY_BUFFER || klass == SHARED_BUFFER) {
          return $length !== undefined
            ? new Base(data, toOffset($offset, BYTES), $length)
            : $offset !== undefined
              ? new Base(data, toOffset($offset, BYTES))
              : new Base(data);
        }
        if (TYPED_ARRAY in data) return fromList(TypedArray, data);
        return $from.call(TypedArray, data);
      });
      arrayForEach(TAC !== Function.prototype ? gOPN(Base).concat(gOPN(TAC)) : gOPN(Base), function (key) {
        if (!(key in TypedArray)) hide(TypedArray, key, Base[key]);
      });
      TypedArray[PROTOTYPE] = TypedArrayPrototype;
      if (!LIBRARY) TypedArrayPrototype.constructor = TypedArray;
    }
    var $nativeIterator = TypedArrayPrototype[ITERATOR];
    var CORRECT_ITER_NAME = !!$nativeIterator
      && ($nativeIterator.name == 'values' || $nativeIterator.name == undefined);
    var $iterator = $iterators.values;
    hide(TypedArray, TYPED_CONSTRUCTOR, true);
    hide(TypedArrayPrototype, TYPED_ARRAY, NAME);
    hide(TypedArrayPrototype, VIEW, true);
    hide(TypedArrayPrototype, DEF_CONSTRUCTOR, TypedArray);

    if (CLAMPED ? new TypedArray(1)[TAG] != NAME : !(TAG in TypedArrayPrototype)) {
      dP(TypedArrayPrototype, TAG, {
        get: function () { return NAME; }
      });
    }

    O[NAME] = TypedArray;

    $export($export.G + $export.W + $export.F * (TypedArray != Base), O);

    $export($export.S, NAME, {
      BYTES_PER_ELEMENT: BYTES
    });

    $export($export.S + $export.F * fails(function () { Base.of.call(TypedArray, 1); }), NAME, {
      from: $from,
      of: $of
    });

    if (!(BYTES_PER_ELEMENT in TypedArrayPrototype)) hide(TypedArrayPrototype, BYTES_PER_ELEMENT, BYTES);

    $export($export.P, NAME, proto);

    setSpecies(NAME);

    $export($export.P + $export.F * FORCED_SET, NAME, { set: $set });

    $export($export.P + $export.F * !CORRECT_ITER_NAME, NAME, $iterators);

    if (!LIBRARY && TypedArrayPrototype.toString != arrayToString) TypedArrayPrototype.toString = arrayToString;

    $export($export.P + $export.F * fails(function () {
      new TypedArray(1).slice();
    }), NAME, { slice: $slice });

    $export($export.P + $export.F * (fails(function () {
      return [1, 2].toLocaleString() != new TypedArray([1, 2]).toLocaleString();
    }) || !fails(function () {
      TypedArrayPrototype.toLocaleString.call([1, 2]);
    })), NAME, { toLocaleString: $toLocaleString });

    Iterators[NAME] = CORRECT_ITER_NAME ? $nativeIterator : $iterator;
    if (!LIBRARY && !CORRECT_ITER_NAME) hide(TypedArrayPrototype, ITERATOR, $iterator);
  };
} else module.exports = function () { /* empty */ };


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

var Map = __webpack_require__(114);
var $export = __webpack_require__(0);
var shared = __webpack_require__(50)('metadata');
var store = shared.store || (shared.store = new (__webpack_require__(117))());

var getOrCreateMetadataMap = function (target, targetKey, create) {
  var targetMetadata = store.get(target);
  if (!targetMetadata) {
    if (!create) return undefined;
    store.set(target, targetMetadata = new Map());
  }
  var keyMetadata = targetMetadata.get(targetKey);
  if (!keyMetadata) {
    if (!create) return undefined;
    targetMetadata.set(targetKey, keyMetadata = new Map());
  } return keyMetadata;
};
var ordinaryHasOwnMetadata = function (MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? false : metadataMap.has(MetadataKey);
};
var ordinaryGetOwnMetadata = function (MetadataKey, O, P) {
  var metadataMap = getOrCreateMetadataMap(O, P, false);
  return metadataMap === undefined ? undefined : metadataMap.get(MetadataKey);
};
var ordinaryDefineOwnMetadata = function (MetadataKey, MetadataValue, O, P) {
  getOrCreateMetadataMap(O, P, true).set(MetadataKey, MetadataValue);
};
var ordinaryOwnMetadataKeys = function (target, targetKey) {
  var metadataMap = getOrCreateMetadataMap(target, targetKey, false);
  var keys = [];
  if (metadataMap) metadataMap.forEach(function (_, key) { keys.push(key); });
  return keys;
};
var toMetaKey = function (it) {
  return it === undefined || typeof it == 'symbol' ? it : String(it);
};
var exp = function (O) {
  $export($export.S, 'Reflect', O);
};

module.exports = {
  store: store,
  map: getOrCreateMetadataMap,
  has: ordinaryHasOwnMetadata,
  get: ordinaryGetOwnMetadata,
  set: ordinaryDefineOwnMetadata,
  keys: ordinaryOwnMetadataKeys,
  key: toMetaKey,
  exp: exp
};


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

var META = __webpack_require__(32)('meta');
var isObject = __webpack_require__(4);
var has = __webpack_require__(11);
var setDesc = __webpack_require__(7).f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(3)(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.31 Array.prototype[@@unscopables]
var UNSCOPABLES = __webpack_require__(5)('unscopables');
var ArrayProto = Array.prototype;
if (ArrayProto[UNSCOPABLES] == undefined) __webpack_require__(12)(ArrayProto, UNSCOPABLES, {});
module.exports = function (key) {
  ArrayProto[UNSCOPABLES][key] = true;
};


/***/ }),
/* 31 */
/***/ (function(module, exports) {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};


/***/ }),
/* 32 */
/***/ (function(module, exports) {

var id = 0;
var px = Math.random();
module.exports = function (key) {
  return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
};


/***/ }),
/* 33 */
/***/ (function(module, exports) {

module.exports = false;


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 / 15.2.3.14 Object.keys(O)
var $keys = __webpack_require__(95);
var enumBugKeys = __webpack_require__(68);

module.exports = Object.keys || function keys(O) {
  return $keys(O, enumBugKeys);
};


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(24);
var max = Math.max;
var min = Math.min;
module.exports = function (index, length) {
  index = toInteger(index);
  return index < 0 ? max(index + length, 0) : min(index, length);
};


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
var anObject = __webpack_require__(1);
var dPs = __webpack_require__(96);
var enumBugKeys = __webpack_require__(68);
var IE_PROTO = __webpack_require__(67)('IE_PROTO');
var Empty = function () { /* empty */ };
var PROTOTYPE = 'prototype';

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var createDict = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = __webpack_require__(65)('iframe');
  var i = enumBugKeys.length;
  var lt = '<';
  var gt = '>';
  var iframeDocument;
  iframe.style.display = 'none';
  __webpack_require__(69).appendChild(iframe);
  iframe.src = 'javascript:'; // eslint-disable-line no-script-url
  // createDict = iframe.contentWindow.Object;
  // html.removeChild(iframe);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
  iframeDocument.close();
  createDict = iframeDocument.F;
  while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
  return createDict();
};

module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    Empty[PROTOTYPE] = anObject(O);
    result = new Empty();
    Empty[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = createDict();
  return Properties === undefined ? result : dPs(result, Properties);
};


/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(95);
var hiddenKeys = __webpack_require__(68).concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var dP = __webpack_require__(7);
var DESCRIPTORS = __webpack_require__(6);
var SPECIES = __webpack_require__(5)('species');

module.exports = function (KEY) {
  var C = global[KEY];
  if (DESCRIPTORS && C && !C[SPECIES]) dP.f(C, SPECIES, {
    configurable: true,
    get: function () { return this; }
  });
};


/***/ }),
/* 39 */
/***/ (function(module, exports) {

module.exports = function (it, Constructor, name, forbiddenField) {
  if (!(it instanceof Constructor) || (forbiddenField !== undefined && forbiddenField in it)) {
    throw TypeError(name + ': incorrect invocation!');
  } return it;
};


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(18);
var call = __webpack_require__(107);
var isArrayIter = __webpack_require__(81);
var anObject = __webpack_require__(1);
var toLength = __webpack_require__(8);
var getIterFn = __webpack_require__(83);
var BREAK = {};
var RETURN = {};
var exports = module.exports = function (iterable, entries, fn, that, ITERATOR) {
  var iterFn = ITERATOR ? function () { return iterable; } : getIterFn(iterable);
  var f = ctx(fn, that, entries ? 2 : 1);
  var index = 0;
  var length, step, iterator, result;
  if (typeof iterFn != 'function') throw TypeError(iterable + ' is not iterable!');
  // fast case for arrays with default iterator
  if (isArrayIter(iterFn)) for (length = toLength(iterable.length); length > index; index++) {
    result = entries ? f(anObject(step = iterable[index])[0], step[1]) : f(iterable[index]);
    if (result === BREAK || result === RETURN) return result;
  } else for (iterator = iterFn.call(iterable); !(step = iterator.next()).done;) {
    result = call(iterator, f, step.value, entries);
    if (result === BREAK || result === RETURN) return result;
  }
};
exports.BREAK = BREAK;
exports.RETURN = RETURN;


/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

var redefine = __webpack_require__(13);
module.exports = function (target, src, safe) {
  for (var key in src) redefine(target, key, src[key], safe);
  return target;
};


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

var def = __webpack_require__(7).f;
var has = __webpack_require__(11);
var TAG = __webpack_require__(5)('toStringTag');

module.exports = function (it, tag, stat) {
  if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
};


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var defined = __webpack_require__(23);
var fails = __webpack_require__(3);
var spaces = __webpack_require__(71);
var space = '[' + spaces + ']';
var non = '\u200b\u0085';
var ltrim = RegExp('^' + space + space + '*');
var rtrim = RegExp(space + space + '*$');

var exporter = function (KEY, exec, ALIAS) {
  var exp = {};
  var FORCE = fails(function () {
    return !!spaces[KEY]() || non[KEY]() != non;
  });
  var fn = exp[KEY] = FORCE ? exec(trim) : spaces[KEY];
  if (ALIAS) exp[ALIAS] = fn;
  $export($export.P + $export.F * FORCE, 'String', exp);
};

// 1 -> String#trimLeft
// 2 -> String#trimRight
// 3 -> String#trim
var trim = exporter.trim = function (string, TYPE) {
  string = String(defined(string));
  if (TYPE & 1) string = string.replace(ltrim, '');
  if (TYPE & 2) string = string.replace(rtrim, '');
  return string;
};

module.exports = exporter;


/***/ }),
/* 44 */
/***/ (function(module, exports) {

module.exports = {};


/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
module.exports = function (it, TYPE) {
  if (!isObject(it) || it._t !== TYPE) throw TypeError('Incompatible receiver, ' + TYPE + ' required!');
  return it;
};


/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _point = __webpack_require__(64);

Object.keys(_point).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _point[key];
    }
  });
});

var _polygon = __webpack_require__(127);

Object.keys(_polygon).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _polygon[key];
    }
  });
});

var _rectangle = __webpack_require__(129);

Object.keys(_rectangle).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _rectangle[key];
    }
  });
});

var _line = __webpack_require__(128);

Object.keys(_line).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _line[key];
    }
  });
});

var _utils = __webpack_require__(338);

Object.keys(_utils).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _utils[key];
    }
  });
});

var _circle = __webpack_require__(339);

Object.keys(_circle).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function get() {
      return _circle[key];
    }
  });
});

/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var cof = __webpack_require__(19);
// eslint-disable-next-line no-prototype-builtins
module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
  return cof(it) == 'String' ? it.split('') : Object(it);
};


/***/ }),
/* 48 */
/***/ (function(module, exports) {

exports.f = {}.propertyIsEnumerable;


/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

// getting tag from 19.1.3.6 Object.prototype.toString()
var cof = __webpack_require__(19);
var TAG = __webpack_require__(5)('toStringTag');
// ES3 wrong here
var ARG = cof(function () { return arguments; }()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (e) { /* empty */ }
};

module.exports = function (it) {
  var O, T, B;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
    // @@toStringTag case
    : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
    // builtinTag case
    : ARG ? cof(O)
    // ES3 arguments fallback
    : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
};


/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || (global[SHARED] = {});
module.exports = function (key) {
  return store[key] || (store[key] = {});
};


/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

// false -> Array#indexOf
// true  -> Array#includes
var toIObject = __webpack_require__(15);
var toLength = __webpack_require__(8);
var toAbsoluteIndex = __webpack_require__(35);
module.exports = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
      if (O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};


/***/ }),
/* 52 */
/***/ (function(module, exports) {

exports.f = Object.getOwnPropertySymbols;


/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(19);
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};


/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.8 IsRegExp(argument)
var isObject = __webpack_require__(4);
var cof = __webpack_require__(19);
var MATCH = __webpack_require__(5)('match');
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : cof(it) == 'RegExp');
};


/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

var ITERATOR = __webpack_require__(5)('iterator');
var SAFE_CLOSING = false;

try {
  var riter = [7][ITERATOR]();
  riter['return'] = function () { SAFE_CLOSING = true; };
  // eslint-disable-next-line no-throw-literal
  Array.from(riter, function () { throw 2; });
} catch (e) { /* empty */ }

module.exports = function (exec, skipClosing) {
  if (!skipClosing && !SAFE_CLOSING) return false;
  var safe = false;
  try {
    var arr = [7];
    var iter = arr[ITERATOR]();
    iter.next = function () { return { done: safe = true }; };
    arr[ITERATOR] = function () { return iter; };
    exec(arr);
  } catch (e) { /* empty */ }
  return safe;
};


/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.2.5.3 get RegExp.prototype.flags
var anObject = __webpack_require__(1);
module.exports = function () {
  var that = anObject(this);
  var result = '';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.unicode) result += 'u';
  if (that.sticky) result += 'y';
  return result;
};


/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var hide = __webpack_require__(12);
var redefine = __webpack_require__(13);
var fails = __webpack_require__(3);
var defined = __webpack_require__(23);
var wks = __webpack_require__(5);

module.exports = function (KEY, length, exec) {
  var SYMBOL = wks(KEY);
  var fns = exec(defined, SYMBOL, ''[KEY]);
  var strfn = fns[0];
  var rxfn = fns[1];
  if (fails(function () {
    var O = {};
    O[SYMBOL] = function () { return 7; };
    return ''[KEY](O) != 7;
  })) {
    redefine(String.prototype, KEY, strfn);
    hide(RegExp.prototype, SYMBOL, length == 2
      // 21.2.5.8 RegExp.prototype[@@replace](string, replaceValue)
      // 21.2.5.11 RegExp.prototype[@@split](string, limit)
      ? function (string, arg) { return rxfn.call(string, this, arg); }
      // 21.2.5.6 RegExp.prototype[@@match](string)
      // 21.2.5.9 RegExp.prototype[@@search](string)
      : function (string) { return rxfn.call(string, this); }
    );
  }
};


/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

// 7.3.20 SpeciesConstructor(O, defaultConstructor)
var anObject = __webpack_require__(1);
var aFunction = __webpack_require__(10);
var SPECIES = __webpack_require__(5)('species');
module.exports = function (O, D) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || (S = anObject(C)[SPECIES]) == undefined ? D : aFunction(S);
};


/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(13);
var redefineAll = __webpack_require__(41);
var meta = __webpack_require__(29);
var forOf = __webpack_require__(40);
var anInstance = __webpack_require__(39);
var isObject = __webpack_require__(4);
var fails = __webpack_require__(3);
var $iterDetect = __webpack_require__(55);
var setToStringTag = __webpack_require__(42);
var inheritIfRequired = __webpack_require__(72);

module.exports = function (NAME, wrapper, methods, common, IS_MAP, IS_WEAK) {
  var Base = global[NAME];
  var C = Base;
  var ADDER = IS_MAP ? 'set' : 'add';
  var proto = C && C.prototype;
  var O = {};
  var fixMethod = function (KEY) {
    var fn = proto[KEY];
    redefine(proto, KEY,
      KEY == 'delete' ? function (a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'has' ? function has(a) {
        return IS_WEAK && !isObject(a) ? false : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'get' ? function get(a) {
        return IS_WEAK && !isObject(a) ? undefined : fn.call(this, a === 0 ? 0 : a);
      } : KEY == 'add' ? function add(a) { fn.call(this, a === 0 ? 0 : a); return this; }
        : function set(a, b) { fn.call(this, a === 0 ? 0 : a, b); return this; }
    );
  };
  if (typeof C != 'function' || !(IS_WEAK || proto.forEach && !fails(function () {
    new C().entries().next();
  }))) {
    // create collection constructor
    C = common.getConstructor(wrapper, NAME, IS_MAP, ADDER);
    redefineAll(C.prototype, methods);
    meta.NEED = true;
  } else {
    var instance = new C();
    // early implementations not supports chaining
    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) != instance;
    // V8 ~  Chromium 40- weak-collections throws on primitives, but should return false
    var THROWS_ON_PRIMITIVES = fails(function () { instance.has(1); });
    // most early implementations doesn't supports iterables, most modern - not close it correctly
    var ACCEPT_ITERABLES = $iterDetect(function (iter) { new C(iter); }); // eslint-disable-line no-new
    // for early implementations -0 and +0 not the same
    var BUGGY_ZERO = !IS_WEAK && fails(function () {
      // V8 ~ Chromium 42- fails only with 5+ elements
      var $instance = new C();
      var index = 5;
      while (index--) $instance[ADDER](index, index);
      return !$instance.has(-0);
    });
    if (!ACCEPT_ITERABLES) {
      C = wrapper(function (target, iterable) {
        anInstance(target, C, NAME);
        var that = inheritIfRequired(new Base(), target, C);
        if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
        return that;
      });
      C.prototype = proto;
      proto.constructor = C;
    }
    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
      fixMethod('delete');
      fixMethod('has');
      IS_MAP && fixMethod('get');
    }
    if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);
    // weak collections should not contains .clear method
    if (IS_WEAK && proto.clear) delete proto.clear;
  }

  setToStringTag(C, NAME);

  O[NAME] = C;
  $export($export.G + $export.W + $export.F * (C != Base), O);

  if (!IS_WEAK) common.setStrong(C, NAME, IS_MAP);

  return C;
};


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var hide = __webpack_require__(12);
var uid = __webpack_require__(32);
var TYPED = uid('typed_array');
var VIEW = uid('view');
var ABV = !!(global.ArrayBuffer && global.DataView);
var CONSTR = ABV;
var i = 0;
var l = 9;
var Typed;

var TypedArrayConstructors = (
  'Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array'
).split(',');

while (i < l) {
  if (Typed = global[TypedArrayConstructors[i++]]) {
    hide(Typed.prototype, TYPED, true);
    hide(Typed.prototype, VIEW, true);
  } else CONSTR = false;
}

module.exports = {
  ABV: ABV,
  CONSTR: CONSTR,
  TYPED: TYPED,
  VIEW: VIEW
};


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// Forced replacement prototype accessors methods
module.exports = __webpack_require__(33) || !__webpack_require__(3)(function () {
  var K = Math.random();
  // In FF throws only define methods
  // eslint-disable-next-line no-undef, no-useless-call
  __defineSetter__.call(null, K, function () { /* empty */ });
  delete __webpack_require__(2)[K];
});


/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(0);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { of: function of() {
    var length = arguments.length;
    var A = new Array(length);
    while (length--) A[length] = arguments[length];
    return new this(A);
  } });
};


/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-setmap-offrom/
var $export = __webpack_require__(0);
var aFunction = __webpack_require__(10);
var ctx = __webpack_require__(18);
var forOf = __webpack_require__(40);

module.exports = function (COLLECTION) {
  $export($export.S, COLLECTION, { from: function from(source /* , mapFn, thisArg */) {
    var mapFn = arguments[1];
    var mapping, A, n, cb;
    aFunction(this);
    mapping = mapFn !== undefined;
    if (mapping) aFunction(mapFn);
    if (source == undefined) return new this();
    A = [];
    if (mapping) {
      n = 0;
      cb = ctx(mapFn, arguments[2], 2);
      forOf(source, false, function (nextItem) {
        A.push(cb(nextItem, n++));
      });
    } else {
      forOf(source, false, A.push, A);
    }
    return new this(A);
  } });
};


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var pt = function pt(x, y) {
  return { x: x, y: y };
};

var ZERO = pt(0, 0);

// Eucliean distance between two points
var distance = function distance(pt1, pt2) {
  return Math.sqrt((pt2.x - pt1.x) * (pt2.x - pt1.x) + (pt2.y - pt1.y) * (pt2.y - pt1.y));
};

// Magnitude 
var magnitude = function magnitude(v) {
  return distance(v, ZERO);
};

// Given the three points, are the counter clockwise?
var ccw = function ccw(a, b, c) {
  return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
};

// Angle between two points in radians
var angle2 = function angle2(a, b) {
  return Math.atan2(b.y - a.y, b.x - a.x);
};

// Angle between three points in radians
var angle3 = function angle3(a, b, c) {
  return Math.atan2(a.y - b.y, a.x - b.x) - Math.atan2(c.y - b.y, c.x - b.x);
};

var piNum = Math.PI / 180;
var numPi = 180 / Math.PI;
var degToRad = function degToRad(deg) {
  return deg * piNum;
};
var radToDeg = function radToDeg(rad) {
  return rad * numPi;
};

var sum = function sum(a, b) {
  return pt(a.x + b.x, a.y + b.y);
};
var sub = function sub(a, b) {
  return pt(a.x - b.x, a.y - b.y);
};

var dot = function dot(a, b) {
  return a.x * b.x + a.y * b.y;
};
var unit = function unit(a) {
  var dist = distance(pt(0, 0), a);
  return pt(a.x / dist, a.y / dist);
};

var normal = function normal(p0, p1) {
  // if we define dx=x2-x1 and dy=y2-y1, then the normals are (-dy, dx) and (dy, -dx).
  var dx = p1.x - p0.x;
  var dy = p1.y - p0.y;
  // orthoginal(sub(p1, p0))
  return pt(-dy, dx);
};

var orthoginal = function orthoginal(v) {
  return pt(-v.y, v.x);
};

var scalar = function scalar(a, c) {
  return pt(a.x * c, a.y * c);
};

exports.pt = pt;
exports.ccw = ccw;
exports.sum = sum;
exports.sub = sub;
exports.dot = dot;
exports.ZERO = ZERO;
exports.unit = unit;
exports.scalar = scalar;
exports.normal = normal;
exports.angle2 = angle2;
exports.angle3 = angle3;
exports.degToRad = degToRad;
exports.radToDeg = radToDeg;
exports.distance = distance;
exports.magnitude = magnitude;
exports.orthoginal = orthoginal;

/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var document = __webpack_require__(2).document;
// typeof document.createElement is 'object' in old IE
var is = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return is ? document.createElement(it) : {};
};


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var core = __webpack_require__(21);
var LIBRARY = __webpack_require__(33);
var wksExt = __webpack_require__(94);
var defineProperty = __webpack_require__(7).f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

var shared = __webpack_require__(50)('keys');
var uid = __webpack_require__(32);
module.exports = function (key) {
  return shared[key] || (shared[key] = uid(key));
};


/***/ }),
/* 68 */
/***/ (function(module, exports) {

// IE 8- don't enum bug keys
module.exports = (
  'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
).split(',');


/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

var document = __webpack_require__(2).document;
module.exports = document && document.documentElement;


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
var isObject = __webpack_require__(4);
var anObject = __webpack_require__(1);
var check = function (O, proto) {
  anObject(O);
  if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
};
module.exports = {
  set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
    function (test, buggy, set) {
      try {
        set = __webpack_require__(18)(Function.call, __webpack_require__(16).f(Object.prototype, '__proto__').set, 2);
        set(test, []);
        buggy = !(test instanceof Array);
      } catch (e) { buggy = true; }
      return function setPrototypeOf(O, proto) {
        check(O, proto);
        if (buggy) O.__proto__ = proto;
        else set(O, proto);
        return O;
      };
    }({}, false) : undefined),
  check: check
};


/***/ }),
/* 71 */
/***/ (function(module, exports) {

module.exports = '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003' +
  '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var setPrototypeOf = __webpack_require__(70).set;
module.exports = function (that, target, C) {
  var S = target.constructor;
  var P;
  if (S !== C && typeof S == 'function' && (P = S.prototype) !== C.prototype && isObject(P) && setPrototypeOf) {
    setPrototypeOf(that, P);
  } return that;
};


/***/ }),
/* 73 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var toInteger = __webpack_require__(24);
var defined = __webpack_require__(23);

module.exports = function repeat(count) {
  var str = String(defined(this));
  var res = '';
  var n = toInteger(count);
  if (n < 0 || n == Infinity) throw RangeError("Count can't be negative");
  for (;n > 0; (n >>>= 1) && (str += str)) if (n & 1) res += str;
  return res;
};


/***/ }),
/* 74 */
/***/ (function(module, exports) {

// 20.2.2.28 Math.sign(x)
module.exports = Math.sign || function sign(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) == 0 || x != x ? x : x < 0 ? -1 : 1;
};


/***/ }),
/* 75 */
/***/ (function(module, exports) {

// 20.2.2.14 Math.expm1(x)
var $expm1 = Math.expm1;
module.exports = (!$expm1
  // Old FF bug
  || $expm1(10) > 22025.465794806719 || $expm1(10) < 22025.4657948067165168
  // Tor Browser bug
  || $expm1(-2e-17) != -2e-17
) ? function expm1(x) {
  return (x = +x) == 0 ? x : x > -1e-6 && x < 1e-6 ? x + x * x / 2 : Math.exp(x) - 1;
} : $expm1;


/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

var toInteger = __webpack_require__(24);
var defined = __webpack_require__(23);
// true  -> String#at
// false -> String#codePointAt
module.exports = function (TO_STRING) {
  return function (that, pos) {
    var s = String(defined(that));
    var i = toInteger(pos);
    var l = s.length;
    var a, b;
    if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
    a = s.charCodeAt(i);
    return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
      ? TO_STRING ? s.charAt(i) : a
      : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
  };
};


/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(33);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(13);
var hide = __webpack_require__(12);
var has = __webpack_require__(11);
var Iterators = __webpack_require__(44);
var $iterCreate = __webpack_require__(78);
var setToStringTag = __webpack_require__(42);
var getPrototypeOf = __webpack_require__(17);
var ITERATOR = __webpack_require__(5)('iterator');
var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
var FF_ITERATOR = '@@iterator';
var KEYS = 'keys';
var VALUES = 'values';

var returnThis = function () { return this; };

module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
  $iterCreate(Constructor, NAME, next);
  var getMethod = function (kind) {
    if (!BUGGY && kind in proto) return proto[kind];
    switch (kind) {
      case KEYS: return function keys() { return new Constructor(this, kind); };
      case VALUES: return function values() { return new Constructor(this, kind); };
    } return function entries() { return new Constructor(this, kind); };
  };
  var TAG = NAME + ' Iterator';
  var DEF_VALUES = DEFAULT == VALUES;
  var VALUES_BUG = false;
  var proto = Base.prototype;
  var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
  var $default = (!BUGGY && $native) || getMethod(DEFAULT);
  var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
  var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
  var methods, key, IteratorPrototype;
  // Fix native
  if ($anyNative) {
    IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
    if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
      // Set @@toStringTag to native iterators
      setToStringTag(IteratorPrototype, TAG, true);
      // fix for some old engines
      if (!LIBRARY && !has(IteratorPrototype, ITERATOR)) hide(IteratorPrototype, ITERATOR, returnThis);
    }
  }
  // fix Array#{values, @@iterator}.name in V8 / FF
  if (DEF_VALUES && $native && $native.name !== VALUES) {
    VALUES_BUG = true;
    $default = function values() { return $native.call(this); };
  }
  // Define iterator
  if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
    hide(proto, ITERATOR, $default);
  }
  // Plug for library
  Iterators[NAME] = $default;
  Iterators[TAG] = returnThis;
  if (DEFAULT) {
    methods = {
      values: DEF_VALUES ? $default : getMethod(VALUES),
      keys: IS_SET ? $default : getMethod(KEYS),
      entries: $entries
    };
    if (FORCED) for (key in methods) {
      if (!(key in proto)) redefine(proto, key, methods[key]);
    } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
  }
  return methods;
};


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var create = __webpack_require__(36);
var descriptor = __webpack_require__(31);
var setToStringTag = __webpack_require__(42);
var IteratorPrototype = {};

// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
__webpack_require__(12)(IteratorPrototype, __webpack_require__(5)('iterator'), function () { return this; });

module.exports = function (Constructor, NAME, next) {
  Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
  setToStringTag(Constructor, NAME + ' Iterator');
};


/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

// helper for String#{startsWith, endsWith, includes}
var isRegExp = __webpack_require__(54);
var defined = __webpack_require__(23);

module.exports = function (that, searchString, NAME) {
  if (isRegExp(searchString)) throw TypeError('String#' + NAME + " doesn't accept regex!");
  return String(defined(that));
};


/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

var MATCH = __webpack_require__(5)('match');
module.exports = function (KEY) {
  var re = /./;
  try {
    '/./'[KEY](re);
  } catch (e) {
    try {
      re[MATCH] = false;
      return !'/./'[KEY](re);
    } catch (f) { /* empty */ }
  } return true;
};


/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

// check on default Array iterator
var Iterators = __webpack_require__(44);
var ITERATOR = __webpack_require__(5)('iterator');
var ArrayProto = Array.prototype;

module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayProto[ITERATOR] === it);
};


/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $defineProperty = __webpack_require__(7);
var createDesc = __webpack_require__(31);

module.exports = function (object, index, value) {
  if (index in object) $defineProperty.f(object, index, createDesc(0, value));
  else object[index] = value;
};


/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

var classof = __webpack_require__(49);
var ITERATOR = __webpack_require__(5)('iterator');
var Iterators = __webpack_require__(44);
module.exports = __webpack_require__(21).getIteratorMethod = function (it) {
  if (it != undefined) return it[ITERATOR]
    || it['@@iterator']
    || Iterators[classof(it)];
};


/***/ }),
/* 84 */
/***/ (function(module, exports, __webpack_require__) {

// 9.4.2.3 ArraySpeciesCreate(originalArray, length)
var speciesConstructor = __webpack_require__(227);

module.exports = function (original, length) {
  return new (speciesConstructor(original))(length);
};


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)

var toObject = __webpack_require__(9);
var toAbsoluteIndex = __webpack_require__(35);
var toLength = __webpack_require__(8);
module.exports = function fill(value /* , start = 0, end = @length */) {
  var O = toObject(this);
  var length = toLength(O.length);
  var aLen = arguments.length;
  var index = toAbsoluteIndex(aLen > 1 ? arguments[1] : undefined, length);
  var end = aLen > 2 ? arguments[2] : undefined;
  var endPos = end === undefined ? length : toAbsoluteIndex(end, length);
  while (endPos > index) O[index++] = value;
  return O;
};


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var addToUnscopables = __webpack_require__(30);
var step = __webpack_require__(110);
var Iterators = __webpack_require__(44);
var toIObject = __webpack_require__(15);

// 22.1.3.4 Array.prototype.entries()
// 22.1.3.13 Array.prototype.keys()
// 22.1.3.29 Array.prototype.values()
// 22.1.3.30 Array.prototype[@@iterator]()
module.exports = __webpack_require__(77)(Array, 'Array', function (iterated, kind) {
  this._t = toIObject(iterated); // target
  this._i = 0;                   // next index
  this._k = kind;                // kind
// 22.1.5.2.1 %ArrayIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var kind = this._k;
  var index = this._i++;
  if (!O || index >= O.length) {
    this._t = undefined;
    return step(1);
  }
  if (kind == 'keys') return step(0, index);
  if (kind == 'values') return step(0, O[index]);
  return step(0, [index, O[index]]);
}, 'values');

// argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
Iterators.Arguments = Iterators.Array;

addToUnscopables('keys');
addToUnscopables('values');
addToUnscopables('entries');


/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

var ctx = __webpack_require__(18);
var invoke = __webpack_require__(100);
var html = __webpack_require__(69);
var cel = __webpack_require__(65);
var global = __webpack_require__(2);
var process = global.process;
var setTask = global.setImmediate;
var clearTask = global.clearImmediate;
var MessageChannel = global.MessageChannel;
var Dispatch = global.Dispatch;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var defer, channel, port;
var run = function () {
  var id = +this;
  // eslint-disable-next-line no-prototype-builtins
  if (queue.hasOwnProperty(id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var listener = function (event) {
  run.call(event.data);
};
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!setTask || !clearTask) {
  setTask = function setImmediate(fn) {
    var args = [];
    var i = 1;
    while (arguments.length > i) args.push(arguments[i++]);
    queue[++counter] = function () {
      // eslint-disable-next-line no-new-func
      invoke(typeof fn == 'function' ? fn : Function(fn), args);
    };
    defer(counter);
    return counter;
  };
  clearTask = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (__webpack_require__(19)(process) == 'process') {
    defer = function (id) {
      process.nextTick(ctx(run, id, 1));
    };
  // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(ctx(run, id, 1));
    };
  // Browsers with MessageChannel, includes WebWorkers
  } else if (MessageChannel) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = listener;
    defer = ctx(port.postMessage, port, 1);
  // Browsers with postMessage, skip WebWorkers
  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && typeof postMessage == 'function' && !global.importScripts) {
    defer = function (id) {
      global.postMessage(id + '', '*');
    };
    global.addEventListener('message', listener, false);
  // IE8-
  } else if (ONREADYSTATECHANGE in cel('script')) {
    defer = function (id) {
      html.appendChild(cel('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run.call(id);
      };
    };
  // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(ctx(run, id, 1), 0);
    };
  }
}
module.exports = {
  set: setTask,
  clear: clearTask
};


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var macrotask = __webpack_require__(87).set;
var Observer = global.MutationObserver || global.WebKitMutationObserver;
var process = global.process;
var Promise = global.Promise;
var isNode = __webpack_require__(19)(process) == 'process';

module.exports = function () {
  var head, last, notify;

  var flush = function () {
    var parent, fn;
    if (isNode && (parent = process.domain)) parent.exit();
    while (head) {
      fn = head.fn;
      head = head.next;
      try {
        fn();
      } catch (e) {
        if (head) notify();
        else last = undefined;
        throw e;
      }
    } last = undefined;
    if (parent) parent.enter();
  };

  // Node.js
  if (isNode) {
    notify = function () {
      process.nextTick(flush);
    };
  // browsers with MutationObserver, except iOS Safari - https://github.com/zloirock/core-js/issues/339
  } else if (Observer && !(global.navigator && global.navigator.standalone)) {
    var toggle = true;
    var node = document.createTextNode('');
    new Observer(flush).observe(node, { characterData: true }); // eslint-disable-line no-new
    notify = function () {
      node.data = toggle = !toggle;
    };
  // environments with maybe non-completely correct, but existent Promise
  } else if (Promise && Promise.resolve) {
    var promise = Promise.resolve();
    notify = function () {
      promise.then(flush);
    };
  // for other environments - macrotask based on:
  // - setImmediate
  // - MessageChannel
  // - window.postMessag
  // - onreadystatechange
  // - setTimeout
  } else {
    notify = function () {
      // strange IE + webpack dev server bug - use .call(global)
      macrotask.call(global, flush);
    };
  }

  return function (fn) {
    var task = { fn: fn, next: undefined };
    if (last) last.next = task;
    if (!head) {
      head = task;
      notify();
    } last = task;
  };
};


/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 25.4.1.5 NewPromiseCapability(C)
var aFunction = __webpack_require__(10);

function PromiseCapability(C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aFunction(resolve);
  this.reject = aFunction(reject);
}

module.exports.f = function (C) {
  return new PromiseCapability(C);
};


/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var DESCRIPTORS = __webpack_require__(6);
var LIBRARY = __webpack_require__(33);
var $typed = __webpack_require__(60);
var hide = __webpack_require__(12);
var redefineAll = __webpack_require__(41);
var fails = __webpack_require__(3);
var anInstance = __webpack_require__(39);
var toInteger = __webpack_require__(24);
var toLength = __webpack_require__(8);
var toIndex = __webpack_require__(119);
var gOPN = __webpack_require__(37).f;
var dP = __webpack_require__(7).f;
var arrayFill = __webpack_require__(85);
var setToStringTag = __webpack_require__(42);
var ARRAY_BUFFER = 'ArrayBuffer';
var DATA_VIEW = 'DataView';
var PROTOTYPE = 'prototype';
var WRONG_LENGTH = 'Wrong length!';
var WRONG_INDEX = 'Wrong index!';
var $ArrayBuffer = global[ARRAY_BUFFER];
var $DataView = global[DATA_VIEW];
var Math = global.Math;
var RangeError = global.RangeError;
// eslint-disable-next-line no-shadow-restricted-names
var Infinity = global.Infinity;
var BaseBuffer = $ArrayBuffer;
var abs = Math.abs;
var pow = Math.pow;
var floor = Math.floor;
var log = Math.log;
var LN2 = Math.LN2;
var BUFFER = 'buffer';
var BYTE_LENGTH = 'byteLength';
var BYTE_OFFSET = 'byteOffset';
var $BUFFER = DESCRIPTORS ? '_b' : BUFFER;
var $LENGTH = DESCRIPTORS ? '_l' : BYTE_LENGTH;
var $OFFSET = DESCRIPTORS ? '_o' : BYTE_OFFSET;

// IEEE754 conversions based on https://github.com/feross/ieee754
function packIEEE754(value, mLen, nBytes) {
  var buffer = new Array(nBytes);
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var rt = mLen === 23 ? pow(2, -24) - pow(2, -77) : 0;
  var i = 0;
  var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
  var e, m, c;
  value = abs(value);
  // eslint-disable-next-line no-self-compare
  if (value != value || value === Infinity) {
    // eslint-disable-next-line no-self-compare
    m = value != value ? 1 : 0;
    e = eMax;
  } else {
    e = floor(log(value) / LN2);
    if (value * (c = pow(2, -e)) < 1) {
      e--;
      c *= 2;
    }
    if (e + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e++;
      c /= 2;
    }
    if (e + eBias >= eMax) {
      m = 0;
      e = eMax;
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * pow(2, mLen);
      e = e + eBias;
    } else {
      m = value * pow(2, eBias - 1) * pow(2, mLen);
      e = 0;
    }
  }
  for (; mLen >= 8; buffer[i++] = m & 255, m /= 256, mLen -= 8);
  e = e << mLen | m;
  eLen += mLen;
  for (; eLen > 0; buffer[i++] = e & 255, e /= 256, eLen -= 8);
  buffer[--i] |= s * 128;
  return buffer;
}
function unpackIEEE754(buffer, mLen, nBytes) {
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var nBits = eLen - 7;
  var i = nBytes - 1;
  var s = buffer[i--];
  var e = s & 127;
  var m;
  s >>= 7;
  for (; nBits > 0; e = e * 256 + buffer[i], i--, nBits -= 8);
  m = e & (1 << -nBits) - 1;
  e >>= -nBits;
  nBits += mLen;
  for (; nBits > 0; m = m * 256 + buffer[i], i--, nBits -= 8);
  if (e === 0) {
    e = 1 - eBias;
  } else if (e === eMax) {
    return m ? NaN : s ? -Infinity : Infinity;
  } else {
    m = m + pow(2, mLen);
    e = e - eBias;
  } return (s ? -1 : 1) * m * pow(2, e - mLen);
}

function unpackI32(bytes) {
  return bytes[3] << 24 | bytes[2] << 16 | bytes[1] << 8 | bytes[0];
}
function packI8(it) {
  return [it & 0xff];
}
function packI16(it) {
  return [it & 0xff, it >> 8 & 0xff];
}
function packI32(it) {
  return [it & 0xff, it >> 8 & 0xff, it >> 16 & 0xff, it >> 24 & 0xff];
}
function packF64(it) {
  return packIEEE754(it, 52, 8);
}
function packF32(it) {
  return packIEEE754(it, 23, 4);
}

function addGetter(C, key, internal) {
  dP(C[PROTOTYPE], key, { get: function () { return this[internal]; } });
}

function get(view, bytes, index, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = store.slice(start, start + bytes);
  return isLittleEndian ? pack : pack.reverse();
}
function set(view, bytes, index, conversion, value, isLittleEndian) {
  var numIndex = +index;
  var intIndex = toIndex(numIndex);
  if (intIndex + bytes > view[$LENGTH]) throw RangeError(WRONG_INDEX);
  var store = view[$BUFFER]._b;
  var start = intIndex + view[$OFFSET];
  var pack = conversion(+value);
  for (var i = 0; i < bytes; i++) store[start + i] = pack[isLittleEndian ? i : bytes - i - 1];
}

if (!$typed.ABV) {
  $ArrayBuffer = function ArrayBuffer(length) {
    anInstance(this, $ArrayBuffer, ARRAY_BUFFER);
    var byteLength = toIndex(length);
    this._b = arrayFill.call(new Array(byteLength), 0);
    this[$LENGTH] = byteLength;
  };

  $DataView = function DataView(buffer, byteOffset, byteLength) {
    anInstance(this, $DataView, DATA_VIEW);
    anInstance(buffer, $ArrayBuffer, DATA_VIEW);
    var bufferLength = buffer[$LENGTH];
    var offset = toInteger(byteOffset);
    if (offset < 0 || offset > bufferLength) throw RangeError('Wrong offset!');
    byteLength = byteLength === undefined ? bufferLength - offset : toLength(byteLength);
    if (offset + byteLength > bufferLength) throw RangeError(WRONG_LENGTH);
    this[$BUFFER] = buffer;
    this[$OFFSET] = offset;
    this[$LENGTH] = byteLength;
  };

  if (DESCRIPTORS) {
    addGetter($ArrayBuffer, BYTE_LENGTH, '_l');
    addGetter($DataView, BUFFER, '_b');
    addGetter($DataView, BYTE_LENGTH, '_l');
    addGetter($DataView, BYTE_OFFSET, '_o');
  }

  redefineAll($DataView[PROTOTYPE], {
    getInt8: function getInt8(byteOffset) {
      return get(this, 1, byteOffset)[0] << 24 >> 24;
    },
    getUint8: function getUint8(byteOffset) {
      return get(this, 1, byteOffset)[0];
    },
    getInt16: function getInt16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return (bytes[1] << 8 | bytes[0]) << 16 >> 16;
    },
    getUint16: function getUint16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments[1]);
      return bytes[1] << 8 | bytes[0];
    },
    getInt32: function getInt32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1]));
    },
    getUint32: function getUint32(byteOffset /* , littleEndian */) {
      return unpackI32(get(this, 4, byteOffset, arguments[1])) >>> 0;
    },
    getFloat32: function getFloat32(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 4, byteOffset, arguments[1]), 23, 4);
    },
    getFloat64: function getFloat64(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 8, byteOffset, arguments[1]), 52, 8);
    },
    setInt8: function setInt8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setUint8: function setUint8(byteOffset, value) {
      set(this, 1, byteOffset, packI8, value);
    },
    setInt16: function setInt16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setUint16: function setUint16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packI16, value, arguments[2]);
    },
    setInt32: function setInt32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setUint32: function setUint32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packI32, value, arguments[2]);
    },
    setFloat32: function setFloat32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packF32, value, arguments[2]);
    },
    setFloat64: function setFloat64(byteOffset, value /* , littleEndian */) {
      set(this, 8, byteOffset, packF64, value, arguments[2]);
    }
  });
} else {
  if (!fails(function () {
    $ArrayBuffer(1);
  }) || !fails(function () {
    new $ArrayBuffer(-1); // eslint-disable-line no-new
  }) || fails(function () {
    new $ArrayBuffer(); // eslint-disable-line no-new
    new $ArrayBuffer(1.5); // eslint-disable-line no-new
    new $ArrayBuffer(NaN); // eslint-disable-line no-new
    return $ArrayBuffer.name != ARRAY_BUFFER;
  })) {
    $ArrayBuffer = function ArrayBuffer(length) {
      anInstance(this, $ArrayBuffer);
      return new BaseBuffer(toIndex(length));
    };
    var ArrayBufferProto = $ArrayBuffer[PROTOTYPE] = BaseBuffer[PROTOTYPE];
    for (var keys = gOPN(BaseBuffer), j = 0, key; keys.length > j;) {
      if (!((key = keys[j++]) in $ArrayBuffer)) hide($ArrayBuffer, key, BaseBuffer[key]);
    }
    if (!LIBRARY) ArrayBufferProto.constructor = $ArrayBuffer;
  }
  // iOS Safari 7.x bug
  var view = new $DataView(new $ArrayBuffer(2));
  var $setInt8 = $DataView[PROTOTYPE].setInt8;
  view.setInt8(0, 2147483648);
  view.setInt8(1, 2147483649);
  if (view.getInt8(0) || !view.getInt8(1)) redefineAll($DataView[PROTOTYPE], {
    setInt8: function setInt8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    },
    setUint8: function setUint8(byteOffset, value) {
      $setInt8.call(this, byteOffset, value << 24 >> 24);
    }
  }, true);
}
setToStringTag($ArrayBuffer, ARRAY_BUFFER);
setToStringTag($DataView, DATA_VIEW);
hide($DataView[PROTOTYPE], $typed.VIEW, true);
exports[ARRAY_BUFFER] = $ArrayBuffer;
exports[DATA_VIEW] = $DataView;


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var navigator = global.navigator;

module.exports = navigator && navigator.userAgent || '';


/***/ }),
/* 92 */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),
/* 93 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = !__webpack_require__(6) && !__webpack_require__(3)(function () {
  return Object.defineProperty(__webpack_require__(65)('div'), 'a', { get: function () { return 7; } }).a != 7;
});


/***/ }),
/* 94 */
/***/ (function(module, exports, __webpack_require__) {

exports.f = __webpack_require__(5);


/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

var has = __webpack_require__(11);
var toIObject = __webpack_require__(15);
var arrayIndexOf = __webpack_require__(51)(false);
var IE_PROTO = __webpack_require__(67)('IE_PROTO');

module.exports = function (object, names) {
  var O = toIObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~arrayIndexOf(result, key) || result.push(key);
  }
  return result;
};


/***/ }),
/* 96 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(7);
var anObject = __webpack_require__(1);
var getKeys = __webpack_require__(34);

module.exports = __webpack_require__(6) ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = getKeys(Properties);
  var length = keys.length;
  var i = 0;
  var P;
  while (length > i) dP.f(O, P = keys[i++], Properties[P]);
  return O;
};


/***/ }),
/* 97 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(15);
var gOPN = __webpack_require__(37).f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};


/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.2.1 Object.assign(target, source, ...)
var getKeys = __webpack_require__(34);
var gOPS = __webpack_require__(52);
var pIE = __webpack_require__(48);
var toObject = __webpack_require__(9);
var IObject = __webpack_require__(47);
var $assign = Object.assign;

// should work with symbols and should have deterministic property order (V8 bug)
module.exports = !$assign || __webpack_require__(3)(function () {
  var A = {};
  var B = {};
  // eslint-disable-next-line no-undef
  var S = Symbol();
  var K = 'abcdefghijklmnopqrst';
  A[S] = 7;
  K.split('').forEach(function (k) { B[k] = k; });
  return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
}) ? function assign(target, source) { // eslint-disable-line no-unused-vars
  var T = toObject(target);
  var aLen = arguments.length;
  var index = 1;
  var getSymbols = gOPS.f;
  var isEnum = pIE.f;
  while (aLen > index) {
    var S = IObject(arguments[index++]);
    var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
    var length = keys.length;
    var j = 0;
    var key;
    while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
  } return T;
} : $assign;


/***/ }),
/* 99 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var aFunction = __webpack_require__(10);
var isObject = __webpack_require__(4);
var invoke = __webpack_require__(100);
var arraySlice = [].slice;
var factories = {};

var construct = function (F, len, args) {
  if (!(len in factories)) {
    for (var n = [], i = 0; i < len; i++) n[i] = 'a[' + i + ']';
    // eslint-disable-next-line no-new-func
    factories[len] = Function('F,a', 'return new F(' + n.join(',') + ')');
  } return factories[len](F, args);
};

module.exports = Function.bind || function bind(that /* , ...args */) {
  var fn = aFunction(this);
  var partArgs = arraySlice.call(arguments, 1);
  var bound = function (/* args... */) {
    var args = partArgs.concat(arraySlice.call(arguments));
    return this instanceof bound ? construct(fn, args.length, args) : invoke(fn, args, that);
  };
  if (isObject(fn.prototype)) bound.prototype = fn.prototype;
  return bound;
};


/***/ }),
/* 100 */
/***/ (function(module, exports) {

// fast apply, http://jsperf.lnkit.com/fast-apply/5
module.exports = function (fn, args, that) {
  var un = that === undefined;
  switch (args.length) {
    case 0: return un ? fn()
                      : fn.call(that);
    case 1: return un ? fn(args[0])
                      : fn.call(that, args[0]);
    case 2: return un ? fn(args[0], args[1])
                      : fn.call(that, args[0], args[1]);
    case 3: return un ? fn(args[0], args[1], args[2])
                      : fn.call(that, args[0], args[1], args[2]);
    case 4: return un ? fn(args[0], args[1], args[2], args[3])
                      : fn.call(that, args[0], args[1], args[2], args[3]);
  } return fn.apply(that, args);
};


/***/ }),
/* 101 */
/***/ (function(module, exports, __webpack_require__) {

var $parseInt = __webpack_require__(2).parseInt;
var $trim = __webpack_require__(43).trim;
var ws = __webpack_require__(71);
var hex = /^[-+]?0[xX]/;

module.exports = $parseInt(ws + '08') !== 8 || $parseInt(ws + '0x16') !== 22 ? function parseInt(str, radix) {
  var string = $trim(String(str), 3);
  return $parseInt(string, (radix >>> 0) || (hex.test(string) ? 16 : 10));
} : $parseInt;


/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {

var $parseFloat = __webpack_require__(2).parseFloat;
var $trim = __webpack_require__(43).trim;

module.exports = 1 / $parseFloat(__webpack_require__(71) + '-0') !== -Infinity ? function parseFloat(str) {
  var string = $trim(String(str), 3);
  var result = $parseFloat(string);
  return result === 0 && string.charAt(0) == '-' ? -0 : result;
} : $parseFloat;


/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

var cof = __webpack_require__(19);
module.exports = function (it, msg) {
  if (typeof it != 'number' && cof(it) != 'Number') throw TypeError(msg);
  return +it;
};


/***/ }),
/* 104 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var isObject = __webpack_require__(4);
var floor = Math.floor;
module.exports = function isInteger(it) {
  return !isObject(it) && isFinite(it) && floor(it) === it;
};


/***/ }),
/* 105 */
/***/ (function(module, exports) {

// 20.2.2.20 Math.log1p(x)
module.exports = Math.log1p || function log1p(x) {
  return (x = +x) > -1e-8 && x < 1e-8 ? x - x * x / 2 : Math.log(1 + x);
};


/***/ }),
/* 106 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var sign = __webpack_require__(74);
var pow = Math.pow;
var EPSILON = pow(2, -52);
var EPSILON32 = pow(2, -23);
var MAX32 = pow(2, 127) * (2 - EPSILON32);
var MIN32 = pow(2, -126);

var roundTiesToEven = function (n) {
  return n + 1 / EPSILON - 1 / EPSILON;
};

module.exports = Math.fround || function fround(x) {
  var $abs = Math.abs(x);
  var $sign = sign(x);
  var a, result;
  if ($abs < MIN32) return $sign * roundTiesToEven($abs / MIN32 / EPSILON32) * MIN32 * EPSILON32;
  a = (1 + EPSILON32 / EPSILON) * $abs;
  result = a - (a - $abs);
  // eslint-disable-next-line no-self-compare
  if (result > MAX32 || result != result) return $sign * Infinity;
  return $sign * result;
};


/***/ }),
/* 107 */
/***/ (function(module, exports, __webpack_require__) {

// call something on iterator step with safe closing on error
var anObject = __webpack_require__(1);
module.exports = function (iterator, fn, value, entries) {
  try {
    return entries ? fn(anObject(value)[0], value[1]) : fn(value);
  // 7.4.6 IteratorClose(iterator, completion)
  } catch (e) {
    var ret = iterator['return'];
    if (ret !== undefined) anObject(ret.call(iterator));
    throw e;
  }
};


/***/ }),
/* 108 */
/***/ (function(module, exports, __webpack_require__) {

var aFunction = __webpack_require__(10);
var toObject = __webpack_require__(9);
var IObject = __webpack_require__(47);
var toLength = __webpack_require__(8);

module.exports = function (that, callbackfn, aLen, memo, isRight) {
  aFunction(callbackfn);
  var O = toObject(that);
  var self = IObject(O);
  var length = toLength(O.length);
  var index = isRight ? length - 1 : 0;
  var i = isRight ? -1 : 1;
  if (aLen < 2) for (;;) {
    if (index in self) {
      memo = self[index];
      index += i;
      break;
    }
    index += i;
    if (isRight ? index < 0 : length <= index) {
      throw TypeError('Reduce of empty array with no initial value');
    }
  }
  for (;isRight ? index >= 0 : length > index; index += i) if (index in self) {
    memo = callbackfn(memo, self[index], index, O);
  }
  return memo;
};


/***/ }),
/* 109 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)

var toObject = __webpack_require__(9);
var toAbsoluteIndex = __webpack_require__(35);
var toLength = __webpack_require__(8);

module.exports = [].copyWithin || function copyWithin(target /* = 0 */, start /* = 0, end = @length */) {
  var O = toObject(this);
  var len = toLength(O.length);
  var to = toAbsoluteIndex(target, len);
  var from = toAbsoluteIndex(start, len);
  var end = arguments.length > 2 ? arguments[2] : undefined;
  var count = Math.min((end === undefined ? len : toAbsoluteIndex(end, len)) - from, len - to);
  var inc = 1;
  if (from < to && to < from + count) {
    inc = -1;
    from += count - 1;
    to += count - 1;
  }
  while (count-- > 0) {
    if (from in O) O[to] = O[from];
    else delete O[to];
    to += inc;
    from += inc;
  } return O;
};


/***/ }),
/* 110 */
/***/ (function(module, exports) {

module.exports = function (done, value) {
  return { value: value, done: !!done };
};


/***/ }),
/* 111 */
/***/ (function(module, exports, __webpack_require__) {

// 21.2.5.3 get RegExp.prototype.flags()
if (__webpack_require__(6) && /./g.flags != 'g') __webpack_require__(7).f(RegExp.prototype, 'flags', {
  configurable: true,
  get: __webpack_require__(56)
});


/***/ }),
/* 112 */
/***/ (function(module, exports) {

module.exports = function (exec) {
  try {
    return { e: false, v: exec() };
  } catch (e) {
    return { e: true, v: e };
  }
};


/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {

var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var newPromiseCapability = __webpack_require__(89);

module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};


/***/ }),
/* 114 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(115);
var validate = __webpack_require__(45);
var MAP = 'Map';

// 23.1 Map Objects
module.exports = __webpack_require__(59)(MAP, function (get) {
  return function Map() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.1.3.6 Map.prototype.get(key)
  get: function get(key) {
    var entry = strong.getEntry(validate(this, MAP), key);
    return entry && entry.v;
  },
  // 23.1.3.9 Map.prototype.set(key, value)
  set: function set(key, value) {
    return strong.def(validate(this, MAP), key === 0 ? 0 : key, value);
  }
}, strong, true);


/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var dP = __webpack_require__(7).f;
var create = __webpack_require__(36);
var redefineAll = __webpack_require__(41);
var ctx = __webpack_require__(18);
var anInstance = __webpack_require__(39);
var forOf = __webpack_require__(40);
var $iterDefine = __webpack_require__(77);
var step = __webpack_require__(110);
var setSpecies = __webpack_require__(38);
var DESCRIPTORS = __webpack_require__(6);
var fastKey = __webpack_require__(29).fastKey;
var validate = __webpack_require__(45);
var SIZE = DESCRIPTORS ? '_s' : 'size';

var getEntry = function (that, key) {
  // fast case
  var index = fastKey(key);
  var entry;
  if (index !== 'F') return that._i[index];
  // frozen object case
  for (entry = that._f; entry; entry = entry.n) {
    if (entry.k == key) return entry;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;         // collection type
      that._i = create(null); // index
      that._f = undefined;    // first entry
      that._l = undefined;    // last entry
      that[SIZE] = 0;         // size
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.1.3.1 Map.prototype.clear()
      // 23.2.3.2 Set.prototype.clear()
      clear: function clear() {
        for (var that = validate(this, NAME), data = that._i, entry = that._f; entry; entry = entry.n) {
          entry.r = true;
          if (entry.p) entry.p = entry.p.n = undefined;
          delete data[entry.i];
        }
        that._f = that._l = undefined;
        that[SIZE] = 0;
      },
      // 23.1.3.3 Map.prototype.delete(key)
      // 23.2.3.4 Set.prototype.delete(value)
      'delete': function (key) {
        var that = validate(this, NAME);
        var entry = getEntry(that, key);
        if (entry) {
          var next = entry.n;
          var prev = entry.p;
          delete that._i[entry.i];
          entry.r = true;
          if (prev) prev.n = next;
          if (next) next.p = prev;
          if (that._f == entry) that._f = next;
          if (that._l == entry) that._l = prev;
          that[SIZE]--;
        } return !!entry;
      },
      // 23.2.3.6 Set.prototype.forEach(callbackfn, thisArg = undefined)
      // 23.1.3.5 Map.prototype.forEach(callbackfn, thisArg = undefined)
      forEach: function forEach(callbackfn /* , that = undefined */) {
        validate(this, NAME);
        var f = ctx(callbackfn, arguments.length > 1 ? arguments[1] : undefined, 3);
        var entry;
        while (entry = entry ? entry.n : this._f) {
          f(entry.v, entry.k, this);
          // revert to the last existing entry
          while (entry && entry.r) entry = entry.p;
        }
      },
      // 23.1.3.7 Map.prototype.has(key)
      // 23.2.3.7 Set.prototype.has(value)
      has: function has(key) {
        return !!getEntry(validate(this, NAME), key);
      }
    });
    if (DESCRIPTORS) dP(C.prototype, 'size', {
      get: function () {
        return validate(this, NAME)[SIZE];
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var entry = getEntry(that, key);
    var prev, index;
    // change existing entry
    if (entry) {
      entry.v = value;
    // create new entry
    } else {
      that._l = entry = {
        i: index = fastKey(key, true), // <- index
        k: key,                        // <- key
        v: value,                      // <- value
        p: prev = that._l,             // <- previous entry
        n: undefined,                  // <- next entry
        r: false                       // <- removed
      };
      if (!that._f) that._f = entry;
      if (prev) prev.n = entry;
      that[SIZE]++;
      // add to index
      if (index !== 'F') that._i[index] = entry;
    } return that;
  },
  getEntry: getEntry,
  setStrong: function (C, NAME, IS_MAP) {
    // add .keys, .values, .entries, [@@iterator]
    // 23.1.3.4, 23.1.3.8, 23.1.3.11, 23.1.3.12, 23.2.3.5, 23.2.3.8, 23.2.3.10, 23.2.3.11
    $iterDefine(C, NAME, function (iterated, kind) {
      this._t = validate(iterated, NAME); // target
      this._k = kind;                     // kind
      this._l = undefined;                // previous
    }, function () {
      var that = this;
      var kind = that._k;
      var entry = that._l;
      // revert to the last existing entry
      while (entry && entry.r) entry = entry.p;
      // get next entry
      if (!that._t || !(that._l = entry = entry ? entry.n : that._t._f)) {
        // or finish the iteration
        that._t = undefined;
        return step(1);
      }
      // return step by kind
      if (kind == 'keys') return step(0, entry.k);
      if (kind == 'values') return step(0, entry.v);
      return step(0, [entry.k, entry.v]);
    }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

    // add [@@species], 23.1.2.2, 23.2.2.2
    setSpecies(NAME);
  }
};


/***/ }),
/* 116 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var strong = __webpack_require__(115);
var validate = __webpack_require__(45);
var SET = 'Set';

// 23.2 Set Objects
module.exports = __webpack_require__(59)(SET, function (get) {
  return function Set() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.2.3.1 Set.prototype.add(value)
  add: function add(value) {
    return strong.def(validate(this, SET), value = value === 0 ? 0 : value, value);
  }
}, strong);


/***/ }),
/* 117 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var each = __webpack_require__(26)(0);
var redefine = __webpack_require__(13);
var meta = __webpack_require__(29);
var assign = __webpack_require__(98);
var weak = __webpack_require__(118);
var isObject = __webpack_require__(4);
var fails = __webpack_require__(3);
var validate = __webpack_require__(45);
var WEAK_MAP = 'WeakMap';
var getWeak = meta.getWeak;
var isExtensible = Object.isExtensible;
var uncaughtFrozenStore = weak.ufstore;
var tmp = {};
var InternalMap;

var wrapper = function (get) {
  return function WeakMap() {
    return get(this, arguments.length > 0 ? arguments[0] : undefined);
  };
};

var methods = {
  // 23.3.3.3 WeakMap.prototype.get(key)
  get: function get(key) {
    if (isObject(key)) {
      var data = getWeak(key);
      if (data === true) return uncaughtFrozenStore(validate(this, WEAK_MAP)).get(key);
      return data ? data[this._i] : undefined;
    }
  },
  // 23.3.3.5 WeakMap.prototype.set(key, value)
  set: function set(key, value) {
    return weak.def(validate(this, WEAK_MAP), key, value);
  }
};

// 23.3 WeakMap Objects
var $WeakMap = module.exports = __webpack_require__(59)(WEAK_MAP, wrapper, methods, weak, true, true);

// IE11 WeakMap frozen keys fix
if (fails(function () { return new $WeakMap().set((Object.freeze || Object)(tmp), 7).get(tmp) != 7; })) {
  InternalMap = weak.getConstructor(wrapper, WEAK_MAP);
  assign(InternalMap.prototype, methods);
  meta.NEED = true;
  each(['delete', 'has', 'get', 'set'], function (key) {
    var proto = $WeakMap.prototype;
    var method = proto[key];
    redefine(proto, key, function (a, b) {
      // store frozen objects on internal weakmap shim
      if (isObject(a) && !isExtensible(a)) {
        if (!this._f) this._f = new InternalMap();
        var result = this._f[key](a, b);
        return key == 'set' ? this : result;
      // store all the rest on native weakmap
      } return method.call(this, a, b);
    });
  });
}


/***/ }),
/* 118 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var redefineAll = __webpack_require__(41);
var getWeak = __webpack_require__(29).getWeak;
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var anInstance = __webpack_require__(39);
var forOf = __webpack_require__(40);
var createArrayMethod = __webpack_require__(26);
var $has = __webpack_require__(11);
var validate = __webpack_require__(45);
var arrayFind = createArrayMethod(5);
var arrayFindIndex = createArrayMethod(6);
var id = 0;

// fallback for uncaught frozen keys
var uncaughtFrozenStore = function (that) {
  return that._l || (that._l = new UncaughtFrozenStore());
};
var UncaughtFrozenStore = function () {
  this.a = [];
};
var findUncaughtFrozen = function (store, key) {
  return arrayFind(store.a, function (it) {
    return it[0] === key;
  });
};
UncaughtFrozenStore.prototype = {
  get: function (key) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) return entry[1];
  },
  has: function (key) {
    return !!findUncaughtFrozen(this, key);
  },
  set: function (key, value) {
    var entry = findUncaughtFrozen(this, key);
    if (entry) entry[1] = value;
    else this.a.push([key, value]);
  },
  'delete': function (key) {
    var index = arrayFindIndex(this.a, function (it) {
      return it[0] === key;
    });
    if (~index) this.a.splice(index, 1);
    return !!~index;
  }
};

module.exports = {
  getConstructor: function (wrapper, NAME, IS_MAP, ADDER) {
    var C = wrapper(function (that, iterable) {
      anInstance(that, C, NAME, '_i');
      that._t = NAME;      // collection type
      that._i = id++;      // collection id
      that._l = undefined; // leak store for uncaught frozen objects
      if (iterable != undefined) forOf(iterable, IS_MAP, that[ADDER], that);
    });
    redefineAll(C.prototype, {
      // 23.3.3.2 WeakMap.prototype.delete(key)
      // 23.4.3.3 WeakSet.prototype.delete(value)
      'delete': function (key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME))['delete'](key);
        return data && $has(data, this._i) && delete data[this._i];
      },
      // 23.3.3.4 WeakMap.prototype.has(key)
      // 23.4.3.4 WeakSet.prototype.has(value)
      has: function has(key) {
        if (!isObject(key)) return false;
        var data = getWeak(key);
        if (data === true) return uncaughtFrozenStore(validate(this, NAME)).has(key);
        return data && $has(data, this._i);
      }
    });
    return C;
  },
  def: function (that, key, value) {
    var data = getWeak(anObject(key), true);
    if (data === true) uncaughtFrozenStore(that).set(key, value);
    else data[that._i] = value;
    return that;
  },
  ufstore: uncaughtFrozenStore
};


/***/ }),
/* 119 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/ecma262/#sec-toindex
var toInteger = __webpack_require__(24);
var toLength = __webpack_require__(8);
module.exports = function (it) {
  if (it === undefined) return 0;
  var number = toInteger(it);
  var length = toLength(number);
  if (number !== length) throw RangeError('Wrong length!');
  return length;
};


/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {

// all object keys, includes non-enumerable and symbols
var gOPN = __webpack_require__(37);
var gOPS = __webpack_require__(52);
var anObject = __webpack_require__(1);
var Reflect = __webpack_require__(2).Reflect;
module.exports = Reflect && Reflect.ownKeys || function ownKeys(it) {
  var keys = gOPN.f(anObject(it));
  var getSymbols = gOPS.f;
  return getSymbols ? keys.concat(getSymbols(it)) : keys;
};


/***/ }),
/* 121 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-FlattenIntoArray
var isArray = __webpack_require__(53);
var isObject = __webpack_require__(4);
var toLength = __webpack_require__(8);
var ctx = __webpack_require__(18);
var IS_CONCAT_SPREADABLE = __webpack_require__(5)('isConcatSpreadable');

function flattenIntoArray(target, original, source, sourceLen, start, depth, mapper, thisArg) {
  var targetIndex = start;
  var sourceIndex = 0;
  var mapFn = mapper ? ctx(mapper, thisArg, 3) : false;
  var element, spreadable;

  while (sourceIndex < sourceLen) {
    if (sourceIndex in source) {
      element = mapFn ? mapFn(source[sourceIndex], sourceIndex, original) : source[sourceIndex];

      spreadable = false;
      if (isObject(element)) {
        spreadable = element[IS_CONCAT_SPREADABLE];
        spreadable = spreadable !== undefined ? !!spreadable : isArray(element);
      }

      if (spreadable && depth > 0) {
        targetIndex = flattenIntoArray(target, original, element, toLength(element.length), targetIndex, depth - 1) - 1;
      } else {
        if (targetIndex >= 0x1fffffffffffff) throw TypeError();
        target[targetIndex] = element;
      }

      targetIndex++;
    }
    sourceIndex++;
  }
  return targetIndex;
}

module.exports = flattenIntoArray;


/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-string-pad-start-end
var toLength = __webpack_require__(8);
var repeat = __webpack_require__(73);
var defined = __webpack_require__(23);

module.exports = function (that, maxLength, fillString, left) {
  var S = String(defined(that));
  var stringLength = S.length;
  var fillStr = fillString === undefined ? ' ' : String(fillString);
  var intMaxLength = toLength(maxLength);
  if (intMaxLength <= stringLength || fillStr == '') return S;
  var fillLen = intMaxLength - stringLength;
  var stringFiller = repeat.call(fillStr, Math.ceil(fillLen / fillStr.length));
  if (stringFiller.length > fillLen) stringFiller = stringFiller.slice(0, fillLen);
  return left ? stringFiller + S : S + stringFiller;
};


/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

var getKeys = __webpack_require__(34);
var toIObject = __webpack_require__(15);
var isEnum = __webpack_require__(48).f;
module.exports = function (isEntries) {
  return function (it) {
    var O = toIObject(it);
    var keys = getKeys(O);
    var length = keys.length;
    var i = 0;
    var result = [];
    var key;
    while (length > i) if (isEnum.call(O, key = keys[i++])) {
      result.push(isEntries ? [key, O[key]] : O[key]);
    } return result;
  };
};


/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var classof = __webpack_require__(49);
var from = __webpack_require__(125);
module.exports = function (NAME) {
  return function toJSON() {
    if (classof(this) != NAME) throw TypeError(NAME + "#toJSON isn't generic");
    return from(this);
  };
};


/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

var forOf = __webpack_require__(40);

module.exports = function (iter, ITERATOR) {
  var result = [];
  forOf(iter, false, result.push, result, ITERATOR);
  return result;
};


/***/ }),
/* 126 */
/***/ (function(module, exports) {

// https://rwaldron.github.io/proposal-math-extensions/
module.exports = Math.scale || function scale(x, inLow, inHigh, outLow, outHigh) {
  if (
    arguments.length === 0
      // eslint-disable-next-line no-self-compare
      || x != x
      // eslint-disable-next-line no-self-compare
      || inLow != inLow
      // eslint-disable-next-line no-self-compare
      || inHigh != inHigh
      // eslint-disable-next-line no-self-compare
      || outLow != outLow
      // eslint-disable-next-line no-self-compare
      || outHigh != outHigh
  ) return NaN;
  if (x === Infinity || x === -Infinity) return x;
  return (x - inLow) * (outHigh - outLow) / (inHigh - inLow) + outLow;
};


/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Polygon = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _point = __webpack_require__(64);

var _line = __webpack_require__(128);

var _rectangle = __webpack_require__(129);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Polygon = function () {
  function Polygon() {
    _classCallCheck(this, Polygon);

    for (var _len = arguments.length, points = Array(_len), _key = 0; _key < _len; _key++) {
      points[_key] = arguments[_key];
    }

    this.verticies = [].concat(points);
    this.size = this.verticies.length;
    this._AABB = null;
    this._AABB_DIRTY = true;
  }

  _createClass(Polygon, [{
    key: 'translate',
    value: function translate(x, y) {
      this._AABB_DIRTY = true;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.verticies[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var vertex = _step.value;

          vertex.x += x;
          vertex.y += y;
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    }
  }, {
    key: 'rotate',
    value: function rotate(pt, rad) {
      this._AABB_DIRTY = true;
      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = this.verticies[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var vertex = _step2.value;

          var x = vertex.x - pt.x;
          var y = vertex.y - pt.y;
          var rotx = Math.cos(rad);
          var roty = Math.sin(rad);
          var dx = x * rotx - y * roty;
          var dy = x * roty + y * rotx;
          vertex.x = pt.x + dx;
          vertex.y = pt.y + dy;
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }
    }
  }, {
    key: 'rotateDeg',
    value: function rotateDeg(pt, deg) {
      this.rotate(pt, (0, _point.degToRad)(deg));
    }
  }, {
    key: 'perimeter',
    value: function perimeter() {
      var p = 0;
      for (var i = 0; i < this.verticies.length; i++) {
        var j = (i + 1) % this.size;
        var p1 = this.verticies[i];
        var p2 = this.verticies[j];
        p += (0, _point.distance)(p1, p2);
      }
      return p;
    }

    // Returns both the min x and y value of polygon

  }, {
    key: 'minPoints',
    value: function minPoints() {
      var minX = Infinity;
      var minY = Infinity;
      for (var i = this.verticies.length - 1; i >= 0; i--) {
        minX = Math.min(this.verticies[i].x, minX);
        minY = Math.min(this.verticies[i].y, minY);
      }
      return (0, _point.pt)(minX, minY);
    }

    // Returns both the minimum and maximum elements of a polygon

  }, {
    key: 'maxPoints',
    value: function maxPoints() {
      var maxX = -Infinity;
      var maxY = -Infinity;
      for (var i = this.verticies.length - 1; i >= 0; i--) {
        maxX = Math.max(this.verticies[i].x, maxX);
        maxY = Math.max(this.verticies[i].y, maxY);
      }
      return (0, _point.pt)(maxX, maxY);
    }
  }, {
    key: 'AABB',
    value: function AABB() {
      if (!this._AABB_DIRTY && this._AABB) {
        return this._AABB;
      }
      var min = this.minPoints();
      var max = this.maxPoints();
      this._AABB = new _rectangle.Rectangle(min.x, min.y, max.x - min.x, max.y - min.y);
      return this._AABB;
    }

    // Returns the verticies of polygon as if it were located at (0, 0)

  }, {
    key: 'fromZero',
    value: function fromZero() {
      var min = (0, _point.scalar)(this.minPoints(), -1);
      var verticies = [];
      this.verticies.forEach(function (v) {
        verticies.push((0, _point.sum)(v, min));
      });
      return verticies;
    }
  }, {
    key: 'center',
    value: function center() {
      var sumValue = (0, _point.pt)(0, 0);
      var _iteratorNormalCompletion3 = true;
      var _didIteratorError3 = false;
      var _iteratorError3 = undefined;

      try {
        for (var _iterator3 = this.verticies[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
          var vertex = _step3.value;

          sumValue = (0, _point.sum)(vertex, sumValue);
        }
      } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion3 && _iterator3.return) {
            _iterator3.return();
          }
        } finally {
          if (_didIteratorError3) {
            throw _iteratorError3;
          }
        }
      }

      sumValue.x /= this.verticies.length;
      sumValue.y /= this.verticies.length;
      return sumValue;
    }
  }, {
    key: 'centerOfMass',
    value: function centerOfMass() {
      // X = SUM[(Xi + Xi+1) * (Xi * Yi+1 - Xi+1 * Yi)] / 6 / A
      // Y = SUM[(Yi + Yi+1) * (Xi * Yi+1 - Xi+1 * Yi)] / 6 / A
      var center = (0, _point.pt)(0, 0);
      var area = Math.abs(this.area());
      var min = this.minPoints();
      // Need to normalize from 0
      var zerod = this.fromZero();
      for (var i = 0; i < zerod.length - 1; i++) {
        var p0 = zerod[i];
        var p1 = zerod[i + 1];
        var normalizingConstant = p0.x * p1.y - p1.x * p0.y;
        center.x += (p0.x + p1.x) * normalizingConstant;
        center.y += (p0.y + p1.y) * normalizingConstant;
      }
      center.x = center.x / (6 * area) + min.x;
      center.y = center.y / (6 * area) + min.y;
      return center;
    }
  }, {
    key: 'area',
    value: function area() {
      // area += poly[i].x * (poly[prev(i, n)].y - poly[next(i, n)].y);
      var a = 0;
      for (var i = 0; i < this.verticies.length; i++) {
        var j = (i + 1) % this.size;
        var k = (i - 1 + this.size) % this.size;
        var p0 = this.verticies[k];
        var p1 = this.verticies[i];
        var p2 = this.verticies[j];
        a += p1.x * (p0.y - p2.y);
      }
      return a / 2;
    }
  }, {
    key: 'convex',
    value: function convex() {
      var isLeft = (0, _point.ccw)(this.verticies[0], this.verticies[1], this.verticies[2]);
      for (var i = 0; i < this.size - 1; i++) {
        var j = (i + 1) % this.size;
        var k = (i + 2) % this.size;
        var p0 = this.verticies[i];
        var p1 = this.verticies[j];
        var p2 = this.verticies[k];
        if ((0, _point.ccw)(p0, p1, p2) !== isLeft) {
          return false;
        }
      }
      return true;
    }
  }, {
    key: 'intersectsPt',
    value: function intersectsPt(pt) {
      var c = false;
      for (var i = -1, l = this.verticies.length, j = l - 1; ++i < l; j = i) {
        var p0 = this.verticies[i];
        var p1 = this.verticies[j];
        /* eslint-disable no-unused-vars */
        // Have to set this to a dummy variable due to bad babel translations/syntax?
        var int = (p0.y <= pt.y && pt.y < p1.y || p1.y <= pt.y && pt.y < p0.y) && pt.x < (p1.x - p0.x) * (pt.y - p0.y) / (p1.y - p0.y) + p0.x && (c = !c);
        /* eslint-enable no-unused-vars */
      }
      return c;
    }
  }, {
    key: 'intersectsSegment',
    value: function intersectsSegment(seg) {
      for (var i = 0, j = 1, size = this.size; i < size; i++, j = (i + 1) % size) {
        var p0 = this.verticies[i];
        var p1 = this.verticies[j];
        var p2 = seg.p0;
        var p3 = seg.p1;
        var intersectsPt = (0, _line.segmentIntersectsSegment)(p0, p1, p2, p3);
        if (intersectsPt) {
          return intersectsPt;
        }
      }
      return this.intersectsPt(seg.p0);
    }

    // Fix later using SAT

  }, {
    key: '_seperatingAxis',
    value: function _seperatingAxis(projectionAxis, poly0, poly1) {
      var min1 = Infinity;
      var min2 = Infinity;
      var max1 = -Infinity;
      var max2 = -Infinity;

      var _iteratorNormalCompletion4 = true;
      var _didIteratorError4 = false;
      var _iteratorError4 = undefined;

      try {
        for (var _iterator4 = poly0[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
          var vertex = _step4.value;

          var projection = (0, _point.dot)(vertex, projectionAxis);
          min1 = Math.min(min1, projection);
          max1 = Math.max(max1, projection);
        }
      } catch (err) {
        _didIteratorError4 = true;
        _iteratorError4 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion4 && _iterator4.return) {
            _iterator4.return();
          }
        } finally {
          if (_didIteratorError4) {
            throw _iteratorError4;
          }
        }
      }

      var _iteratorNormalCompletion5 = true;
      var _didIteratorError5 = false;
      var _iteratorError5 = undefined;

      try {
        for (var _iterator5 = poly1[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
          var _vertex = _step5.value;

          var _projection = (0, _point.dot)(_vertex, projectionAxis);
          min2 = Math.min(min2, _projection);
          max2 = Math.max(max2, _projection);
        }
      } catch (err) {
        _didIteratorError5 = true;
        _iteratorError5 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion5 && _iterator5.return) {
            _iterator5.return();
          }
        } finally {
          if (_didIteratorError5) {
            throw _iteratorError5;
          }
        }
      }

      if (max1 >= min2 && max2 >= min1) {
        // const d = Math.min(max2 - min1, max1 - min2)
        // const pv = d/dot(projectionAxis, projectionAxis) + 1e-10)
        /*
          d_over_o_squared = d/np.dot(o, o) + 1e-10
          pv = d_over_o_squared*o
          return False, pv
        */
        return false;
      } else {
        return true;
      }
    }
  }, {
    key: 'intersectsConvexPoly',
    value: function intersectsConvexPoly(poly) {
      // get edges
      for (var i = 0, j = 1; i < this.size; i++, j = (i + 1) % this.size) {
        var p0 = this.verticies[i];
        var p1 = this.verticies[j];
        var edge = (0, _point.sub)(p1, p0);
        var orth = (0, _point.orthoginal)(edge);
        var sep = this._seperatingAxis(orth, this.verticies, poly.verticies);
        if (sep) {
          return false;
        }
      }

      for (var _i = 0, _j = 1; _i < poly.size; _i++, _j = (_i + 1) % poly.size) {
        var _p = poly.verticies[_i];
        var _p2 = poly.verticies[_j];
        var _edge = (0, _point.sub)(_p2, _p);
        var _orth = (0, _point.orthoginal)(_edge);
        var _sep = this._seperatingAxis(_orth, this.verticies, poly.verticies);
        if (_sep) {
          return false;
        }
      }
      return true;
    }
  }, {
    key: 'intersectsConcavePoly',
    value: function intersectsConcavePoly(poly) {
      for (var i = 0, j = 1, size = this.size; i < size; i++, j = (i + 1) % size) {
        var p0 = this.verticies[i];
        var p1 = this.verticies[j];
        for (var x = 0, y = 1, psize = poly.size; x < psize; x++, y = (x + 1) % psize) {
          var p2 = poly.verticies[x];
          var p3 = poly.verticies[y];
          var intersectsPt = (0, _line.segmentIntersectsSegment)(p0, p1, p2, p3);
          if (intersectsPt) {
            return intersectsPt;
          }
        }
      }

      return poly.intersectsPt(this.verticies[0]);
    }

    // Generates a convex hull of the polygon. Not optimized for speed

  }, {
    key: 'generateConvexHull',
    value: function generateConvexHull() {
      var hull = [];
      // Find min x value in poly
      var xmin = this.verticies.reduce(function (a, b) {
        if (Math.min(a.x, b.x) === a.x) {
          return a;
        } else {
          return b;
        }
      }, (0, _point.pt)(Infinity, Infinity));
      // let y = this.verticies.reduce((a, b) => pt(0, Math.min(a.y, b.y)), pt(Infinity, Infinity))

      // find max x value in poly
      var xmax = this.verticies.reduce(function (a, b) {
        if (Math.max(a.x, b.x) === a.x) {
          return a;
        } else {
          return b;
        }
      }, (0, _point.pt)(-Infinity, -Infinity));

      this._findHull(hull, xmin, xmax, 1);
      this._findHull(hull, xmin, xmax, -1);

      // Need to sort points w/ respect to original poly
      var sortedHull = [];
      for (var i = 0; i < this.verticies.length; i++) {
        var v = this.verticies[i];
        for (var j = 0; j < hull.length; j++) {
          var h = hull[j];
          if (h.x === v.x && h.y === v.y) {
            sortedHull.push(h);
            break;
          }
        }
      }
      return new (Function.prototype.bind.apply(Polygon, [null].concat(sortedHull)))();
    }
  }, {
    key: '_findSide',
    value: function _findSide(p1, p2, p) {
      var dist = (p.y - p1.y) * (p2.x - p1.x) - (p2.y - p1.y) * (p.x - p1.x);

      if (dist > 0) {
        return 1;
      }
      if (dist < 0) {
        return -1;
      }
      return 0;
    }
  }, {
    key: '_lineDist',
    value: function _lineDist(p1, p2, p) {
      return Math.abs((p.y - p1.y) * (p2.x - p1.x) - (p2.y - p1.y) * (p.x - p1.x));
    }
  }, {
    key: '_findHull',
    value: function _findHull(hull, xmin, xmax, side) {
      // Find the furthest point from the line from xmin -> xmax
      var largestDist = 0;
      var largestIndex = -1;
      for (var i = 0; i < this.verticies.length; i++) {
        var v = this.verticies[i];
        var dist = this._lineDist(xmin, xmax, v);
        if (dist > largestDist && this._findSide(xmin, xmax, v) === side) {
          largestDist = dist;
          largestIndex = i;
        }
      }

      if (largestIndex === -1) {
        hull.push(xmin, xmax);
        return;
      }

      var c = this.verticies[largestIndex];
      this._findHull(hull, c, xmin, -this._findSide(c, xmin, xmax));
      this._findHull(hull, c, xmax, -this._findSide(c, xmax, xmin));
    }
  }]);

  return Polygon;
}();

exports.Polygon = Polygon;

/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.segmentIntersectsSegment = exports.slope = exports.Ray = exports.Segment = exports.Line = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _point = __webpack_require__(64);

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var slope = function slope(p0, p1) {
  return (p0.y - p1.y) / (p0.x - p1.x);
};

var Line = function () {
  // Takes two points as a line segment.
  function Line(p0, p1) {
    _classCallCheck(this, Line);

    this.p0 = p0;
    // Default line point up
    if (!p1) {
      p1 = (0, _point.pt)(p0.x, p0.y - 0.01);
    }
    this.p1 = p1;
  }

  _createClass(Line, [{
    key: 'intersectsLine',
    value: function intersectsLine(line) {
      var A0 = this.p1.y - this.p0.y;
      var B0 = this.p0.x - this.p1.x;
      var C0 = A0 * this.p0.x + B0 * this.p0.y;

      var A1 = line.p1.y - line.p0.y;
      var B1 = line.p0.x - line.p1.x;
      var C1 = A1 * line.p0.x + B1 * line.p0.y;
      var denom = A0 * B1 - A1 * B0;
      return (0, _point.pt)((B1 * C0 - B0 * C1) / denom, (A0 * C1 - A1 * C0) / denom);
    }
  }, {
    key: 'intersectsSegment',
    value: function intersectsSegment(seg) {
      var A0 = this.p1.y - this.p0.y;
      var B0 = this.p0.x - this.p1.x;
      var C0 = A0 * this.p0.x + B0 * this.p0.y;

      var A1 = seg.p1.y - seg.p0.y;
      var B1 = seg.p0.x - seg.p1.x;
      var C1 = A1 * seg.p0.x + B1 * seg.p0.y;
      var denom = A0 * B1 - A1 * B0;
      if (denom === 0) {
        return null;
      }
      var intersectX = (B1 * C0 - B0 * C1) / denom;
      var intersectY = (A0 * C1 - A1 * C0) / denom;
      // let r0x = (intersectX - this.p0.x) / (this.p1.x - this.p0.x)
      // let r0y = (intersectY - this.p0.y) / (this.p1.y - this.p0.y)
      var r1x = (intersectX - seg.p0.x) / (seg.p1.x - seg.p0.x);
      var r1y = (intersectY - seg.p0.y) / (seg.p1.y - seg.p0.y);
      if (r1x >= 0 && r1x <= 1 || r1y >= 0 && r1y <= 1) {
        return (0, _point.pt)(intersectX, intersectY);
      }
      return null;
    }
  }, {
    key: 'rotate',
    value: function rotate(rad) {
      // getting the distance of each component
      var x = this.p1.x - this.p0.x;
      var y = this.p1.y - this.p0.y;
      // find the rotated point from the origin and multiply
      // it by the size of each component to get the new offset
      // from p0 to p1
      var rotx = Math.cos(rad);
      var roty = Math.sin(rad);
      var dx = x * rotx - y * roty;
      var dy = x * roty + y * rotx;
      // add the rotated points to the root
      this.p1.x = this.p0.x + dx;
      this.p1.y = this.p0.y + dy;
    }
  }, {
    key: 'rotateDeg',
    value: function rotateDeg(deg) {
      this.rotate((0, _point.degToRad)(deg));
    }
  }, {
    key: 'translate',
    value: function translate(x, y) {
      this.p1.x = this.p1.x - this.p0.x + x;
      this.p1.y = this.p1.y - this.p0.y + y;
      this.p0.x = x;
      this.p0.y = y;
    }
  }, {
    key: 'pointAt',
    value: function pointAt(x, y) {
      var dx = this.p0.x - x;
      var dy = this.p1.y - y;
      this.p1.x = this.p0.x - dx / 100;
      this.p1.y = this.p0.y - dy / 100;
    }
  }]);

  return Line;
}();

var Segment = function (_Line) {
  _inherits(Segment, _Line);

  function Segment() {
    _classCallCheck(this, Segment);

    return _possibleConstructorReturn(this, (Segment.__proto__ || Object.getPrototypeOf(Segment)).apply(this, arguments));
  }

  _createClass(Segment, [{
    key: 'intersectsLine',
    value: function intersectsLine(ln) {
      var A0 = this.p1.y - this.p0.y;
      var B0 = this.p0.x - this.p1.x;
      var C0 = A0 * this.p0.x + B0 * this.p0.y;

      var A1 = ln.p1.y - ln.p0.y;
      var B1 = ln.p0.x - ln.p1.x;
      var C1 = A1 * ln.p0.x + B1 * ln.p0.y;
      var denom = A0 * B1 - A1 * B0;
      if (denom === 0) {
        return null;
      }
      var intersectX = (B1 * C0 - B0 * C1) / denom;
      var intersectY = (A0 * C1 - A1 * C0) / denom;
      var r0x = (intersectX - this.p0.x) / (this.p1.x - this.p0.x);
      var r0y = (intersectY - this.p0.y) / (this.p1.y - this.p0.y);
      // let r1x = (intersectX - ln.p0.x) / (ln.p1.x - ln.p0.x)
      // let r1y = (intersectY - ln.p0.y) / (ln.p1.y - ln.p0.y)
      if (r0x >= 0 && r0x <= 1 || r0y >= 0 && r0y <= 1) {
        return (0, _point.pt)(intersectX, intersectY);
      }
      return null;
    }
  }, {
    key: 'intersectsSegment',
    value: function intersectsSegment(seg) {
      var A0 = this.p1.y - this.p0.y;
      var B0 = this.p0.x - this.p1.x;
      var C0 = A0 * this.p0.x + B0 * this.p0.y;

      var A1 = seg.p1.y - seg.p0.y;
      var B1 = seg.p0.x - seg.p1.x;
      var C1 = A1 * seg.p0.x + B1 * seg.p0.y;
      var denom = A0 * B1 - A1 * B0;
      if (denom === 0) {
        return null;
      }
      var intersectX = (B1 * C0 - B0 * C1) / denom;
      var intersectY = (A0 * C1 - A1 * C0) / denom;

      var r0x = (intersectX - this.p0.x) / (this.p1.x - this.p0.x);
      var r0y = (intersectY - this.p0.y) / (this.p1.y - this.p0.y);
      var r1x = (intersectX - seg.p0.x) / (seg.p1.x - seg.p0.x);
      var r1y = (intersectY - seg.p0.y) / (seg.p1.y - seg.p0.y);
      if ((r1x >= 0 && r1x <= 1 || r1y >= 0 && r1y <= 1) && (r0x >= 0 && r0x <= 1 || r0y >= 0 && r0y <= 1)) {
        return (0, _point.pt)(intersectX, intersectY);
      }
      return null;
    }
  }]);

  return Segment;
}(Line);

var Ray = function (_Line2) {
  _inherits(Ray, _Line2);

  function Ray() {
    _classCallCheck(this, Ray);

    return _possibleConstructorReturn(this, (Ray.__proto__ || Object.getPrototypeOf(Ray)).apply(this, arguments));
  }

  _createClass(Ray, [{
    key: 'intersectsSegment',
    value: function intersectsSegment(seg) {
      var A0 = this.p1.y - this.p0.y;
      var B0 = this.p0.x - this.p1.x;
      var C0 = A0 * this.p0.x + B0 * this.p0.y;

      var A1 = seg.p1.y - seg.p0.y;
      var B1 = seg.p0.x - seg.p1.x;
      var C1 = A1 * seg.p0.x + B1 * seg.p0.y;
      var denom = A0 * B1 - A1 * B0;
      if (denom === 0) {
        return null;
      }
      var intersectX = (B1 * C0 - B0 * C1) / denom;
      var intersectY = (A0 * C1 - A1 * C0) / denom;
      var dist1X = Math.abs(intersectX - this.p1.x);
      var dist1Y = Math.abs(intersectY - this.p1.y);
      var dist0X = Math.abs(intersectX - this.p0.x);
      var dist0Y = Math.abs(intersectY - this.p0.y);
      // console.log(dist1X, dist1Y)
      // console.log(dist0X, dist0Y)
      if (dist1X > dist0X || dist1Y > dist0Y) {
        return null;
      }
      // let r0x = (intersectX - this.p0.x) / (this.p1.x - this.p0.x)
      // let r0y = (intersectY - this.p0.y) / (this.p1.y - this.p0.y)
      var r1x = (intersectX - seg.p0.x) / (seg.p1.x - seg.p0.x);
      var r1y = (intersectY - seg.p0.y) / (seg.p1.y - seg.p0.y);
      if (r1x >= 0 && r1x <= 1 || r1y >= 0 && r1y <= 1) {
        return (0, _point.pt)(intersectX, intersectY);
      }
      return null;
    }

    // Decomposes intersectsSeg, used in poly to save allocs

  }, {
    key: 'intersectsLine',
    value: function intersectsLine(p0, p1) {
      var A0 = this.p1.y - this.p0.y;
      var B0 = this.p0.x - this.p1.x;
      var C0 = A0 * this.p0.x + B0 * this.p0.y;

      var A1 = p1.y - p0.y;
      var B1 = p0.x - p1.x;
      var C1 = A1 * p0.x + B1 * p0.y;
      var denom = A0 * B1 - A1 * B0;
      if (denom === 0) {
        return null;
      }
      var intersectX = (B1 * C0 - B0 * C1) / denom;
      var intersectY = (A0 * C1 - A1 * C0) / denom;
      var dist1X = Math.abs(intersectX - this.p1.x);
      var dist1Y = Math.abs(intersectY - this.p1.y);
      var dist0X = Math.abs(intersectX - this.p0.x);
      var dist0Y = Math.abs(intersectY - this.p0.y);
      if (dist1X > dist0X || dist1Y > dist0Y) {
        return null;
      }
      // let r0x = (intersectX - this.p0.x) / (this.p1.x - this.p0.x)
      // let r0y = (intersectY - this.p0.y) / (this.p1.y - this.p0.y)
      var r1x = (intersectX - p0.x) / (p1.x - p0.x);
      var r1y = (intersectY - p0.y) / (p1.y - p0.y);
      if (r1x >= 0 && r1x <= 1 || r1y >= 0 && r1y <= 1) {
        return (0, _point.pt)(intersectX, intersectY);
      }
      return null;
    }
  }, {
    key: 'intersectsPoly',
    value: function intersectsPoly(poly) {
      var intersect = null;
      var maxDistance = Infinity;
      for (var i = 0, j = 1; i < poly.size; i++, j = (i + 1) % poly.size) {
        var p0 = poly.verticies[i];
        var p1 = poly.verticies[j];
        var collision = this.intersectsLine(p0, p1);
        if (!collision) continue;
        var dist = (0, _point.distance)(this.p0, collision);
        if (intersect === null) {
          intersect = collision;
          maxDistance = dist;
        } else if (dist < maxDistance) {
          maxDistance = dist;
          intersect = collision;
        }
      }
      return intersect;
    }
  }]);

  return Ray;
}(Line);

var segmentIntersectsSegment = function segmentIntersectsSegment(p0, p1, p2, p3) {
  var A0 = p1.y - p0.y;
  var B0 = p0.x - p1.x;
  var C0 = A0 * p0.x + B0 * p0.y;

  var A1 = p3.y - p2.y;
  var B1 = p2.x - p3.x;
  var C1 = A1 * p2.x + B1 * p2.y;
  var denom = A0 * B1 - A1 * B0;
  if (denom === 0) {
    return null;
  }
  var intersectX = (B1 * C0 - B0 * C1) / denom;
  var intersectY = (A0 * C1 - A1 * C0) / denom;

  var r0x = (intersectX - p0.x) / (p1.x - p0.x);
  var r0y = (intersectY - p0.y) / (p1.y - p0.y);
  var r1x = (intersectX - p2.x) / (p3.x - p2.x);
  var r1y = (intersectY - p2.y) / (p3.y - p2.y);
  if ((r1x >= 0 && r1x <= 1 || r1y >= 0 && r1y <= 1) && (r0x >= 0 && r0x <= 1 || r0y >= 0 && r0y <= 1)) {
    return (0, _point.pt)(intersectX, intersectY);
  }
  return null;
};

exports.Line = Line;
exports.Segment = Segment;
exports.Ray = Ray;
exports.slope = slope;
exports.segmentIntersectsSegment = segmentIntersectsSegment;

/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.rectToPolygon = exports.Square = exports.Rectangle = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _point = __webpack_require__(64);

var _polygon = __webpack_require__(127);

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Rectangle = function () {
  function Rectangle(x, y, width, height) {
    _classCallCheck(this, Rectangle);

    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  _createClass(Rectangle, [{
    key: 'intersectsRect',
    value: function intersectsRect(box) {
      var rect1x = this.x;
      var rect1y = this.y;
      var rect1w = this.width;
      var rect1h = this.height;
      var rect2x = box.x;
      var rect2y = box.y;
      var rect2w = box.width;
      var rect2h = box.height;
      return rect1x + rect1w > rect2x && rect1x < rect2x + rect2w && rect1y + rect1h > rect2y && rect1y < rect2y + rect2h;
    }
  }, {
    key: 'intersectsPt',
    value: function intersectsPt(pt) {
      var rect1x = this.x;
      var rect1y = this.y;
      var rect1w = this.width;
      var rect1h = this.height;
      var rect2x = pt.x;
      var rect2y = pt.y;
      var rect2w = 1;
      var rect2h = 1;
      return rect1x + rect1w > rect2x && rect1x < rect2x + rect2w && rect1y + rect1h > rect2y && rect1y < rect2y + rect2h;
    }
  }, {
    key: 'center',
    value: function center() {
      return (0, _point.pt)(this.x + this.width / 2, this.y + this.height / 2);
    }
  }]);

  return Rectangle;
}();

// OOP so why not


var Square = function (_Rectangle) {
  _inherits(Square, _Rectangle);

  function Square(x, y, side) {
    _classCallCheck(this, Square);

    return _possibleConstructorReturn(this, (Square.__proto__ || Object.getPrototypeOf(Square)).call(this, x, y, side, side));
  }

  return Square;
}(Rectangle);

var rectToPolygon = function rectToPolygon(x, y, width, height) {
  var topLeft = (0, _point.pt)(x, y);
  var topRight = (0, _point.pt)(x + width, y);
  var bottomRight = (0, _point.pt)(x + width, y + height);
  var bottomLeft = (0, _point.pt)(x, y + height);
  return new _polygon.Polygon(topLeft, topRight, bottomRight, bottomLeft);
};

exports.Rectangle = Rectangle;
exports.Square = Square;
exports.rectToPolygon = rectToPolygon;

/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var KEY_UP = exports.KEY_UP = 38;
var KEY_DOWN = exports.KEY_DOWN = 40;
var KEY_LEFT = exports.KEY_LEFT = 37;
var KEY_RIGHT = exports.KEY_RIGHT = 39;
var CTRL = exports.CTRL = 17;
var META = exports.META = 91;
var SHIFT = exports.SHIFT = 16;
var Q = exports.Q = 81;
var W = exports.W = 87;
var E = exports.E = 69;
var R = exports.R = 82;
var T = exports.T = 84;
var Y = exports.Y = 89;
var A = exports.A = 65;
var S = exports.S = 83;
var D = exports.D = 68;
var F = exports.F = 70;
var G = exports.G = 71;
var H = exports.H = 72;
var Z = exports.Z = 90;
var X = exports.X = 88;
var C = exports.C = 67;
var V = exports.V = 86;
var B = exports.B = 66;
var N = exports.N = 78;
var SPACE = exports.SPACE = 32;
var ENTER = exports.ENTER = 13;
var ZERO = exports.ZERO = 48;
var ONE = exports.ONE = 49;
var TWO = exports.TWO = 50;
var THREE = exports.THREE = 51;
var FOUR = exports.FOUR = 52;
var FIVE = exports.FIVE = 53;
var SIX = exports.SIX = 54;
var SEVEN = exports.SEVEN = 55;
var EIGHT = exports.EIGHT = 56;
var NINE = exports.NINE = 57;
var ESC = exports.ESC = 27;

/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.drawBox = exports.drawRay = exports.drawSegment = exports.drawLine = exports.drawPolyLine = exports.drawPolygon = undefined;

var _math = __webpack_require__(46);

var drawPolygon = function drawPolygon(c, poly) {
  var color = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '#f00';
  var bg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '#00a';
  var showBox = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;

  if (showBox) {
    c.fillStyle = bg;
    var box = poly.AABB();
    c.fillRect(box.x, box.y, box.width, box.height);
  }
  c.fillStyle = color;
  c.strokeStyle = 'white';
  c.beginPath();
  c.moveTo(poly.verticies[0].x, poly.verticies[0].y);
  // c.fillRect(poly.verticies[0].x - 1, poly.verticies[0].y - 1, 3, 3)
  for (var i = 1; i < poly.verticies.length; i++) {
    var vertex = poly.verticies[i];
    c.lineTo(vertex.x, vertex.y);
    // c.fillRect(vertex.x - 1, vertex.y - 1, 3, 3)
  }
  c.lineTo(poly.verticies[0].x, poly.verticies[0].y);
  c.closePath();
  c.fill();
  c.stroke();
  if (showBox) {
    var center = poly.AABB().center();
    c.fillStyle = 'black';
    c.fillRect(center.x - 1, center.y - 1, 3, 3);
  }
};

var drawPolyLine = function drawPolyLine(c, polyLine) {
  var color = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '#fff';
  var bg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '#f00';

  for (var i = 0, j = 1; j < polyLine.length; i++, j++) {
    var p0 = polyLine[i];
    var p1 = polyLine[j];
    var seg = new _math.Segment(p0.point.position, p1.point.position);
    drawSegment(c, seg, color, bg);
  }
};

var drawLine = function drawLine(c, line) {
  var color = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '#fff';
  var bg = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '#f00';

  // Before
  c.strokeStyle = bg;
  c.beginPath();
  c.moveTo(line.p0.x, line.p0.y);
  c.lineTo(line.p0.x - (line.p1.x - line.p0.x) * 0xffff, line.p0.y - (line.p1.y - line.p0.y) * 0xffff);
  c.closePath();
  c.stroke();
  // Segment
  c.strokeStyle = color;
  c.beginPath();
  c.moveTo(line.p0.x, line.p0.y);
  c.lineTo(line.p1.x, line.p1.y);
  c.closePath();
  c.stroke();
  // Afters
  c.strokeStyle = bg;
  c.beginPath();
  c.moveTo(line.p1.x, line.p1.y);
  c.lineTo(line.p1.x + (line.p1.x - line.p0.x) * 0xffffffff, line.p1.y + (line.p1.y - line.p0.y) * 0xffffffff);
  c.closePath();
  c.stroke();
};

var drawSegment = function drawSegment(c, seg) {
  var color = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '#fff';
  var fill = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '#f00';
  var width = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 3;

  c.strokeStyle = color;
  c.lineWidth = width;
  c.beginPath();
  c.moveTo(seg.p0.x, seg.p0.y);
  c.lineTo(seg.p1.x, seg.p1.y);
  c.closePath();
  c.stroke();
  c.fillStyle = fill;
  c.fillRect(seg.p0.x - 1, seg.p0.y - 1, 3, 3);
  c.fillRect(seg.p1.x - 1, seg.p1.y - 1, 3, 3);
};

var drawRay = function drawRay(c, seg) {
  var color = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '#fff';
  var fill = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '#f00';

  c.strokeStyle = color;
  c.beginPath();
  c.moveTo(seg.p0.x, seg.p0.y);
  c.lineTo(seg.p1.x, seg.p1.y);
  c.closePath();
  c.stroke();
  c.fillStyle = fill;
  c.fillRect(seg.p0.x - 1, seg.p0.y - 1, 3, 3);

  c.strokeStyle = fill;
  c.beginPath();
  c.moveTo(seg.p1.x, seg.p1.y);
  c.lineTo(seg.p1.x + (seg.p1.x - seg.p0.x) * 0xffff, seg.p1.y + (seg.p1.y - seg.p0.y) * 0xffff);
  c.closePath();
  c.stroke();
};

var drawBox = function drawBox(c, box) {
  var color = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '#fff';

  var _fill = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '#f00';

  c.fillStyle = color;
  c.fillRect(box.x, box.y, box.width, box.height);
};

exports.drawPolygon = drawPolygon;
exports.drawPolyLine = drawPolyLine;
exports.drawLine = drawLine;
exports.drawSegment = drawSegment;
exports.drawRay = drawRay;
exports.drawBox = drawBox;

/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var DOMMock = function () {
  function DOMMock() {
    _classCallCheck(this, DOMMock);
  }

  _createClass(DOMMock, [{
    key: 'addEventListener',
    value: function addEventListener() {}
  }]);

  return DOMMock;
}();

var WindowMock = function (_DOMMock) {
  _inherits(WindowMock, _DOMMock);

  function WindowMock() {
    _classCallCheck(this, WindowMock);

    return _possibleConstructorReturn(this, (WindowMock.__proto__ || Object.getPrototypeOf(WindowMock)).apply(this, arguments));
  }

  _createClass(WindowMock, [{
    key: 'requestAnimationFrame',
    value: function requestAnimationFrame() {}
  }]);

  return WindowMock;
}(DOMMock);

var ContextMock = function (_DOMMock2) {
  _inherits(ContextMock, _DOMMock2);

  function ContextMock() {
    _classCallCheck(this, ContextMock);

    return _possibleConstructorReturn(this, (ContextMock.__proto__ || Object.getPrototypeOf(ContextMock)).apply(this, arguments));
  }

  _createClass(ContextMock, [{
    key: 'lineTo',
    value: function lineTo() {}
  }, {
    key: 'closePath',
    value: function closePath() {}
  }, {
    key: 'fill',
    value: function fill() {}
  }, {
    key: 'stroke',
    value: function stroke() {}
  }, {
    key: 'fillRect',
    value: function fillRect() {}
  }, {
    key: 'beginPath',
    value: function beginPath() {}
  }, {
    key: 'moveTo',
    value: function moveTo() {}
  }, {
    key: 'clearRect',
    value: function clearRect() {}
  }]);

  return ContextMock;
}(DOMMock);

var CanvasMock = function (_DOMMock3) {
  _inherits(CanvasMock, _DOMMock3);

  function CanvasMock() {
    _classCallCheck(this, CanvasMock);

    return _possibleConstructorReturn(this, (CanvasMock.__proto__ || Object.getPrototypeOf(CanvasMock)).apply(this, arguments));
  }

  _createClass(CanvasMock, [{
    key: 'getContext',
    value: function getContext(type) {
      if (type === '2d') {
        return new ContextMock();
      }
    }
  }]);

  return CanvasMock;
}(DOMMock);

var DocumentMock = function (_DOMMock4) {
  _inherits(DocumentMock, _DOMMock4);

  function DocumentMock() {
    _classCallCheck(this, DocumentMock);

    return _possibleConstructorReturn(this, (DocumentMock.__proto__ || Object.getPrototypeOf(DocumentMock)).apply(this, arguments));
  }

  _createClass(DocumentMock, [{
    key: 'getElementById',
    value: function getElementById(id) {
      if (id === 'canvas') {
        return new CanvasMock();
      }
    }
  }]);

  return DocumentMock;
}(DOMMock);

var isNode = function isNode(_) {
  return typeof window === 'undefined';
};

exports.isNode = isNode;
exports.DOMMock = DOMMock;
exports.DocumentMock = DocumentMock;
exports.WindowMock = WindowMock;

/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _engine = __webpack_require__(134);

var _engine2 = _interopRequireDefault(_engine);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _engine2.default;

/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

__webpack_require__(135);

var _touch = __webpack_require__(337);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Engine = function () {
  _createClass(Engine, [{
    key: 'onClick',


    // callback for click events


    // Contains keys that are pressed. Updated each frame
    value: function onClick(engine) {}

    // keycode -> func map. When the key with the keycode is pressed,
    // it will call func

    // Data to handle mouse events. Updated each frame

  }, {
    key: 'keyUp',
    value: function keyUp(engine, key, event) {}

    // drawn each frame

  }, {
    key: 'draw',
    value: function draw(engine, c) {}

    // updated each frame

  }, {
    key: 'update',
    value: function update(engine, delta) {}

    // Hooks into an element

  }]);

  function Engine(root) {
    var width = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 500;
    var height = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 500;
    var fullscreen = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

    _classCallCheck(this, Engine);

    this.mouse = {
      x: 0,
      y: 0,
      down: false,
      left: false,
      right: false,
      middle: false
    };
    this.touches = [];
    this.touchmode = false;
    this.state = {};
    this._width = 500;
    this._height = 500;
    this.settings = {
      width: this._width,
      height: this._height,
      fullscreen: false,
      supersampling: 1 };
    this.keys = {};
    this.keyEvents = {};

    var canvas = document.createElement('canvas');
    var offscreenCanvas = document.createElement('canvas');
    root.appendChild(canvas);
    this.canvas = canvas;
    this.offscreenCanvas = offscreenCanvas;
    this.settings.fullscreen = fullscreen;

    if (fullscreen) {
      this.width = window.innerWidth;
      this.height = window.innerHeight;
    } else {
      this.width = width;
      this.height = height;
    }
    this.context = canvas.getContext('2d');
    this.offscreenContext = offscreenCanvas.getContext('2d');
  }

  // Starts the event loop


  _createClass(Engine, [{
    key: 'run',
    value: function run(delta) {
      var _this = this;

      this.update(this, delta);
      this.draw(this, this.offscreenContext);
      this.context.clearRect(0, 0, this._width, this._height);
      this.context.drawImage(this.offscreenCanvas, 0, 0, this._width * 1, this._height * 1);
      window.requestAnimationFrame(function (delta) {
        return _this.run(delta);
      });
    }

    // Initializes events

  }, {
    key: 'start',
    value: function start() {
      var _this2 = this;

      this.canvas.addEventListener('mousemove', function (e) {
        if (e.offsetX) {
          _this2.mouse.x = e.offsetX * _this2.settings.supersampling;
          _this2.mouse.y = e.offsetY * _this2.settings.supersampling;
        } else if (e.layerX) {
          var box = _this2.canvas.getBoundingClientRect();
          _this2.mouse.x = (e.layerX - box.left) * _this2.settings.supersampling;
          _this2.mouse.y = (e.layerY - box.top) * _this2.settings.supersampling;
        }
      });

      this.canvas.addEventListener('mousedown', function (e) {
        _this2.mouse.down = true;

        if (e.which === 1) {
          _this2.mouse.left = true;
        }
        if (e.which === 2) {
          _this2.mouse.middle = true;
        }
        if (e.which === 3) {
          _this2.mouse.right = true;
        }
      });

      this.canvas.addEventListener('contextmenu', function (e) {
        return e.preventDefault();
      });
      this.canvas.addEventListener('dragenter', function (e) {
        return e.preventDefault();
      });
      console.log(this.canvas);

      window.addEventListener('mouseup', function (e) {
        _this2.onClick(_this2);
        if (e.which === 1) {
          _this2.mouse.left = false;
        } else if (e.which === 3) {
          _this2.mouse.right = false;
        } else if (e.which === 2) {
          _this2.mouse.middle = false;
        }
        if (!_this2.mouse.left && !_this2.mouse.right && !_this2.mouse.middle) {
          _this2.mouse.down = false;
        }
      });

      window.addEventListener('keydown', function (e) {
        _this2.keys[e.keyCode] = true;
        if (!e.ctrlKey && !e.metaKey) {
          e.preventDefault();
        }
      }, false);

      window.addEventListener('keyup', function (e) {
        if (typeof _this2.keyEvents[e.keyCode] === 'function') {
          _this2.keyEvents[e.keyCode](_this2);
        }
        delete _this2.keys[e.keyCode];
        _this2.keyUp(_this2, e.keyCode, e);
      }, false);

      window.addEventListener('resize', function (_e) {
        if (_this2.settings.fullscreen) {
          _this2.width = window.innerWidth;
          _this2.height = window.innerHeight;
        }
      }, false);

      this.canvas.addEventListener('touchstart', function (evt) {
        _this2.touchmode = true;
        _this2.touches = (0, _touch.getTouches)(evt, _this2.settings.supersampling);
        evt.preventDefault();
        for (var i = 0; i < evt.changedTouches.length; i++) {
          var touch = evt.touches[i];
          if (i === 0) {
            _this2.mouse.down = true;
            if (touch.pageX) {
              _this2.mouse.x = touch.pageX * _this2.settings.supersampling;
              _this2.mouse.y = touch.pageY * _this2.settings.supersampling;
            }
          }
        }
      }, false);

      this.canvas.addEventListener('touchend', function (evt) {
        _this2.onClick(_this2);
        _this2.touches = (0, _touch.getTouches)(evt, _this2.settings.supersampling);
        _this2.mouse.down = false;
        // console.log('touchend', evt)
      }, false);

      this.canvas.addEventListener('touchcancel', function (evt) {
        _this2.touches = (0, _touch.getTouches)(evt, _this2.settings.supersampling);
        // console.log('touchcancel', evt)
      }, false);

      this.canvas.addEventListener('touchmove', function (evt) {
        _this2.touches = (0, _touch.getTouches)(evt, _this2.settings.supersampling);
        evt.preventDefault();
        for (var i = 0; i < evt.changedTouches.length; i++) {
          var touch = evt.changedTouches[i];
          if (i === 0) {
            _this2.mouse.down = true;
            if (touch.pageX) {
              _this2.mouse.x = touch.pageX * _this2.settings.supersampling;
              _this2.mouse.y = touch.pageY * _this2.settings.supersampling;
            }
          }
        }
      }, false);

      this.run(0);
    }
  }, {
    key: 'setSupersampling',
    value: function setSupersampling(val) {
      this.settings.supersampling = val;
      this.width = window.innerWidth;
      this.height = window.innerHeight;
    }
  }, {
    key: 'width',
    set: function set(w) {
      this._width = w;
      this.settings.width = w;
      this.canvas.width = w;
      this.canvas.style.width = w + 'px';
      this.offscreenCanvas.width = w * this.settings.supersampling;
      this.offscreenCanvas.style.width = w * this.settings.supersampling + 'px';
    },
    get: function get() {
      return this._width * this.settings.supersampling;
    }
  }, {
    key: 'height',
    set: function set(h) {
      this._height = h;
      this.settings.height = h;
      this.canvas.height = h;
      this.canvas.style.height = h + 'px';
      this.offscreenCanvas.height = h * this.settings.supersampling;
      this.offscreenCanvas.style.height = h * this.settings.supersampling + 'px';
    },
    get: function get() {
      return this._height * this.settings.supersampling;
    }
  }]);

  return Engine;
}();

exports.default = Engine;

/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

__webpack_require__(136);

__webpack_require__(333);

__webpack_require__(334);

if (global._babelPolyfill) {
  throw new Error("only one instance of babel-polyfill is allowed");
}
global._babelPolyfill = true;

var DEFINE_PROPERTY = "defineProperty";
function define(O, key, value) {
  O[key] || Object[DEFINE_PROPERTY](O, key, {
    writable: true,
    configurable: true,
    value: value
  });
}

define(String.prototype, "padLeft", "".padStart);
define(String.prototype, "padRight", "".padEnd);

"pop,reverse,shift,keys,values,entries,indexOf,every,some,forEach,map,filter,find,findIndex,includes,join,slice,concat,push,splice,unshift,sort,lastIndexOf,reduce,reduceRight,copyWithin,fill".split(",").forEach(function (key) {
  [][key] && define(Array, key, Function.call.bind([][key]));
});
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(137);
__webpack_require__(139);
__webpack_require__(140);
__webpack_require__(141);
__webpack_require__(142);
__webpack_require__(143);
__webpack_require__(144);
__webpack_require__(145);
__webpack_require__(146);
__webpack_require__(147);
__webpack_require__(148);
__webpack_require__(149);
__webpack_require__(150);
__webpack_require__(151);
__webpack_require__(152);
__webpack_require__(153);
__webpack_require__(155);
__webpack_require__(156);
__webpack_require__(157);
__webpack_require__(158);
__webpack_require__(159);
__webpack_require__(160);
__webpack_require__(161);
__webpack_require__(162);
__webpack_require__(163);
__webpack_require__(164);
__webpack_require__(165);
__webpack_require__(166);
__webpack_require__(167);
__webpack_require__(168);
__webpack_require__(169);
__webpack_require__(170);
__webpack_require__(171);
__webpack_require__(172);
__webpack_require__(173);
__webpack_require__(174);
__webpack_require__(175);
__webpack_require__(176);
__webpack_require__(177);
__webpack_require__(178);
__webpack_require__(179);
__webpack_require__(180);
__webpack_require__(181);
__webpack_require__(182);
__webpack_require__(183);
__webpack_require__(184);
__webpack_require__(185);
__webpack_require__(186);
__webpack_require__(187);
__webpack_require__(188);
__webpack_require__(189);
__webpack_require__(190);
__webpack_require__(191);
__webpack_require__(192);
__webpack_require__(193);
__webpack_require__(194);
__webpack_require__(195);
__webpack_require__(196);
__webpack_require__(197);
__webpack_require__(198);
__webpack_require__(199);
__webpack_require__(200);
__webpack_require__(201);
__webpack_require__(202);
__webpack_require__(203);
__webpack_require__(204);
__webpack_require__(205);
__webpack_require__(206);
__webpack_require__(207);
__webpack_require__(208);
__webpack_require__(209);
__webpack_require__(210);
__webpack_require__(211);
__webpack_require__(212);
__webpack_require__(213);
__webpack_require__(214);
__webpack_require__(215);
__webpack_require__(217);
__webpack_require__(218);
__webpack_require__(220);
__webpack_require__(221);
__webpack_require__(222);
__webpack_require__(223);
__webpack_require__(224);
__webpack_require__(225);
__webpack_require__(226);
__webpack_require__(228);
__webpack_require__(229);
__webpack_require__(230);
__webpack_require__(231);
__webpack_require__(232);
__webpack_require__(233);
__webpack_require__(234);
__webpack_require__(235);
__webpack_require__(236);
__webpack_require__(237);
__webpack_require__(238);
__webpack_require__(239);
__webpack_require__(240);
__webpack_require__(86);
__webpack_require__(241);
__webpack_require__(242);
__webpack_require__(111);
__webpack_require__(243);
__webpack_require__(244);
__webpack_require__(245);
__webpack_require__(246);
__webpack_require__(247);
__webpack_require__(114);
__webpack_require__(116);
__webpack_require__(117);
__webpack_require__(248);
__webpack_require__(249);
__webpack_require__(250);
__webpack_require__(251);
__webpack_require__(252);
__webpack_require__(253);
__webpack_require__(254);
__webpack_require__(255);
__webpack_require__(256);
__webpack_require__(257);
__webpack_require__(258);
__webpack_require__(259);
__webpack_require__(260);
__webpack_require__(261);
__webpack_require__(262);
__webpack_require__(263);
__webpack_require__(264);
__webpack_require__(265);
__webpack_require__(266);
__webpack_require__(267);
__webpack_require__(268);
__webpack_require__(269);
__webpack_require__(270);
__webpack_require__(271);
__webpack_require__(272);
__webpack_require__(273);
__webpack_require__(274);
__webpack_require__(275);
__webpack_require__(276);
__webpack_require__(277);
__webpack_require__(278);
__webpack_require__(279);
__webpack_require__(280);
__webpack_require__(281);
__webpack_require__(282);
__webpack_require__(283);
__webpack_require__(284);
__webpack_require__(285);
__webpack_require__(286);
__webpack_require__(287);
__webpack_require__(288);
__webpack_require__(289);
__webpack_require__(290);
__webpack_require__(291);
__webpack_require__(292);
__webpack_require__(293);
__webpack_require__(294);
__webpack_require__(295);
__webpack_require__(296);
__webpack_require__(297);
__webpack_require__(298);
__webpack_require__(299);
__webpack_require__(300);
__webpack_require__(301);
__webpack_require__(302);
__webpack_require__(303);
__webpack_require__(304);
__webpack_require__(305);
__webpack_require__(306);
__webpack_require__(307);
__webpack_require__(308);
__webpack_require__(309);
__webpack_require__(310);
__webpack_require__(311);
__webpack_require__(312);
__webpack_require__(313);
__webpack_require__(314);
__webpack_require__(315);
__webpack_require__(316);
__webpack_require__(317);
__webpack_require__(318);
__webpack_require__(319);
__webpack_require__(320);
__webpack_require__(321);
__webpack_require__(322);
__webpack_require__(323);
__webpack_require__(324);
__webpack_require__(325);
__webpack_require__(326);
__webpack_require__(327);
__webpack_require__(328);
__webpack_require__(329);
__webpack_require__(330);
__webpack_require__(331);
__webpack_require__(332);
module.exports = __webpack_require__(21);


/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// ECMAScript 6 symbols shim
var global = __webpack_require__(2);
var has = __webpack_require__(11);
var DESCRIPTORS = __webpack_require__(6);
var $export = __webpack_require__(0);
var redefine = __webpack_require__(13);
var META = __webpack_require__(29).KEY;
var $fails = __webpack_require__(3);
var shared = __webpack_require__(50);
var setToStringTag = __webpack_require__(42);
var uid = __webpack_require__(32);
var wks = __webpack_require__(5);
var wksExt = __webpack_require__(94);
var wksDefine = __webpack_require__(66);
var enumKeys = __webpack_require__(138);
var isArray = __webpack_require__(53);
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var toIObject = __webpack_require__(15);
var toPrimitive = __webpack_require__(22);
var createDesc = __webpack_require__(31);
var _create = __webpack_require__(36);
var gOPNExt = __webpack_require__(97);
var $GOPD = __webpack_require__(16);
var $DP = __webpack_require__(7);
var $keys = __webpack_require__(34);
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  __webpack_require__(37).f = gOPNExt.f = $getOwnPropertyNames;
  __webpack_require__(48).f = $propertyIsEnumerable;
  __webpack_require__(52).f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !__webpack_require__(33)) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function (key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(12)($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);


/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(34);
var gOPS = __webpack_require__(52);
var pIE = __webpack_require__(48);
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};


/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
$export($export.S, 'Object', { create: __webpack_require__(36) });


/***/ }),
/* 140 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(6), 'Object', { defineProperty: __webpack_require__(7).f });


/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
// 19.1.2.3 / 15.2.3.7 Object.defineProperties(O, Properties)
$export($export.S + $export.F * !__webpack_require__(6), 'Object', { defineProperties: __webpack_require__(96) });


/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
var toIObject = __webpack_require__(15);
var $getOwnPropertyDescriptor = __webpack_require__(16).f;

__webpack_require__(25)('getOwnPropertyDescriptor', function () {
  return function getOwnPropertyDescriptor(it, key) {
    return $getOwnPropertyDescriptor(toIObject(it), key);
  };
});


/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.9 Object.getPrototypeOf(O)
var toObject = __webpack_require__(9);
var $getPrototypeOf = __webpack_require__(17);

__webpack_require__(25)('getPrototypeOf', function () {
  return function getPrototypeOf(it) {
    return $getPrototypeOf(toObject(it));
  };
});


/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(9);
var $keys = __webpack_require__(34);

__webpack_require__(25)('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 Object.getOwnPropertyNames(O)
__webpack_require__(25)('getOwnPropertyNames', function () {
  return __webpack_require__(97).f;
});


/***/ }),
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.5 Object.freeze(O)
var isObject = __webpack_require__(4);
var meta = __webpack_require__(29).onFreeze;

__webpack_require__(25)('freeze', function ($freeze) {
  return function freeze(it) {
    return $freeze && isObject(it) ? $freeze(meta(it)) : it;
  };
});


/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.17 Object.seal(O)
var isObject = __webpack_require__(4);
var meta = __webpack_require__(29).onFreeze;

__webpack_require__(25)('seal', function ($seal) {
  return function seal(it) {
    return $seal && isObject(it) ? $seal(meta(it)) : it;
  };
});


/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.15 Object.preventExtensions(O)
var isObject = __webpack_require__(4);
var meta = __webpack_require__(29).onFreeze;

__webpack_require__(25)('preventExtensions', function ($preventExtensions) {
  return function preventExtensions(it) {
    return $preventExtensions && isObject(it) ? $preventExtensions(meta(it)) : it;
  };
});


/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.12 Object.isFrozen(O)
var isObject = __webpack_require__(4);

__webpack_require__(25)('isFrozen', function ($isFrozen) {
  return function isFrozen(it) {
    return isObject(it) ? $isFrozen ? $isFrozen(it) : false : true;
  };
});


/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.13 Object.isSealed(O)
var isObject = __webpack_require__(4);

__webpack_require__(25)('isSealed', function ($isSealed) {
  return function isSealed(it) {
    return isObject(it) ? $isSealed ? $isSealed(it) : false : true;
  };
});


/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.11 Object.isExtensible(O)
var isObject = __webpack_require__(4);

__webpack_require__(25)('isExtensible', function ($isExtensible) {
  return function isExtensible(it) {
    return isObject(it) ? $isExtensible ? $isExtensible(it) : true : false;
  };
});


/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.1 Object.assign(target, source)
var $export = __webpack_require__(0);

$export($export.S + $export.F, 'Object', { assign: __webpack_require__(98) });


/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.10 Object.is(value1, value2)
var $export = __webpack_require__(0);
$export($export.S, 'Object', { is: __webpack_require__(154) });


/***/ }),
/* 154 */
/***/ (function(module, exports) {

// 7.2.9 SameValue(x, y)
module.exports = Object.is || function is(x, y) {
  // eslint-disable-next-line no-self-compare
  return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
};


/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.3.19 Object.setPrototypeOf(O, proto)
var $export = __webpack_require__(0);
$export($export.S, 'Object', { setPrototypeOf: __webpack_require__(70).set });


/***/ }),
/* 156 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 19.1.3.6 Object.prototype.toString()
var classof = __webpack_require__(49);
var test = {};
test[__webpack_require__(5)('toStringTag')] = 'z';
if (test + '' != '[object z]') {
  __webpack_require__(13)(Object.prototype, 'toString', function toString() {
    return '[object ' + classof(this) + ']';
  }, true);
}


/***/ }),
/* 157 */
/***/ (function(module, exports, __webpack_require__) {

// 19.2.3.2 / 15.3.4.5 Function.prototype.bind(thisArg, args...)
var $export = __webpack_require__(0);

$export($export.P, 'Function', { bind: __webpack_require__(99) });


/***/ }),
/* 158 */
/***/ (function(module, exports, __webpack_require__) {

var dP = __webpack_require__(7).f;
var FProto = Function.prototype;
var nameRE = /^\s*function ([^ (]*)/;
var NAME = 'name';

// 19.2.4.2 name
NAME in FProto || __webpack_require__(6) && dP(FProto, NAME, {
  configurable: true,
  get: function () {
    try {
      return ('' + this).match(nameRE)[1];
    } catch (e) {
      return '';
    }
  }
});


/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var isObject = __webpack_require__(4);
var getPrototypeOf = __webpack_require__(17);
var HAS_INSTANCE = __webpack_require__(5)('hasInstance');
var FunctionProto = Function.prototype;
// 19.2.3.6 Function.prototype[@@hasInstance](V)
if (!(HAS_INSTANCE in FunctionProto)) __webpack_require__(7).f(FunctionProto, HAS_INSTANCE, { value: function (O) {
  if (typeof this != 'function' || !isObject(O)) return false;
  if (!isObject(this.prototype)) return O instanceof this;
  // for environment w/o native `@@hasInstance` logic enough `instanceof`, but add this:
  while (O = getPrototypeOf(O)) if (this.prototype === O) return true;
  return false;
} });


/***/ }),
/* 160 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseInt = __webpack_require__(101);
// 18.2.5 parseInt(string, radix)
$export($export.G + $export.F * (parseInt != $parseInt), { parseInt: $parseInt });


/***/ }),
/* 161 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseFloat = __webpack_require__(102);
// 18.2.4 parseFloat(string)
$export($export.G + $export.F * (parseFloat != $parseFloat), { parseFloat: $parseFloat });


/***/ }),
/* 162 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var global = __webpack_require__(2);
var has = __webpack_require__(11);
var cof = __webpack_require__(19);
var inheritIfRequired = __webpack_require__(72);
var toPrimitive = __webpack_require__(22);
var fails = __webpack_require__(3);
var gOPN = __webpack_require__(37).f;
var gOPD = __webpack_require__(16).f;
var dP = __webpack_require__(7).f;
var $trim = __webpack_require__(43).trim;
var NUMBER = 'Number';
var $Number = global[NUMBER];
var Base = $Number;
var proto = $Number.prototype;
// Opera ~12 has broken Object#toString
var BROKEN_COF = cof(__webpack_require__(36)(proto)) == NUMBER;
var TRIM = 'trim' in String.prototype;

// 7.1.3 ToNumber(argument)
var toNumber = function (argument) {
  var it = toPrimitive(argument, false);
  if (typeof it == 'string' && it.length > 2) {
    it = TRIM ? it.trim() : $trim(it, 3);
    var first = it.charCodeAt(0);
    var third, radix, maxCode;
    if (first === 43 || first === 45) {
      third = it.charCodeAt(2);
      if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
    } else if (first === 48) {
      switch (it.charCodeAt(1)) {
        case 66: case 98: radix = 2; maxCode = 49; break; // fast equal /^0b[01]+$/i
        case 79: case 111: radix = 8; maxCode = 55; break; // fast equal /^0o[0-7]+$/i
        default: return +it;
      }
      for (var digits = it.slice(2), i = 0, l = digits.length, code; i < l; i++) {
        code = digits.charCodeAt(i);
        // parseInt parses a string to a first unavailable symbol
        // but ToNumber should return NaN if a string contains unavailable symbols
        if (code < 48 || code > maxCode) return NaN;
      } return parseInt(digits, radix);
    }
  } return +it;
};

if (!$Number(' 0o1') || !$Number('0b1') || $Number('+0x1')) {
  $Number = function Number(value) {
    var it = arguments.length < 1 ? 0 : value;
    var that = this;
    return that instanceof $Number
      // check on 1..constructor(foo) case
      && (BROKEN_COF ? fails(function () { proto.valueOf.call(that); }) : cof(that) != NUMBER)
        ? inheritIfRequired(new Base(toNumber(it)), that, $Number) : toNumber(it);
  };
  for (var keys = __webpack_require__(6) ? gOPN(Base) : (
    // ES3:
    'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
    // ES6 (in case, if modules with ES6 Number statics required before):
    'EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,' +
    'MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger'
  ).split(','), j = 0, key; keys.length > j; j++) {
    if (has(Base, key = keys[j]) && !has($Number, key)) {
      dP($Number, key, gOPD(Base, key));
    }
  }
  $Number.prototype = proto;
  proto.constructor = $Number;
  __webpack_require__(13)(global, NUMBER, $Number);
}


/***/ }),
/* 163 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toInteger = __webpack_require__(24);
var aNumberValue = __webpack_require__(103);
var repeat = __webpack_require__(73);
var $toFixed = 1.0.toFixed;
var floor = Math.floor;
var data = [0, 0, 0, 0, 0, 0];
var ERROR = 'Number.toFixed: incorrect invocation!';
var ZERO = '0';

var multiply = function (n, c) {
  var i = -1;
  var c2 = c;
  while (++i < 6) {
    c2 += n * data[i];
    data[i] = c2 % 1e7;
    c2 = floor(c2 / 1e7);
  }
};
var divide = function (n) {
  var i = 6;
  var c = 0;
  while (--i >= 0) {
    c += data[i];
    data[i] = floor(c / n);
    c = (c % n) * 1e7;
  }
};
var numToString = function () {
  var i = 6;
  var s = '';
  while (--i >= 0) {
    if (s !== '' || i === 0 || data[i] !== 0) {
      var t = String(data[i]);
      s = s === '' ? t : s + repeat.call(ZERO, 7 - t.length) + t;
    }
  } return s;
};
var pow = function (x, n, acc) {
  return n === 0 ? acc : n % 2 === 1 ? pow(x, n - 1, acc * x) : pow(x * x, n / 2, acc);
};
var log = function (x) {
  var n = 0;
  var x2 = x;
  while (x2 >= 4096) {
    n += 12;
    x2 /= 4096;
  }
  while (x2 >= 2) {
    n += 1;
    x2 /= 2;
  } return n;
};

$export($export.P + $export.F * (!!$toFixed && (
  0.00008.toFixed(3) !== '0.000' ||
  0.9.toFixed(0) !== '1' ||
  1.255.toFixed(2) !== '1.25' ||
  1000000000000000128.0.toFixed(0) !== '1000000000000000128'
) || !__webpack_require__(3)(function () {
  // V8 ~ Android 4.3-
  $toFixed.call({});
})), 'Number', {
  toFixed: function toFixed(fractionDigits) {
    var x = aNumberValue(this, ERROR);
    var f = toInteger(fractionDigits);
    var s = '';
    var m = ZERO;
    var e, z, j, k;
    if (f < 0 || f > 20) throw RangeError(ERROR);
    // eslint-disable-next-line no-self-compare
    if (x != x) return 'NaN';
    if (x <= -1e21 || x >= 1e21) return String(x);
    if (x < 0) {
      s = '-';
      x = -x;
    }
    if (x > 1e-21) {
      e = log(x * pow(2, 69, 1)) - 69;
      z = e < 0 ? x * pow(2, -e, 1) : x / pow(2, e, 1);
      z *= 0x10000000000000;
      e = 52 - e;
      if (e > 0) {
        multiply(0, z);
        j = f;
        while (j >= 7) {
          multiply(1e7, 0);
          j -= 7;
        }
        multiply(pow(10, j, 1), 0);
        j = e - 1;
        while (j >= 23) {
          divide(1 << 23);
          j -= 23;
        }
        divide(1 << j);
        multiply(1, 1);
        divide(2);
        m = numToString();
      } else {
        multiply(0, z);
        multiply(1 << -e, 0);
        m = numToString() + repeat.call(ZERO, f);
      }
    }
    if (f > 0) {
      k = m.length;
      m = s + (k <= f ? '0.' + repeat.call(ZERO, f - k) + m : m.slice(0, k - f) + '.' + m.slice(k - f));
    } else {
      m = s + m;
    } return m;
  }
});


/***/ }),
/* 164 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $fails = __webpack_require__(3);
var aNumberValue = __webpack_require__(103);
var $toPrecision = 1.0.toPrecision;

$export($export.P + $export.F * ($fails(function () {
  // IE7-
  return $toPrecision.call(1, undefined) !== '1';
}) || !$fails(function () {
  // V8 ~ Android 4.3-
  $toPrecision.call({});
})), 'Number', {
  toPrecision: function toPrecision(precision) {
    var that = aNumberValue(this, 'Number#toPrecision: incorrect invocation!');
    return precision === undefined ? $toPrecision.call(that) : $toPrecision.call(that, precision);
  }
});


/***/ }),
/* 165 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.1 Number.EPSILON
var $export = __webpack_require__(0);

$export($export.S, 'Number', { EPSILON: Math.pow(2, -52) });


/***/ }),
/* 166 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.2 Number.isFinite(number)
var $export = __webpack_require__(0);
var _isFinite = __webpack_require__(2).isFinite;

$export($export.S, 'Number', {
  isFinite: function isFinite(it) {
    return typeof it == 'number' && _isFinite(it);
  }
});


/***/ }),
/* 167 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.3 Number.isInteger(number)
var $export = __webpack_require__(0);

$export($export.S, 'Number', { isInteger: __webpack_require__(104) });


/***/ }),
/* 168 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.4 Number.isNaN(number)
var $export = __webpack_require__(0);

$export($export.S, 'Number', {
  isNaN: function isNaN(number) {
    // eslint-disable-next-line no-self-compare
    return number != number;
  }
});


/***/ }),
/* 169 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.5 Number.isSafeInteger(number)
var $export = __webpack_require__(0);
var isInteger = __webpack_require__(104);
var abs = Math.abs;

$export($export.S, 'Number', {
  isSafeInteger: function isSafeInteger(number) {
    return isInteger(number) && abs(number) <= 0x1fffffffffffff;
  }
});


/***/ }),
/* 170 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.6 Number.MAX_SAFE_INTEGER
var $export = __webpack_require__(0);

$export($export.S, 'Number', { MAX_SAFE_INTEGER: 0x1fffffffffffff });


/***/ }),
/* 171 */
/***/ (function(module, exports, __webpack_require__) {

// 20.1.2.10 Number.MIN_SAFE_INTEGER
var $export = __webpack_require__(0);

$export($export.S, 'Number', { MIN_SAFE_INTEGER: -0x1fffffffffffff });


/***/ }),
/* 172 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseFloat = __webpack_require__(102);
// 20.1.2.12 Number.parseFloat(string)
$export($export.S + $export.F * (Number.parseFloat != $parseFloat), 'Number', { parseFloat: $parseFloat });


/***/ }),
/* 173 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $parseInt = __webpack_require__(101);
// 20.1.2.13 Number.parseInt(string, radix)
$export($export.S + $export.F * (Number.parseInt != $parseInt), 'Number', { parseInt: $parseInt });


/***/ }),
/* 174 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.3 Math.acosh(x)
var $export = __webpack_require__(0);
var log1p = __webpack_require__(105);
var sqrt = Math.sqrt;
var $acosh = Math.acosh;

$export($export.S + $export.F * !($acosh
  // V8 bug: https://code.google.com/p/v8/issues/detail?id=3509
  && Math.floor($acosh(Number.MAX_VALUE)) == 710
  // Tor Browser bug: Math.acosh(Infinity) -> NaN
  && $acosh(Infinity) == Infinity
), 'Math', {
  acosh: function acosh(x) {
    return (x = +x) < 1 ? NaN : x > 94906265.62425156
      ? Math.log(x) + Math.LN2
      : log1p(x - 1 + sqrt(x - 1) * sqrt(x + 1));
  }
});


/***/ }),
/* 175 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.5 Math.asinh(x)
var $export = __webpack_require__(0);
var $asinh = Math.asinh;

function asinh(x) {
  return !isFinite(x = +x) || x == 0 ? x : x < 0 ? -asinh(-x) : Math.log(x + Math.sqrt(x * x + 1));
}

// Tor Browser bug: Math.asinh(0) -> -0
$export($export.S + $export.F * !($asinh && 1 / $asinh(0) > 0), 'Math', { asinh: asinh });


/***/ }),
/* 176 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.7 Math.atanh(x)
var $export = __webpack_require__(0);
var $atanh = Math.atanh;

// Tor Browser bug: Math.atanh(-0) -> 0
$export($export.S + $export.F * !($atanh && 1 / $atanh(-0) < 0), 'Math', {
  atanh: function atanh(x) {
    return (x = +x) == 0 ? x : Math.log((1 + x) / (1 - x)) / 2;
  }
});


/***/ }),
/* 177 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.9 Math.cbrt(x)
var $export = __webpack_require__(0);
var sign = __webpack_require__(74);

$export($export.S, 'Math', {
  cbrt: function cbrt(x) {
    return sign(x = +x) * Math.pow(Math.abs(x), 1 / 3);
  }
});


/***/ }),
/* 178 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.11 Math.clz32(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  clz32: function clz32(x) {
    return (x >>>= 0) ? 31 - Math.floor(Math.log(x + 0.5) * Math.LOG2E) : 32;
  }
});


/***/ }),
/* 179 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.12 Math.cosh(x)
var $export = __webpack_require__(0);
var exp = Math.exp;

$export($export.S, 'Math', {
  cosh: function cosh(x) {
    return (exp(x = +x) + exp(-x)) / 2;
  }
});


/***/ }),
/* 180 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.14 Math.expm1(x)
var $export = __webpack_require__(0);
var $expm1 = __webpack_require__(75);

$export($export.S + $export.F * ($expm1 != Math.expm1), 'Math', { expm1: $expm1 });


/***/ }),
/* 181 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.16 Math.fround(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { fround: __webpack_require__(106) });


/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.17 Math.hypot([value1[, value2[, … ]]])
var $export = __webpack_require__(0);
var abs = Math.abs;

$export($export.S, 'Math', {
  hypot: function hypot(value1, value2) { // eslint-disable-line no-unused-vars
    var sum = 0;
    var i = 0;
    var aLen = arguments.length;
    var larg = 0;
    var arg, div;
    while (i < aLen) {
      arg = abs(arguments[i++]);
      if (larg < arg) {
        div = larg / arg;
        sum = sum * div * div + 1;
        larg = arg;
      } else if (arg > 0) {
        div = arg / larg;
        sum += div * div;
      } else sum += arg;
    }
    return larg === Infinity ? Infinity : larg * Math.sqrt(sum);
  }
});


/***/ }),
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.18 Math.imul(x, y)
var $export = __webpack_require__(0);
var $imul = Math.imul;

// some WebKit versions fails with big numbers, some has wrong arity
$export($export.S + $export.F * __webpack_require__(3)(function () {
  return $imul(0xffffffff, 5) != -5 || $imul.length != 2;
}), 'Math', {
  imul: function imul(x, y) {
    var UINT16 = 0xffff;
    var xn = +x;
    var yn = +y;
    var xl = UINT16 & xn;
    var yl = UINT16 & yn;
    return 0 | xl * yl + ((UINT16 & xn >>> 16) * yl + xl * (UINT16 & yn >>> 16) << 16 >>> 0);
  }
});


/***/ }),
/* 184 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.21 Math.log10(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  log10: function log10(x) {
    return Math.log(x) * Math.LOG10E;
  }
});


/***/ }),
/* 185 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.20 Math.log1p(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { log1p: __webpack_require__(105) });


/***/ }),
/* 186 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.22 Math.log2(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  log2: function log2(x) {
    return Math.log(x) / Math.LN2;
  }
});


/***/ }),
/* 187 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.28 Math.sign(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', { sign: __webpack_require__(74) });


/***/ }),
/* 188 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.30 Math.sinh(x)
var $export = __webpack_require__(0);
var expm1 = __webpack_require__(75);
var exp = Math.exp;

// V8 near Chromium 38 has a problem with very small numbers
$export($export.S + $export.F * __webpack_require__(3)(function () {
  return !Math.sinh(-2e-17) != -2e-17;
}), 'Math', {
  sinh: function sinh(x) {
    return Math.abs(x = +x) < 1
      ? (expm1(x) - expm1(-x)) / 2
      : (exp(x - 1) - exp(-x - 1)) * (Math.E / 2);
  }
});


/***/ }),
/* 189 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.33 Math.tanh(x)
var $export = __webpack_require__(0);
var expm1 = __webpack_require__(75);
var exp = Math.exp;

$export($export.S, 'Math', {
  tanh: function tanh(x) {
    var a = expm1(x = +x);
    var b = expm1(-x);
    return a == Infinity ? 1 : b == Infinity ? -1 : (a - b) / (exp(x) + exp(-x));
  }
});


/***/ }),
/* 190 */
/***/ (function(module, exports, __webpack_require__) {

// 20.2.2.34 Math.trunc(x)
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  trunc: function trunc(it) {
    return (it > 0 ? Math.floor : Math.ceil)(it);
  }
});


/***/ }),
/* 191 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var toAbsoluteIndex = __webpack_require__(35);
var fromCharCode = String.fromCharCode;
var $fromCodePoint = String.fromCodePoint;

// length should be 1, old FF problem
$export($export.S + $export.F * (!!$fromCodePoint && $fromCodePoint.length != 1), 'String', {
  // 21.1.2.2 String.fromCodePoint(...codePoints)
  fromCodePoint: function fromCodePoint(x) { // eslint-disable-line no-unused-vars
    var res = [];
    var aLen = arguments.length;
    var i = 0;
    var code;
    while (aLen > i) {
      code = +arguments[i++];
      if (toAbsoluteIndex(code, 0x10ffff) !== code) throw RangeError(code + ' is not a valid code point');
      res.push(code < 0x10000
        ? fromCharCode(code)
        : fromCharCode(((code -= 0x10000) >> 10) + 0xd800, code % 0x400 + 0xdc00)
      );
    } return res.join('');
  }
});


/***/ }),
/* 192 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var toIObject = __webpack_require__(15);
var toLength = __webpack_require__(8);

$export($export.S, 'String', {
  // 21.1.2.4 String.raw(callSite, ...substitutions)
  raw: function raw(callSite) {
    var tpl = toIObject(callSite.raw);
    var len = toLength(tpl.length);
    var aLen = arguments.length;
    var res = [];
    var i = 0;
    while (len > i) {
      res.push(String(tpl[i++]));
      if (i < aLen) res.push(String(arguments[i]));
    } return res.join('');
  }
});


/***/ }),
/* 193 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 21.1.3.25 String.prototype.trim()
__webpack_require__(43)('trim', function ($trim) {
  return function trim() {
    return $trim(this, 3);
  };
});


/***/ }),
/* 194 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $at = __webpack_require__(76)(true);

// 21.1.3.27 String.prototype[@@iterator]()
__webpack_require__(77)(String, 'String', function (iterated) {
  this._t = String(iterated); // target
  this._i = 0;                // next index
// 21.1.5.2.1 %StringIteratorPrototype%.next()
}, function () {
  var O = this._t;
  var index = this._i;
  var point;
  if (index >= O.length) return { value: undefined, done: true };
  point = $at(O, index);
  this._i += point.length;
  return { value: point, done: false };
});


/***/ }),
/* 195 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $at = __webpack_require__(76)(false);
$export($export.P, 'String', {
  // 21.1.3.3 String.prototype.codePointAt(pos)
  codePointAt: function codePointAt(pos) {
    return $at(this, pos);
  }
});


/***/ }),
/* 196 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.6 String.prototype.endsWith(searchString [, endPosition])

var $export = __webpack_require__(0);
var toLength = __webpack_require__(8);
var context = __webpack_require__(79);
var ENDS_WITH = 'endsWith';
var $endsWith = ''[ENDS_WITH];

$export($export.P + $export.F * __webpack_require__(80)(ENDS_WITH), 'String', {
  endsWith: function endsWith(searchString /* , endPosition = @length */) {
    var that = context(this, searchString, ENDS_WITH);
    var endPosition = arguments.length > 1 ? arguments[1] : undefined;
    var len = toLength(that.length);
    var end = endPosition === undefined ? len : Math.min(toLength(endPosition), len);
    var search = String(searchString);
    return $endsWith
      ? $endsWith.call(that, search, end)
      : that.slice(end - search.length, end) === search;
  }
});


/***/ }),
/* 197 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.7 String.prototype.includes(searchString, position = 0)

var $export = __webpack_require__(0);
var context = __webpack_require__(79);
var INCLUDES = 'includes';

$export($export.P + $export.F * __webpack_require__(80)(INCLUDES), 'String', {
  includes: function includes(searchString /* , position = 0 */) {
    return !!~context(this, searchString, INCLUDES)
      .indexOf(searchString, arguments.length > 1 ? arguments[1] : undefined);
  }
});


/***/ }),
/* 198 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);

$export($export.P, 'String', {
  // 21.1.3.13 String.prototype.repeat(count)
  repeat: __webpack_require__(73)
});


/***/ }),
/* 199 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// 21.1.3.18 String.prototype.startsWith(searchString [, position ])

var $export = __webpack_require__(0);
var toLength = __webpack_require__(8);
var context = __webpack_require__(79);
var STARTS_WITH = 'startsWith';
var $startsWith = ''[STARTS_WITH];

$export($export.P + $export.F * __webpack_require__(80)(STARTS_WITH), 'String', {
  startsWith: function startsWith(searchString /* , position = 0 */) {
    var that = context(this, searchString, STARTS_WITH);
    var index = toLength(Math.min(arguments.length > 1 ? arguments[1] : undefined, that.length));
    var search = String(searchString);
    return $startsWith
      ? $startsWith.call(that, search, index)
      : that.slice(index, index + search.length) === search;
  }
});


/***/ }),
/* 200 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.2 String.prototype.anchor(name)
__webpack_require__(14)('anchor', function (createHTML) {
  return function anchor(name) {
    return createHTML(this, 'a', 'name', name);
  };
});


/***/ }),
/* 201 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.3 String.prototype.big()
__webpack_require__(14)('big', function (createHTML) {
  return function big() {
    return createHTML(this, 'big', '', '');
  };
});


/***/ }),
/* 202 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.4 String.prototype.blink()
__webpack_require__(14)('blink', function (createHTML) {
  return function blink() {
    return createHTML(this, 'blink', '', '');
  };
});


/***/ }),
/* 203 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.5 String.prototype.bold()
__webpack_require__(14)('bold', function (createHTML) {
  return function bold() {
    return createHTML(this, 'b', '', '');
  };
});


/***/ }),
/* 204 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.6 String.prototype.fixed()
__webpack_require__(14)('fixed', function (createHTML) {
  return function fixed() {
    return createHTML(this, 'tt', '', '');
  };
});


/***/ }),
/* 205 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.7 String.prototype.fontcolor(color)
__webpack_require__(14)('fontcolor', function (createHTML) {
  return function fontcolor(color) {
    return createHTML(this, 'font', 'color', color);
  };
});


/***/ }),
/* 206 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.8 String.prototype.fontsize(size)
__webpack_require__(14)('fontsize', function (createHTML) {
  return function fontsize(size) {
    return createHTML(this, 'font', 'size', size);
  };
});


/***/ }),
/* 207 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.9 String.prototype.italics()
__webpack_require__(14)('italics', function (createHTML) {
  return function italics() {
    return createHTML(this, 'i', '', '');
  };
});


/***/ }),
/* 208 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.10 String.prototype.link(url)
__webpack_require__(14)('link', function (createHTML) {
  return function link(url) {
    return createHTML(this, 'a', 'href', url);
  };
});


/***/ }),
/* 209 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.11 String.prototype.small()
__webpack_require__(14)('small', function (createHTML) {
  return function small() {
    return createHTML(this, 'small', '', '');
  };
});


/***/ }),
/* 210 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.12 String.prototype.strike()
__webpack_require__(14)('strike', function (createHTML) {
  return function strike() {
    return createHTML(this, 'strike', '', '');
  };
});


/***/ }),
/* 211 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.13 String.prototype.sub()
__webpack_require__(14)('sub', function (createHTML) {
  return function sub() {
    return createHTML(this, 'sub', '', '');
  };
});


/***/ }),
/* 212 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// B.2.3.14 String.prototype.sup()
__webpack_require__(14)('sup', function (createHTML) {
  return function sup() {
    return createHTML(this, 'sup', '', '');
  };
});


/***/ }),
/* 213 */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.3.1 / 15.9.4.4 Date.now()
var $export = __webpack_require__(0);

$export($export.S, 'Date', { now: function () { return new Date().getTime(); } });


/***/ }),
/* 214 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(9);
var toPrimitive = __webpack_require__(22);

$export($export.P + $export.F * __webpack_require__(3)(function () {
  return new Date(NaN).toJSON() !== null
    || Date.prototype.toJSON.call({ toISOString: function () { return 1; } }) !== 1;
}), 'Date', {
  // eslint-disable-next-line no-unused-vars
  toJSON: function toJSON(key) {
    var O = toObject(this);
    var pv = toPrimitive(O);
    return typeof pv == 'number' && !isFinite(pv) ? null : O.toISOString();
  }
});


/***/ }),
/* 215 */
/***/ (function(module, exports, __webpack_require__) {

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var $export = __webpack_require__(0);
var toISOString = __webpack_require__(216);

// PhantomJS / old WebKit has a broken implementations
$export($export.P + $export.F * (Date.prototype.toISOString !== toISOString), 'Date', {
  toISOString: toISOString
});


/***/ }),
/* 216 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 20.3.4.36 / 15.9.5.43 Date.prototype.toISOString()
var fails = __webpack_require__(3);
var getTime = Date.prototype.getTime;
var $toISOString = Date.prototype.toISOString;

var lz = function (num) {
  return num > 9 ? num : '0' + num;
};

// PhantomJS / old WebKit has a broken implementations
module.exports = (fails(function () {
  return $toISOString.call(new Date(-5e13 - 1)) != '0385-07-25T07:06:39.999Z';
}) || !fails(function () {
  $toISOString.call(new Date(NaN));
})) ? function toISOString() {
  if (!isFinite(getTime.call(this))) throw RangeError('Invalid time value');
  var d = this;
  var y = d.getUTCFullYear();
  var m = d.getUTCMilliseconds();
  var s = y < 0 ? '-' : y > 9999 ? '+' : '';
  return s + ('00000' + Math.abs(y)).slice(s ? -6 : -4) +
    '-' + lz(d.getUTCMonth() + 1) + '-' + lz(d.getUTCDate()) +
    'T' + lz(d.getUTCHours()) + ':' + lz(d.getUTCMinutes()) +
    ':' + lz(d.getUTCSeconds()) + '.' + (m > 99 ? m : '0' + lz(m)) + 'Z';
} : $toISOString;


/***/ }),
/* 217 */
/***/ (function(module, exports, __webpack_require__) {

var DateProto = Date.prototype;
var INVALID_DATE = 'Invalid Date';
var TO_STRING = 'toString';
var $toString = DateProto[TO_STRING];
var getTime = DateProto.getTime;
if (new Date(NaN) + '' != INVALID_DATE) {
  __webpack_require__(13)(DateProto, TO_STRING, function toString() {
    var value = getTime.call(this);
    // eslint-disable-next-line no-self-compare
    return value === value ? $toString.call(this) : INVALID_DATE;
  });
}


/***/ }),
/* 218 */
/***/ (function(module, exports, __webpack_require__) {

var TO_PRIMITIVE = __webpack_require__(5)('toPrimitive');
var proto = Date.prototype;

if (!(TO_PRIMITIVE in proto)) __webpack_require__(12)(proto, TO_PRIMITIVE, __webpack_require__(219));


/***/ }),
/* 219 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var anObject = __webpack_require__(1);
var toPrimitive = __webpack_require__(22);
var NUMBER = 'number';

module.exports = function (hint) {
  if (hint !== 'string' && hint !== NUMBER && hint !== 'default') throw TypeError('Incorrect hint');
  return toPrimitive(anObject(this), hint != NUMBER);
};


/***/ }),
/* 220 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.2.2 / 15.4.3.2 Array.isArray(arg)
var $export = __webpack_require__(0);

$export($export.S, 'Array', { isArray: __webpack_require__(53) });


/***/ }),
/* 221 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ctx = __webpack_require__(18);
var $export = __webpack_require__(0);
var toObject = __webpack_require__(9);
var call = __webpack_require__(107);
var isArrayIter = __webpack_require__(81);
var toLength = __webpack_require__(8);
var createProperty = __webpack_require__(82);
var getIterFn = __webpack_require__(83);

$export($export.S + $export.F * !__webpack_require__(55)(function (iter) { Array.from(iter); }), 'Array', {
  // 22.1.2.1 Array.from(arrayLike, mapfn = undefined, thisArg = undefined)
  from: function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
    var O = toObject(arrayLike);
    var C = typeof this == 'function' ? this : Array;
    var aLen = arguments.length;
    var mapfn = aLen > 1 ? arguments[1] : undefined;
    var mapping = mapfn !== undefined;
    var index = 0;
    var iterFn = getIterFn(O);
    var length, result, step, iterator;
    if (mapping) mapfn = ctx(mapfn, aLen > 2 ? arguments[2] : undefined, 2);
    // if object isn't iterable or it's array with default iterator - use simple case
    if (iterFn != undefined && !(C == Array && isArrayIter(iterFn))) {
      for (iterator = iterFn.call(O), result = new C(); !(step = iterator.next()).done; index++) {
        createProperty(result, index, mapping ? call(iterator, mapfn, [step.value, index], true) : step.value);
      }
    } else {
      length = toLength(O.length);
      for (result = new C(length); length > index; index++) {
        createProperty(result, index, mapping ? mapfn(O[index], index) : O[index]);
      }
    }
    result.length = index;
    return result;
  }
});


/***/ }),
/* 222 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var createProperty = __webpack_require__(82);

// WebKit Array.of isn't generic
$export($export.S + $export.F * __webpack_require__(3)(function () {
  function F() { /* empty */ }
  return !(Array.of.call(F) instanceof F);
}), 'Array', {
  // 22.1.2.3 Array.of( ...items)
  of: function of(/* ...args */) {
    var index = 0;
    var aLen = arguments.length;
    var result = new (typeof this == 'function' ? this : Array)(aLen);
    while (aLen > index) createProperty(result, index, arguments[index++]);
    result.length = aLen;
    return result;
  }
});


/***/ }),
/* 223 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.13 Array.prototype.join(separator)
var $export = __webpack_require__(0);
var toIObject = __webpack_require__(15);
var arrayJoin = [].join;

// fallback for not array-like strings
$export($export.P + $export.F * (__webpack_require__(47) != Object || !__webpack_require__(20)(arrayJoin)), 'Array', {
  join: function join(separator) {
    return arrayJoin.call(toIObject(this), separator === undefined ? ',' : separator);
  }
});


/***/ }),
/* 224 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var html = __webpack_require__(69);
var cof = __webpack_require__(19);
var toAbsoluteIndex = __webpack_require__(35);
var toLength = __webpack_require__(8);
var arraySlice = [].slice;

// fallback for not array-like ES3 strings and DOM objects
$export($export.P + $export.F * __webpack_require__(3)(function () {
  if (html) arraySlice.call(html);
}), 'Array', {
  slice: function slice(begin, end) {
    var len = toLength(this.length);
    var klass = cof(this);
    end = end === undefined ? len : end;
    if (klass == 'Array') return arraySlice.call(this, begin, end);
    var start = toAbsoluteIndex(begin, len);
    var upTo = toAbsoluteIndex(end, len);
    var size = toLength(upTo - start);
    var cloned = new Array(size);
    var i = 0;
    for (; i < size; i++) cloned[i] = klass == 'String'
      ? this.charAt(start + i)
      : this[start + i];
    return cloned;
  }
});


/***/ }),
/* 225 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var aFunction = __webpack_require__(10);
var toObject = __webpack_require__(9);
var fails = __webpack_require__(3);
var $sort = [].sort;
var test = [1, 2, 3];

$export($export.P + $export.F * (fails(function () {
  // IE8-
  test.sort(undefined);
}) || !fails(function () {
  // V8 bug
  test.sort(null);
  // Old WebKit
}) || !__webpack_require__(20)($sort)), 'Array', {
  // 22.1.3.25 Array.prototype.sort(comparefn)
  sort: function sort(comparefn) {
    return comparefn === undefined
      ? $sort.call(toObject(this))
      : $sort.call(toObject(this), aFunction(comparefn));
  }
});


/***/ }),
/* 226 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $forEach = __webpack_require__(26)(0);
var STRICT = __webpack_require__(20)([].forEach, true);

$export($export.P + $export.F * !STRICT, 'Array', {
  // 22.1.3.10 / 15.4.4.18 Array.prototype.forEach(callbackfn [, thisArg])
  forEach: function forEach(callbackfn /* , thisArg */) {
    return $forEach(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 227 */
/***/ (function(module, exports, __webpack_require__) {

var isObject = __webpack_require__(4);
var isArray = __webpack_require__(53);
var SPECIES = __webpack_require__(5)('species');

module.exports = function (original) {
  var C;
  if (isArray(original)) {
    C = original.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
    if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return C === undefined ? Array : C;
};


/***/ }),
/* 228 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $map = __webpack_require__(26)(1);

$export($export.P + $export.F * !__webpack_require__(20)([].map, true), 'Array', {
  // 22.1.3.15 / 15.4.4.19 Array.prototype.map(callbackfn [, thisArg])
  map: function map(callbackfn /* , thisArg */) {
    return $map(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 229 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $filter = __webpack_require__(26)(2);

$export($export.P + $export.F * !__webpack_require__(20)([].filter, true), 'Array', {
  // 22.1.3.7 / 15.4.4.20 Array.prototype.filter(callbackfn [, thisArg])
  filter: function filter(callbackfn /* , thisArg */) {
    return $filter(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 230 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $some = __webpack_require__(26)(3);

$export($export.P + $export.F * !__webpack_require__(20)([].some, true), 'Array', {
  // 22.1.3.23 / 15.4.4.17 Array.prototype.some(callbackfn [, thisArg])
  some: function some(callbackfn /* , thisArg */) {
    return $some(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 231 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $every = __webpack_require__(26)(4);

$export($export.P + $export.F * !__webpack_require__(20)([].every, true), 'Array', {
  // 22.1.3.5 / 15.4.4.16 Array.prototype.every(callbackfn [, thisArg])
  every: function every(callbackfn /* , thisArg */) {
    return $every(this, callbackfn, arguments[1]);
  }
});


/***/ }),
/* 232 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $reduce = __webpack_require__(108);

$export($export.P + $export.F * !__webpack_require__(20)([].reduce, true), 'Array', {
  // 22.1.3.18 / 15.4.4.21 Array.prototype.reduce(callbackfn [, initialValue])
  reduce: function reduce(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], false);
  }
});


/***/ }),
/* 233 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $reduce = __webpack_require__(108);

$export($export.P + $export.F * !__webpack_require__(20)([].reduceRight, true), 'Array', {
  // 22.1.3.19 / 15.4.4.22 Array.prototype.reduceRight(callbackfn [, initialValue])
  reduceRight: function reduceRight(callbackfn /* , initialValue */) {
    return $reduce(this, callbackfn, arguments.length, arguments[1], true);
  }
});


/***/ }),
/* 234 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $indexOf = __webpack_require__(51)(false);
var $native = [].indexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].indexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(20)($native)), 'Array', {
  // 22.1.3.11 / 15.4.4.14 Array.prototype.indexOf(searchElement [, fromIndex])
  indexOf: function indexOf(searchElement /* , fromIndex = 0 */) {
    return NEGATIVE_ZERO
      // convert -0 to +0
      ? $native.apply(this, arguments) || 0
      : $indexOf(this, searchElement, arguments[1]);
  }
});


/***/ }),
/* 235 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toIObject = __webpack_require__(15);
var toInteger = __webpack_require__(24);
var toLength = __webpack_require__(8);
var $native = [].lastIndexOf;
var NEGATIVE_ZERO = !!$native && 1 / [1].lastIndexOf(1, -0) < 0;

$export($export.P + $export.F * (NEGATIVE_ZERO || !__webpack_require__(20)($native)), 'Array', {
  // 22.1.3.14 / 15.4.4.15 Array.prototype.lastIndexOf(searchElement [, fromIndex])
  lastIndexOf: function lastIndexOf(searchElement /* , fromIndex = @[*-1] */) {
    // convert -0 to +0
    if (NEGATIVE_ZERO) return $native.apply(this, arguments) || 0;
    var O = toIObject(this);
    var length = toLength(O.length);
    var index = length - 1;
    if (arguments.length > 1) index = Math.min(index, toInteger(arguments[1]));
    if (index < 0) index = length + index;
    for (;index >= 0; index--) if (index in O) if (O[index] === searchElement) return index || 0;
    return -1;
  }
});


/***/ }),
/* 236 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.3 Array.prototype.copyWithin(target, start, end = this.length)
var $export = __webpack_require__(0);

$export($export.P, 'Array', { copyWithin: __webpack_require__(109) });

__webpack_require__(30)('copyWithin');


/***/ }),
/* 237 */
/***/ (function(module, exports, __webpack_require__) {

// 22.1.3.6 Array.prototype.fill(value, start = 0, end = this.length)
var $export = __webpack_require__(0);

$export($export.P, 'Array', { fill: __webpack_require__(85) });

__webpack_require__(30)('fill');


/***/ }),
/* 238 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.8 Array.prototype.find(predicate, thisArg = undefined)
var $export = __webpack_require__(0);
var $find = __webpack_require__(26)(5);
var KEY = 'find';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  find: function find(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(30)(KEY);


/***/ }),
/* 239 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 22.1.3.9 Array.prototype.findIndex(predicate, thisArg = undefined)
var $export = __webpack_require__(0);
var $find = __webpack_require__(26)(6);
var KEY = 'findIndex';
var forced = true;
// Shouldn't skip holes
if (KEY in []) Array(1)[KEY](function () { forced = false; });
$export($export.P + $export.F * forced, 'Array', {
  findIndex: function findIndex(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
__webpack_require__(30)(KEY);


/***/ }),
/* 240 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(38)('Array');


/***/ }),
/* 241 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(2);
var inheritIfRequired = __webpack_require__(72);
var dP = __webpack_require__(7).f;
var gOPN = __webpack_require__(37).f;
var isRegExp = __webpack_require__(54);
var $flags = __webpack_require__(56);
var $RegExp = global.RegExp;
var Base = $RegExp;
var proto = $RegExp.prototype;
var re1 = /a/g;
var re2 = /a/g;
// "new" creates a new object, old webkit buggy here
var CORRECT_NEW = new $RegExp(re1) !== re1;

if (__webpack_require__(6) && (!CORRECT_NEW || __webpack_require__(3)(function () {
  re2[__webpack_require__(5)('match')] = false;
  // RegExp constructor can alter flags and IsRegExp works correct with @@match
  return $RegExp(re1) != re1 || $RegExp(re2) == re2 || $RegExp(re1, 'i') != '/a/i';
}))) {
  $RegExp = function RegExp(p, f) {
    var tiRE = this instanceof $RegExp;
    var piRE = isRegExp(p);
    var fiU = f === undefined;
    return !tiRE && piRE && p.constructor === $RegExp && fiU ? p
      : inheritIfRequired(CORRECT_NEW
        ? new Base(piRE && !fiU ? p.source : p, f)
        : Base((piRE = p instanceof $RegExp) ? p.source : p, piRE && fiU ? $flags.call(p) : f)
      , tiRE ? this : proto, $RegExp);
  };
  var proxy = function (key) {
    key in $RegExp || dP($RegExp, key, {
      configurable: true,
      get: function () { return Base[key]; },
      set: function (it) { Base[key] = it; }
    });
  };
  for (var keys = gOPN(Base), i = 0; keys.length > i;) proxy(keys[i++]);
  proto.constructor = $RegExp;
  $RegExp.prototype = proto;
  __webpack_require__(13)(global, 'RegExp', $RegExp);
}

__webpack_require__(38)('RegExp');


/***/ }),
/* 242 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

__webpack_require__(111);
var anObject = __webpack_require__(1);
var $flags = __webpack_require__(56);
var DESCRIPTORS = __webpack_require__(6);
var TO_STRING = 'toString';
var $toString = /./[TO_STRING];

var define = function (fn) {
  __webpack_require__(13)(RegExp.prototype, TO_STRING, fn, true);
};

// 21.2.5.14 RegExp.prototype.toString()
if (__webpack_require__(3)(function () { return $toString.call({ source: 'a', flags: 'b' }) != '/a/b'; })) {
  define(function toString() {
    var R = anObject(this);
    return '/'.concat(R.source, '/',
      'flags' in R ? R.flags : !DESCRIPTORS && R instanceof RegExp ? $flags.call(R) : undefined);
  });
// FF44- RegExp#toString has a wrong name
} else if ($toString.name != TO_STRING) {
  define(function toString() {
    return $toString.call(this);
  });
}


/***/ }),
/* 243 */
/***/ (function(module, exports, __webpack_require__) {

// @@match logic
__webpack_require__(57)('match', 1, function (defined, MATCH, $match) {
  // 21.1.3.11 String.prototype.match(regexp)
  return [function match(regexp) {
    'use strict';
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[MATCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[MATCH](String(O));
  }, $match];
});


/***/ }),
/* 244 */
/***/ (function(module, exports, __webpack_require__) {

// @@replace logic
__webpack_require__(57)('replace', 2, function (defined, REPLACE, $replace) {
  // 21.1.3.14 String.prototype.replace(searchValue, replaceValue)
  return [function replace(searchValue, replaceValue) {
    'use strict';
    var O = defined(this);
    var fn = searchValue == undefined ? undefined : searchValue[REPLACE];
    return fn !== undefined
      ? fn.call(searchValue, O, replaceValue)
      : $replace.call(String(O), searchValue, replaceValue);
  }, $replace];
});


/***/ }),
/* 245 */
/***/ (function(module, exports, __webpack_require__) {

// @@search logic
__webpack_require__(57)('search', 1, function (defined, SEARCH, $search) {
  // 21.1.3.15 String.prototype.search(regexp)
  return [function search(regexp) {
    'use strict';
    var O = defined(this);
    var fn = regexp == undefined ? undefined : regexp[SEARCH];
    return fn !== undefined ? fn.call(regexp, O) : new RegExp(regexp)[SEARCH](String(O));
  }, $search];
});


/***/ }),
/* 246 */
/***/ (function(module, exports, __webpack_require__) {

// @@split logic
__webpack_require__(57)('split', 2, function (defined, SPLIT, $split) {
  'use strict';
  var isRegExp = __webpack_require__(54);
  var _split = $split;
  var $push = [].push;
  var $SPLIT = 'split';
  var LENGTH = 'length';
  var LAST_INDEX = 'lastIndex';
  if (
    'abbc'[$SPLIT](/(b)*/)[1] == 'c' ||
    'test'[$SPLIT](/(?:)/, -1)[LENGTH] != 4 ||
    'ab'[$SPLIT](/(?:ab)*/)[LENGTH] != 2 ||
    '.'[$SPLIT](/(.?)(.?)/)[LENGTH] != 4 ||
    '.'[$SPLIT](/()()/)[LENGTH] > 1 ||
    ''[$SPLIT](/.?/)[LENGTH]
  ) {
    var NPCG = /()??/.exec('')[1] === undefined; // nonparticipating capturing group
    // based on es5-shim implementation, need to rework it
    $split = function (separator, limit) {
      var string = String(this);
      if (separator === undefined && limit === 0) return [];
      // If `separator` is not a regex, use native split
      if (!isRegExp(separator)) return _split.call(string, separator, limit);
      var output = [];
      var flags = (separator.ignoreCase ? 'i' : '') +
                  (separator.multiline ? 'm' : '') +
                  (separator.unicode ? 'u' : '') +
                  (separator.sticky ? 'y' : '');
      var lastLastIndex = 0;
      var splitLimit = limit === undefined ? 4294967295 : limit >>> 0;
      // Make `global` and avoid `lastIndex` issues by working with a copy
      var separatorCopy = new RegExp(separator.source, flags + 'g');
      var separator2, match, lastIndex, lastLength, i;
      // Doesn't need flags gy, but they don't hurt
      if (!NPCG) separator2 = new RegExp('^' + separatorCopy.source + '$(?!\\s)', flags);
      while (match = separatorCopy.exec(string)) {
        // `separatorCopy.lastIndex` is not reliable cross-browser
        lastIndex = match.index + match[0][LENGTH];
        if (lastIndex > lastLastIndex) {
          output.push(string.slice(lastLastIndex, match.index));
          // Fix browsers whose `exec` methods don't consistently return `undefined` for NPCG
          // eslint-disable-next-line no-loop-func
          if (!NPCG && match[LENGTH] > 1) match[0].replace(separator2, function () {
            for (i = 1; i < arguments[LENGTH] - 2; i++) if (arguments[i] === undefined) match[i] = undefined;
          });
          if (match[LENGTH] > 1 && match.index < string[LENGTH]) $push.apply(output, match.slice(1));
          lastLength = match[0][LENGTH];
          lastLastIndex = lastIndex;
          if (output[LENGTH] >= splitLimit) break;
        }
        if (separatorCopy[LAST_INDEX] === match.index) separatorCopy[LAST_INDEX]++; // Avoid an infinite loop
      }
      if (lastLastIndex === string[LENGTH]) {
        if (lastLength || !separatorCopy.test('')) output.push('');
      } else output.push(string.slice(lastLastIndex));
      return output[LENGTH] > splitLimit ? output.slice(0, splitLimit) : output;
    };
  // Chakra, V8
  } else if ('0'[$SPLIT](undefined, 0)[LENGTH]) {
    $split = function (separator, limit) {
      return separator === undefined && limit === 0 ? [] : _split.call(this, separator, limit);
    };
  }
  // 21.1.3.17 String.prototype.split(separator, limit)
  return [function split(separator, limit) {
    var O = defined(this);
    var fn = separator == undefined ? undefined : separator[SPLIT];
    return fn !== undefined ? fn.call(separator, O, limit) : $split.call(String(O), separator, limit);
  }, $split];
});


/***/ }),
/* 247 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var LIBRARY = __webpack_require__(33);
var global = __webpack_require__(2);
var ctx = __webpack_require__(18);
var classof = __webpack_require__(49);
var $export = __webpack_require__(0);
var isObject = __webpack_require__(4);
var aFunction = __webpack_require__(10);
var anInstance = __webpack_require__(39);
var forOf = __webpack_require__(40);
var speciesConstructor = __webpack_require__(58);
var task = __webpack_require__(87).set;
var microtask = __webpack_require__(88)();
var newPromiseCapabilityModule = __webpack_require__(89);
var perform = __webpack_require__(112);
var promiseResolve = __webpack_require__(113);
var PROMISE = 'Promise';
var TypeError = global.TypeError;
var process = global.process;
var $Promise = global[PROMISE];
var isNode = classof(process) == 'process';
var empty = function () { /* empty */ };
var Internal, newGenericPromiseCapability, OwnPromiseCapability, Wrapper;
var newPromiseCapability = newGenericPromiseCapability = newPromiseCapabilityModule.f;

var USE_NATIVE = !!function () {
  try {
    // correct subclassing with @@species support
    var promise = $Promise.resolve(1);
    var FakePromise = (promise.constructor = {})[__webpack_require__(5)('species')] = function (exec) {
      exec(empty, empty);
    };
    // unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    return (isNode || typeof PromiseRejectionEvent == 'function') && promise.then(empty) instanceof FakePromise;
  } catch (e) { /* empty */ }
}();

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && typeof (then = it.then) == 'function' ? then : false;
};
var notify = function (promise, isReject) {
  if (promise._n) return;
  promise._n = true;
  var chain = promise._c;
  microtask(function () {
    var value = promise._v;
    var ok = promise._s == 1;
    var i = 0;
    var run = function (reaction) {
      var handler = ok ? reaction.ok : reaction.fail;
      var resolve = reaction.resolve;
      var reject = reaction.reject;
      var domain = reaction.domain;
      var result, then;
      try {
        if (handler) {
          if (!ok) {
            if (promise._h == 2) onHandleUnhandled(promise);
            promise._h = 1;
          }
          if (handler === true) result = value;
          else {
            if (domain) domain.enter();
            result = handler(value);
            if (domain) domain.exit();
          }
          if (result === reaction.promise) {
            reject(TypeError('Promise-chain cycle'));
          } else if (then = isThenable(result)) {
            then.call(result, resolve, reject);
          } else resolve(result);
        } else reject(value);
      } catch (e) {
        reject(e);
      }
    };
    while (chain.length > i) run(chain[i++]); // variable length - can't use forEach
    promise._c = [];
    promise._n = false;
    if (isReject && !promise._h) onUnhandled(promise);
  });
};
var onUnhandled = function (promise) {
  task.call(global, function () {
    var value = promise._v;
    var unhandled = isUnhandled(promise);
    var result, handler, console;
    if (unhandled) {
      result = perform(function () {
        if (isNode) {
          process.emit('unhandledRejection', value, promise);
        } else if (handler = global.onunhandledrejection) {
          handler({ promise: promise, reason: value });
        } else if ((console = global.console) && console.error) {
          console.error('Unhandled promise rejection', value);
        }
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      promise._h = isNode || isUnhandled(promise) ? 2 : 1;
    } promise._a = undefined;
    if (unhandled && result.e) throw result.v;
  });
};
var isUnhandled = function (promise) {
  return promise._h !== 1 && (promise._a || promise._c).length === 0;
};
var onHandleUnhandled = function (promise) {
  task.call(global, function () {
    var handler;
    if (isNode) {
      process.emit('rejectionHandled', promise);
    } else if (handler = global.onrejectionhandled) {
      handler({ promise: promise, reason: promise._v });
    }
  });
};
var $reject = function (value) {
  var promise = this;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  promise._v = value;
  promise._s = 2;
  if (!promise._a) promise._a = promise._c.slice();
  notify(promise, true);
};
var $resolve = function (value) {
  var promise = this;
  var then;
  if (promise._d) return;
  promise._d = true;
  promise = promise._w || promise; // unwrap
  try {
    if (promise === value) throw TypeError("Promise can't be resolved itself");
    if (then = isThenable(value)) {
      microtask(function () {
        var wrapper = { _w: promise, _d: false }; // wrap
        try {
          then.call(value, ctx($resolve, wrapper, 1), ctx($reject, wrapper, 1));
        } catch (e) {
          $reject.call(wrapper, e);
        }
      });
    } else {
      promise._v = value;
      promise._s = 1;
      notify(promise, false);
    }
  } catch (e) {
    $reject.call({ _w: promise, _d: false }, e); // wrap
  }
};

// constructor polyfill
if (!USE_NATIVE) {
  // 25.4.3.1 Promise(executor)
  $Promise = function Promise(executor) {
    anInstance(this, $Promise, PROMISE, '_h');
    aFunction(executor);
    Internal.call(this);
    try {
      executor(ctx($resolve, this, 1), ctx($reject, this, 1));
    } catch (err) {
      $reject.call(this, err);
    }
  };
  // eslint-disable-next-line no-unused-vars
  Internal = function Promise(executor) {
    this._c = [];             // <- awaiting reactions
    this._a = undefined;      // <- checked in isUnhandled reactions
    this._s = 0;              // <- state
    this._d = false;          // <- done
    this._v = undefined;      // <- value
    this._h = 0;              // <- rejection state, 0 - default, 1 - handled, 2 - unhandled
    this._n = false;          // <- notify
  };
  Internal.prototype = __webpack_require__(41)($Promise.prototype, {
    // 25.4.5.3 Promise.prototype.then(onFulfilled, onRejected)
    then: function then(onFulfilled, onRejected) {
      var reaction = newPromiseCapability(speciesConstructor(this, $Promise));
      reaction.ok = typeof onFulfilled == 'function' ? onFulfilled : true;
      reaction.fail = typeof onRejected == 'function' && onRejected;
      reaction.domain = isNode ? process.domain : undefined;
      this._c.push(reaction);
      if (this._a) this._a.push(reaction);
      if (this._s) notify(this, false);
      return reaction.promise;
    },
    // 25.4.5.1 Promise.prototype.catch(onRejected)
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    this.promise = promise;
    this.resolve = ctx($resolve, promise, 1);
    this.reject = ctx($reject, promise, 1);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === $Promise || C === Wrapper
      ? new OwnPromiseCapability(C)
      : newGenericPromiseCapability(C);
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Promise: $Promise });
__webpack_require__(42)($Promise, PROMISE);
__webpack_require__(38)(PROMISE);
Wrapper = __webpack_require__(21)[PROMISE];

// statics
$export($export.S + $export.F * !USE_NATIVE, PROMISE, {
  // 25.4.4.5 Promise.reject(r)
  reject: function reject(r) {
    var capability = newPromiseCapability(this);
    var $$reject = capability.reject;
    $$reject(r);
    return capability.promise;
  }
});
$export($export.S + $export.F * (LIBRARY || !USE_NATIVE), PROMISE, {
  // 25.4.4.6 Promise.resolve(x)
  resolve: function resolve(x) {
    return promiseResolve(LIBRARY && this === Wrapper ? $Promise : this, x);
  }
});
$export($export.S + $export.F * !(USE_NATIVE && __webpack_require__(55)(function (iter) {
  $Promise.all(iter)['catch'](empty);
})), PROMISE, {
  // 25.4.4.1 Promise.all(iterable)
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var values = [];
      var index = 0;
      var remaining = 1;
      forOf(iterable, false, function (promise) {
        var $index = index++;
        var alreadyCalled = false;
        values.push(undefined);
        remaining++;
        C.resolve(promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[$index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.e) reject(result.v);
    return capability.promise;
  },
  // 25.4.4.4 Promise.race(iterable)
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapability(C);
    var reject = capability.reject;
    var result = perform(function () {
      forOf(iterable, false, function (promise) {
        C.resolve(promise).then(capability.resolve, reject);
      });
    });
    if (result.e) reject(result.v);
    return capability.promise;
  }
});


/***/ }),
/* 248 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var weak = __webpack_require__(118);
var validate = __webpack_require__(45);
var WEAK_SET = 'WeakSet';

// 23.4 WeakSet Objects
__webpack_require__(59)(WEAK_SET, function (get) {
  return function WeakSet() { return get(this, arguments.length > 0 ? arguments[0] : undefined); };
}, {
  // 23.4.3.1 WeakSet.prototype.add(value)
  add: function add(value) {
    return weak.def(validate(this, WEAK_SET), value, true);
  }
}, weak, false, true);


/***/ }),
/* 249 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var $typed = __webpack_require__(60);
var buffer = __webpack_require__(90);
var anObject = __webpack_require__(1);
var toAbsoluteIndex = __webpack_require__(35);
var toLength = __webpack_require__(8);
var isObject = __webpack_require__(4);
var ArrayBuffer = __webpack_require__(2).ArrayBuffer;
var speciesConstructor = __webpack_require__(58);
var $ArrayBuffer = buffer.ArrayBuffer;
var $DataView = buffer.DataView;
var $isView = $typed.ABV && ArrayBuffer.isView;
var $slice = $ArrayBuffer.prototype.slice;
var VIEW = $typed.VIEW;
var ARRAY_BUFFER = 'ArrayBuffer';

$export($export.G + $export.W + $export.F * (ArrayBuffer !== $ArrayBuffer), { ArrayBuffer: $ArrayBuffer });

$export($export.S + $export.F * !$typed.CONSTR, ARRAY_BUFFER, {
  // 24.1.3.1 ArrayBuffer.isView(arg)
  isView: function isView(it) {
    return $isView && $isView(it) || isObject(it) && VIEW in it;
  }
});

$export($export.P + $export.U + $export.F * __webpack_require__(3)(function () {
  return !new $ArrayBuffer(2).slice(1, undefined).byteLength;
}), ARRAY_BUFFER, {
  // 24.1.4.3 ArrayBuffer.prototype.slice(start, end)
  slice: function slice(start, end) {
    if ($slice !== undefined && end === undefined) return $slice.call(anObject(this), start); // FF fix
    var len = anObject(this).byteLength;
    var first = toAbsoluteIndex(start, len);
    var final = toAbsoluteIndex(end === undefined ? len : end, len);
    var result = new (speciesConstructor(this, $ArrayBuffer))(toLength(final - first));
    var viewS = new $DataView(this);
    var viewT = new $DataView(result);
    var index = 0;
    while (first < final) {
      viewT.setUint8(index++, viewS.getUint8(first++));
    } return result;
  }
});

__webpack_require__(38)(ARRAY_BUFFER);


/***/ }),
/* 250 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
$export($export.G + $export.W + $export.F * !__webpack_require__(60).ABV, {
  DataView: __webpack_require__(90).DataView
});


/***/ }),
/* 251 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Int8', 1, function (init) {
  return function Int8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 252 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Uint8', 1, function (init) {
  return function Uint8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 253 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Uint8', 1, function (init) {
  return function Uint8ClampedArray(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
}, true);


/***/ }),
/* 254 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Int16', 2, function (init) {
  return function Int16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 255 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Uint16', 2, function (init) {
  return function Uint16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 256 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Int32', 4, function (init) {
  return function Int32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 257 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Uint32', 4, function (init) {
  return function Uint32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 258 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Float32', 4, function (init) {
  return function Float32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 259 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(27)('Float64', 8, function (init) {
  return function Float64Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});


/***/ }),
/* 260 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.1 Reflect.apply(target, thisArgument, argumentsList)
var $export = __webpack_require__(0);
var aFunction = __webpack_require__(10);
var anObject = __webpack_require__(1);
var rApply = (__webpack_require__(2).Reflect || {}).apply;
var fApply = Function.apply;
// MS Edge argumentsList argument is optional
$export($export.S + $export.F * !__webpack_require__(3)(function () {
  rApply(function () { /* empty */ });
}), 'Reflect', {
  apply: function apply(target, thisArgument, argumentsList) {
    var T = aFunction(target);
    var L = anObject(argumentsList);
    return rApply ? rApply(T, thisArgument, L) : fApply.call(T, thisArgument, L);
  }
});


/***/ }),
/* 261 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.2 Reflect.construct(target, argumentsList [, newTarget])
var $export = __webpack_require__(0);
var create = __webpack_require__(36);
var aFunction = __webpack_require__(10);
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);
var fails = __webpack_require__(3);
var bind = __webpack_require__(99);
var rConstruct = (__webpack_require__(2).Reflect || {}).construct;

// MS Edge supports only 2 arguments and argumentsList argument is optional
// FF Nightly sets third argument as `new.target`, but does not create `this` from it
var NEW_TARGET_BUG = fails(function () {
  function F() { /* empty */ }
  return !(rConstruct(function () { /* empty */ }, [], F) instanceof F);
});
var ARGS_BUG = !fails(function () {
  rConstruct(function () { /* empty */ });
});

$export($export.S + $export.F * (NEW_TARGET_BUG || ARGS_BUG), 'Reflect', {
  construct: function construct(Target, args /* , newTarget */) {
    aFunction(Target);
    anObject(args);
    var newTarget = arguments.length < 3 ? Target : aFunction(arguments[2]);
    if (ARGS_BUG && !NEW_TARGET_BUG) return rConstruct(Target, args, newTarget);
    if (Target == newTarget) {
      // w/o altered newTarget, optimization for 0-4 arguments
      switch (args.length) {
        case 0: return new Target();
        case 1: return new Target(args[0]);
        case 2: return new Target(args[0], args[1]);
        case 3: return new Target(args[0], args[1], args[2]);
        case 4: return new Target(args[0], args[1], args[2], args[3]);
      }
      // w/o altered newTarget, lot of arguments case
      var $args = [null];
      $args.push.apply($args, args);
      return new (bind.apply(Target, $args))();
    }
    // with altered newTarget, not support built-in constructors
    var proto = newTarget.prototype;
    var instance = create(isObject(proto) ? proto : Object.prototype);
    var result = Function.apply.call(Target, instance, args);
    return isObject(result) ? result : instance;
  }
});


/***/ }),
/* 262 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.3 Reflect.defineProperty(target, propertyKey, attributes)
var dP = __webpack_require__(7);
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var toPrimitive = __webpack_require__(22);

// MS Edge has broken Reflect.defineProperty - throwing instead of returning false
$export($export.S + $export.F * __webpack_require__(3)(function () {
  // eslint-disable-next-line no-undef
  Reflect.defineProperty(dP.f({}, 1, { value: 1 }), 1, { value: 2 });
}), 'Reflect', {
  defineProperty: function defineProperty(target, propertyKey, attributes) {
    anObject(target);
    propertyKey = toPrimitive(propertyKey, true);
    anObject(attributes);
    try {
      dP.f(target, propertyKey, attributes);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 263 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.4 Reflect.deleteProperty(target, propertyKey)
var $export = __webpack_require__(0);
var gOPD = __webpack_require__(16).f;
var anObject = __webpack_require__(1);

$export($export.S, 'Reflect', {
  deleteProperty: function deleteProperty(target, propertyKey) {
    var desc = gOPD(anObject(target), propertyKey);
    return desc && !desc.configurable ? false : delete target[propertyKey];
  }
});


/***/ }),
/* 264 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// 26.1.5 Reflect.enumerate(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var Enumerate = function (iterated) {
  this._t = anObject(iterated); // target
  this._i = 0;                  // next index
  var keys = this._k = [];      // keys
  var key;
  for (key in iterated) keys.push(key);
};
__webpack_require__(78)(Enumerate, 'Object', function () {
  var that = this;
  var keys = that._k;
  var key;
  do {
    if (that._i >= keys.length) return { value: undefined, done: true };
  } while (!((key = keys[that._i++]) in that._t));
  return { value: key, done: false };
});

$export($export.S, 'Reflect', {
  enumerate: function enumerate(target) {
    return new Enumerate(target);
  }
});


/***/ }),
/* 265 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.6 Reflect.get(target, propertyKey [, receiver])
var gOPD = __webpack_require__(16);
var getPrototypeOf = __webpack_require__(17);
var has = __webpack_require__(11);
var $export = __webpack_require__(0);
var isObject = __webpack_require__(4);
var anObject = __webpack_require__(1);

function get(target, propertyKey /* , receiver */) {
  var receiver = arguments.length < 3 ? target : arguments[2];
  var desc, proto;
  if (anObject(target) === receiver) return target[propertyKey];
  if (desc = gOPD.f(target, propertyKey)) return has(desc, 'value')
    ? desc.value
    : desc.get !== undefined
      ? desc.get.call(receiver)
      : undefined;
  if (isObject(proto = getPrototypeOf(target))) return get(proto, propertyKey, receiver);
}

$export($export.S, 'Reflect', { get: get });


/***/ }),
/* 266 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.7 Reflect.getOwnPropertyDescriptor(target, propertyKey)
var gOPD = __webpack_require__(16);
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);

$export($export.S, 'Reflect', {
  getOwnPropertyDescriptor: function getOwnPropertyDescriptor(target, propertyKey) {
    return gOPD.f(anObject(target), propertyKey);
  }
});


/***/ }),
/* 267 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.8 Reflect.getPrototypeOf(target)
var $export = __webpack_require__(0);
var getProto = __webpack_require__(17);
var anObject = __webpack_require__(1);

$export($export.S, 'Reflect', {
  getPrototypeOf: function getPrototypeOf(target) {
    return getProto(anObject(target));
  }
});


/***/ }),
/* 268 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.9 Reflect.has(target, propertyKey)
var $export = __webpack_require__(0);

$export($export.S, 'Reflect', {
  has: function has(target, propertyKey) {
    return propertyKey in target;
  }
});


/***/ }),
/* 269 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.10 Reflect.isExtensible(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var $isExtensible = Object.isExtensible;

$export($export.S, 'Reflect', {
  isExtensible: function isExtensible(target) {
    anObject(target);
    return $isExtensible ? $isExtensible(target) : true;
  }
});


/***/ }),
/* 270 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.11 Reflect.ownKeys(target)
var $export = __webpack_require__(0);

$export($export.S, 'Reflect', { ownKeys: __webpack_require__(120) });


/***/ }),
/* 271 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.12 Reflect.preventExtensions(target)
var $export = __webpack_require__(0);
var anObject = __webpack_require__(1);
var $preventExtensions = Object.preventExtensions;

$export($export.S, 'Reflect', {
  preventExtensions: function preventExtensions(target) {
    anObject(target);
    try {
      if ($preventExtensions) $preventExtensions(target);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 272 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.13 Reflect.set(target, propertyKey, V [, receiver])
var dP = __webpack_require__(7);
var gOPD = __webpack_require__(16);
var getPrototypeOf = __webpack_require__(17);
var has = __webpack_require__(11);
var $export = __webpack_require__(0);
var createDesc = __webpack_require__(31);
var anObject = __webpack_require__(1);
var isObject = __webpack_require__(4);

function set(target, propertyKey, V /* , receiver */) {
  var receiver = arguments.length < 4 ? target : arguments[3];
  var ownDesc = gOPD.f(anObject(target), propertyKey);
  var existingDescriptor, proto;
  if (!ownDesc) {
    if (isObject(proto = getPrototypeOf(target))) {
      return set(proto, propertyKey, V, receiver);
    }
    ownDesc = createDesc(0);
  }
  if (has(ownDesc, 'value')) {
    if (ownDesc.writable === false || !isObject(receiver)) return false;
    existingDescriptor = gOPD.f(receiver, propertyKey) || createDesc(0);
    existingDescriptor.value = V;
    dP.f(receiver, propertyKey, existingDescriptor);
    return true;
  }
  return ownDesc.set === undefined ? false : (ownDesc.set.call(receiver, V), true);
}

$export($export.S, 'Reflect', { set: set });


/***/ }),
/* 273 */
/***/ (function(module, exports, __webpack_require__) {

// 26.1.14 Reflect.setPrototypeOf(target, proto)
var $export = __webpack_require__(0);
var setProto = __webpack_require__(70);

if (setProto) $export($export.S, 'Reflect', {
  setPrototypeOf: function setPrototypeOf(target, proto) {
    setProto.check(target, proto);
    try {
      setProto.set(target, proto);
      return true;
    } catch (e) {
      return false;
    }
  }
});


/***/ }),
/* 274 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/Array.prototype.includes
var $export = __webpack_require__(0);
var $includes = __webpack_require__(51)(true);

$export($export.P, 'Array', {
  includes: function includes(el /* , fromIndex = 0 */) {
    return $includes(this, el, arguments.length > 1 ? arguments[1] : undefined);
  }
});

__webpack_require__(30)('includes');


/***/ }),
/* 275 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatMap
var $export = __webpack_require__(0);
var flattenIntoArray = __webpack_require__(121);
var toObject = __webpack_require__(9);
var toLength = __webpack_require__(8);
var aFunction = __webpack_require__(10);
var arraySpeciesCreate = __webpack_require__(84);

$export($export.P, 'Array', {
  flatMap: function flatMap(callbackfn /* , thisArg */) {
    var O = toObject(this);
    var sourceLen, A;
    aFunction(callbackfn);
    sourceLen = toLength(O.length);
    A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, 1, callbackfn, arguments[1]);
    return A;
  }
});

__webpack_require__(30)('flatMap');


/***/ }),
/* 276 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/proposal-flatMap/#sec-Array.prototype.flatten
var $export = __webpack_require__(0);
var flattenIntoArray = __webpack_require__(121);
var toObject = __webpack_require__(9);
var toLength = __webpack_require__(8);
var toInteger = __webpack_require__(24);
var arraySpeciesCreate = __webpack_require__(84);

$export($export.P, 'Array', {
  flatten: function flatten(/* depthArg = 1 */) {
    var depthArg = arguments[0];
    var O = toObject(this);
    var sourceLen = toLength(O.length);
    var A = arraySpeciesCreate(O, 0);
    flattenIntoArray(A, O, O, sourceLen, 0, depthArg === undefined ? 1 : toInteger(depthArg));
    return A;
  }
});

__webpack_require__(30)('flatten');


/***/ }),
/* 277 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/mathiasbynens/String.prototype.at
var $export = __webpack_require__(0);
var $at = __webpack_require__(76)(true);

$export($export.P, 'String', {
  at: function at(pos) {
    return $at(this, pos);
  }
});


/***/ }),
/* 278 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(0);
var $pad = __webpack_require__(122);
var userAgent = __webpack_require__(91);

// https://github.com/zloirock/core-js/issues/280
$export($export.P + $export.F * /Version\/10\.\d+(\.\d+)? Safari\//.test(userAgent), 'String', {
  padStart: function padStart(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, true);
  }
});


/***/ }),
/* 279 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-string-pad-start-end
var $export = __webpack_require__(0);
var $pad = __webpack_require__(122);
var userAgent = __webpack_require__(91);

// https://github.com/zloirock/core-js/issues/280
$export($export.P + $export.F * /Version\/10\.\d+(\.\d+)? Safari\//.test(userAgent), 'String', {
  padEnd: function padEnd(maxLength /* , fillString = ' ' */) {
    return $pad(this, maxLength, arguments.length > 1 ? arguments[1] : undefined, false);
  }
});


/***/ }),
/* 280 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(43)('trimLeft', function ($trim) {
  return function trimLeft() {
    return $trim(this, 1);
  };
}, 'trimStart');


/***/ }),
/* 281 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/sebmarkbage/ecmascript-string-left-right-trim
__webpack_require__(43)('trimRight', function ($trim) {
  return function trimRight() {
    return $trim(this, 2);
  };
}, 'trimEnd');


/***/ }),
/* 282 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://tc39.github.io/String.prototype.matchAll/
var $export = __webpack_require__(0);
var defined = __webpack_require__(23);
var toLength = __webpack_require__(8);
var isRegExp = __webpack_require__(54);
var getFlags = __webpack_require__(56);
var RegExpProto = RegExp.prototype;

var $RegExpStringIterator = function (regexp, string) {
  this._r = regexp;
  this._s = string;
};

__webpack_require__(78)($RegExpStringIterator, 'RegExp String', function next() {
  var match = this._r.exec(this._s);
  return { value: match, done: match === null };
});

$export($export.P, 'String', {
  matchAll: function matchAll(regexp) {
    defined(this);
    if (!isRegExp(regexp)) throw TypeError(regexp + ' is not a regexp!');
    var S = String(this);
    var flags = 'flags' in RegExpProto ? String(regexp.flags) : getFlags.call(regexp);
    var rx = new RegExp(regexp.source, ~flags.indexOf('g') ? flags : 'g' + flags);
    rx.lastIndex = toLength(regexp.lastIndex);
    return new $RegExpStringIterator(rx, S);
  }
});


/***/ }),
/* 283 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(66)('asyncIterator');


/***/ }),
/* 284 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(66)('observable');


/***/ }),
/* 285 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-getownpropertydescriptors
var $export = __webpack_require__(0);
var ownKeys = __webpack_require__(120);
var toIObject = __webpack_require__(15);
var gOPD = __webpack_require__(16);
var createProperty = __webpack_require__(82);

$export($export.S, 'Object', {
  getOwnPropertyDescriptors: function getOwnPropertyDescriptors(object) {
    var O = toIObject(object);
    var getDesc = gOPD.f;
    var keys = ownKeys(O);
    var result = {};
    var i = 0;
    var key, desc;
    while (keys.length > i) {
      desc = getDesc(O, key = keys[i++]);
      if (desc !== undefined) createProperty(result, key, desc);
    }
    return result;
  }
});


/***/ }),
/* 286 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(0);
var $values = __webpack_require__(123)(false);

$export($export.S, 'Object', {
  values: function values(it) {
    return $values(it);
  }
});


/***/ }),
/* 287 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-object-values-entries
var $export = __webpack_require__(0);
var $entries = __webpack_require__(123)(true);

$export($export.S, 'Object', {
  entries: function entries(it) {
    return $entries(it);
  }
});


/***/ }),
/* 288 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(9);
var aFunction = __webpack_require__(10);
var $defineProperty = __webpack_require__(7);

// B.2.2.2 Object.prototype.__defineGetter__(P, getter)
__webpack_require__(6) && $export($export.P + __webpack_require__(61), 'Object', {
  __defineGetter__: function __defineGetter__(P, getter) {
    $defineProperty.f(toObject(this), P, { get: aFunction(getter), enumerable: true, configurable: true });
  }
});


/***/ }),
/* 289 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(9);
var aFunction = __webpack_require__(10);
var $defineProperty = __webpack_require__(7);

// B.2.2.3 Object.prototype.__defineSetter__(P, setter)
__webpack_require__(6) && $export($export.P + __webpack_require__(61), 'Object', {
  __defineSetter__: function __defineSetter__(P, setter) {
    $defineProperty.f(toObject(this), P, { set: aFunction(setter), enumerable: true, configurable: true });
  }
});


/***/ }),
/* 290 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(9);
var toPrimitive = __webpack_require__(22);
var getPrototypeOf = __webpack_require__(17);
var getOwnPropertyDescriptor = __webpack_require__(16).f;

// B.2.2.4 Object.prototype.__lookupGetter__(P)
__webpack_require__(6) && $export($export.P + __webpack_require__(61), 'Object', {
  __lookupGetter__: function __lookupGetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.get;
    } while (O = getPrototypeOf(O));
  }
});


/***/ }),
/* 291 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var $export = __webpack_require__(0);
var toObject = __webpack_require__(9);
var toPrimitive = __webpack_require__(22);
var getPrototypeOf = __webpack_require__(17);
var getOwnPropertyDescriptor = __webpack_require__(16).f;

// B.2.2.5 Object.prototype.__lookupSetter__(P)
__webpack_require__(6) && $export($export.P + __webpack_require__(61), 'Object', {
  __lookupSetter__: function __lookupSetter__(P) {
    var O = toObject(this);
    var K = toPrimitive(P, true);
    var D;
    do {
      if (D = getOwnPropertyDescriptor(O, K)) return D.set;
    } while (O = getPrototypeOf(O));
  }
});


/***/ }),
/* 292 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(0);

$export($export.P + $export.R, 'Map', { toJSON: __webpack_require__(124)('Map') });


/***/ }),
/* 293 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/DavidBruant/Map-Set.prototype.toJSON
var $export = __webpack_require__(0);

$export($export.P + $export.R, 'Set', { toJSON: __webpack_require__(124)('Set') });


/***/ }),
/* 294 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.of
__webpack_require__(62)('Map');


/***/ }),
/* 295 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.of
__webpack_require__(62)('Set');


/***/ }),
/* 296 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.of
__webpack_require__(62)('WeakMap');


/***/ }),
/* 297 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.of
__webpack_require__(62)('WeakSet');


/***/ }),
/* 298 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-map.from
__webpack_require__(63)('Map');


/***/ }),
/* 299 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-set.from
__webpack_require__(63)('Set');


/***/ }),
/* 300 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakmap.from
__webpack_require__(63)('WeakMap');


/***/ }),
/* 301 */
/***/ (function(module, exports, __webpack_require__) {

// https://tc39.github.io/proposal-setmap-offrom/#sec-weakset.from
__webpack_require__(63)('WeakSet');


/***/ }),
/* 302 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(0);

$export($export.G, { global: __webpack_require__(2) });


/***/ }),
/* 303 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/tc39/proposal-global
var $export = __webpack_require__(0);

$export($export.S, 'System', { global: __webpack_require__(2) });


/***/ }),
/* 304 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/ljharb/proposal-is-error
var $export = __webpack_require__(0);
var cof = __webpack_require__(19);

$export($export.S, 'Error', {
  isError: function isError(it) {
    return cof(it) === 'Error';
  }
});


/***/ }),
/* 305 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  clamp: function clamp(x, lower, upper) {
    return Math.min(upper, Math.max(lower, x));
  }
});


/***/ }),
/* 306 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { DEG_PER_RAD: Math.PI / 180 });


/***/ }),
/* 307 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var RAD_PER_DEG = 180 / Math.PI;

$export($export.S, 'Math', {
  degrees: function degrees(radians) {
    return radians * RAD_PER_DEG;
  }
});


/***/ }),
/* 308 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var scale = __webpack_require__(126);
var fround = __webpack_require__(106);

$export($export.S, 'Math', {
  fscale: function fscale(x, inLow, inHigh, outLow, outHigh) {
    return fround(scale(x, inLow, inHigh, outLow, outHigh));
  }
});


/***/ }),
/* 309 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  iaddh: function iaddh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 + (y1 >>> 0) + (($x0 & $y0 | ($x0 | $y0) & ~($x0 + $y0 >>> 0)) >>> 31) | 0;
  }
});


/***/ }),
/* 310 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  isubh: function isubh(x0, x1, y0, y1) {
    var $x0 = x0 >>> 0;
    var $x1 = x1 >>> 0;
    var $y0 = y0 >>> 0;
    return $x1 - (y1 >>> 0) - ((~$x0 & $y0 | ~($x0 ^ $y0) & $x0 - $y0 >>> 0) >>> 31) | 0;
  }
});


/***/ }),
/* 311 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  imulh: function imulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >> 16;
    var v1 = $v >> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >> 16);
  }
});


/***/ }),
/* 312 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { RAD_PER_DEG: 180 / Math.PI });


/***/ }),
/* 313 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);
var DEG_PER_RAD = Math.PI / 180;

$export($export.S, 'Math', {
  radians: function radians(degrees) {
    return degrees * DEG_PER_RAD;
  }
});


/***/ }),
/* 314 */
/***/ (function(module, exports, __webpack_require__) {

// https://rwaldron.github.io/proposal-math-extensions/
var $export = __webpack_require__(0);

$export($export.S, 'Math', { scale: __webpack_require__(126) });


/***/ }),
/* 315 */
/***/ (function(module, exports, __webpack_require__) {

// https://gist.github.com/BrendanEich/4294d5c212a6d2254703
var $export = __webpack_require__(0);

$export($export.S, 'Math', {
  umulh: function umulh(u, v) {
    var UINT16 = 0xffff;
    var $u = +u;
    var $v = +v;
    var u0 = $u & UINT16;
    var v0 = $v & UINT16;
    var u1 = $u >>> 16;
    var v1 = $v >>> 16;
    var t = (u1 * v0 >>> 0) + (u0 * v0 >>> 16);
    return u1 * v1 + (t >>> 16) + ((u0 * v1 >>> 0) + (t & UINT16) >>> 16);
  }
});


/***/ }),
/* 316 */
/***/ (function(module, exports, __webpack_require__) {

// http://jfbastien.github.io/papers/Math.signbit.html
var $export = __webpack_require__(0);

$export($export.S, 'Math', { signbit: function signbit(x) {
  // eslint-disable-next-line no-self-compare
  return (x = +x) != x ? x : x == 0 ? 1 / x == Infinity : x > 0;
} });


/***/ }),
/* 317 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// https://github.com/tc39/proposal-promise-finally

var $export = __webpack_require__(0);
var core = __webpack_require__(21);
var global = __webpack_require__(2);
var speciesConstructor = __webpack_require__(58);
var promiseResolve = __webpack_require__(113);

$export($export.P + $export.R, 'Promise', { 'finally': function (onFinally) {
  var C = speciesConstructor(this, core.Promise || global.Promise);
  var isFunction = typeof onFinally == 'function';
  return this.then(
    isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () { return x; });
    } : onFinally,
    isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () { throw e; });
    } : onFinally
  );
} });


/***/ }),
/* 318 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/tc39/proposal-promise-try
var $export = __webpack_require__(0);
var newPromiseCapability = __webpack_require__(89);
var perform = __webpack_require__(112);

$export($export.S, 'Promise', { 'try': function (callbackfn) {
  var promiseCapability = newPromiseCapability.f(this);
  var result = perform(callbackfn);
  (result.e ? promiseCapability.reject : promiseCapability.resolve)(result.v);
  return promiseCapability.promise;
} });


/***/ }),
/* 319 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var toMetaKey = metadata.key;
var ordinaryDefineOwnMetadata = metadata.set;

metadata.exp({ defineMetadata: function defineMetadata(metadataKey, metadataValue, target, targetKey) {
  ordinaryDefineOwnMetadata(metadataKey, metadataValue, anObject(target), toMetaKey(targetKey));
} });


/***/ }),
/* 320 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var toMetaKey = metadata.key;
var getOrCreateMetadataMap = metadata.map;
var store = metadata.store;

metadata.exp({ deleteMetadata: function deleteMetadata(metadataKey, target /* , targetKey */) {
  var targetKey = arguments.length < 3 ? undefined : toMetaKey(arguments[2]);
  var metadataMap = getOrCreateMetadataMap(anObject(target), targetKey, false);
  if (metadataMap === undefined || !metadataMap['delete'](metadataKey)) return false;
  if (metadataMap.size) return true;
  var targetMetadata = store.get(target);
  targetMetadata['delete'](targetKey);
  return !!targetMetadata.size || store['delete'](target);
} });


/***/ }),
/* 321 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var getPrototypeOf = __webpack_require__(17);
var ordinaryHasOwnMetadata = metadata.has;
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;

var ordinaryGetMetadata = function (MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return ordinaryGetOwnMetadata(MetadataKey, O, P);
  var parent = getPrototypeOf(O);
  return parent !== null ? ordinaryGetMetadata(MetadataKey, parent, P) : undefined;
};

metadata.exp({ getMetadata: function getMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryGetMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 322 */
/***/ (function(module, exports, __webpack_require__) {

var Set = __webpack_require__(116);
var from = __webpack_require__(125);
var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var getPrototypeOf = __webpack_require__(17);
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;

var ordinaryMetadataKeys = function (O, P) {
  var oKeys = ordinaryOwnMetadataKeys(O, P);
  var parent = getPrototypeOf(O);
  if (parent === null) return oKeys;
  var pKeys = ordinaryMetadataKeys(parent, P);
  return pKeys.length ? oKeys.length ? from(new Set(oKeys.concat(pKeys))) : pKeys : oKeys;
};

metadata.exp({ getMetadataKeys: function getMetadataKeys(target /* , targetKey */) {
  return ordinaryMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
} });


/***/ }),
/* 323 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var ordinaryGetOwnMetadata = metadata.get;
var toMetaKey = metadata.key;

metadata.exp({ getOwnMetadata: function getOwnMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryGetOwnMetadata(metadataKey, anObject(target)
    , arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 324 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var ordinaryOwnMetadataKeys = metadata.keys;
var toMetaKey = metadata.key;

metadata.exp({ getOwnMetadataKeys: function getOwnMetadataKeys(target /* , targetKey */) {
  return ordinaryOwnMetadataKeys(anObject(target), arguments.length < 2 ? undefined : toMetaKey(arguments[1]));
} });


/***/ }),
/* 325 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var getPrototypeOf = __webpack_require__(17);
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;

var ordinaryHasMetadata = function (MetadataKey, O, P) {
  var hasOwn = ordinaryHasOwnMetadata(MetadataKey, O, P);
  if (hasOwn) return true;
  var parent = getPrototypeOf(O);
  return parent !== null ? ordinaryHasMetadata(MetadataKey, parent, P) : false;
};

metadata.exp({ hasMetadata: function hasMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryHasMetadata(metadataKey, anObject(target), arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 326 */
/***/ (function(module, exports, __webpack_require__) {

var metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var ordinaryHasOwnMetadata = metadata.has;
var toMetaKey = metadata.key;

metadata.exp({ hasOwnMetadata: function hasOwnMetadata(metadataKey, target /* , targetKey */) {
  return ordinaryHasOwnMetadata(metadataKey, anObject(target)
    , arguments.length < 3 ? undefined : toMetaKey(arguments[2]));
} });


/***/ }),
/* 327 */
/***/ (function(module, exports, __webpack_require__) {

var $metadata = __webpack_require__(28);
var anObject = __webpack_require__(1);
var aFunction = __webpack_require__(10);
var toMetaKey = $metadata.key;
var ordinaryDefineOwnMetadata = $metadata.set;

$metadata.exp({ metadata: function metadata(metadataKey, metadataValue) {
  return function decorator(target, targetKey) {
    ordinaryDefineOwnMetadata(
      metadataKey, metadataValue,
      (targetKey !== undefined ? anObject : aFunction)(target),
      toMetaKey(targetKey)
    );
  };
} });


/***/ }),
/* 328 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/rwaldron/tc39-notes/blob/master/es6/2014-09/sept-25.md#510-globalasap-for-enqueuing-a-microtask
var $export = __webpack_require__(0);
var microtask = __webpack_require__(88)();
var process = __webpack_require__(2).process;
var isNode = __webpack_require__(19)(process) == 'process';

$export($export.G, {
  asap: function asap(fn) {
    var domain = isNode && process.domain;
    microtask(domain ? domain.bind(fn) : fn);
  }
});


/***/ }),
/* 329 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// https://github.com/zenparsing/es-observable
var $export = __webpack_require__(0);
var global = __webpack_require__(2);
var core = __webpack_require__(21);
var microtask = __webpack_require__(88)();
var OBSERVABLE = __webpack_require__(5)('observable');
var aFunction = __webpack_require__(10);
var anObject = __webpack_require__(1);
var anInstance = __webpack_require__(39);
var redefineAll = __webpack_require__(41);
var hide = __webpack_require__(12);
var forOf = __webpack_require__(40);
var RETURN = forOf.RETURN;

var getMethod = function (fn) {
  return fn == null ? undefined : aFunction(fn);
};

var cleanupSubscription = function (subscription) {
  var cleanup = subscription._c;
  if (cleanup) {
    subscription._c = undefined;
    cleanup();
  }
};

var subscriptionClosed = function (subscription) {
  return subscription._o === undefined;
};

var closeSubscription = function (subscription) {
  if (!subscriptionClosed(subscription)) {
    subscription._o = undefined;
    cleanupSubscription(subscription);
  }
};

var Subscription = function (observer, subscriber) {
  anObject(observer);
  this._c = undefined;
  this._o = observer;
  observer = new SubscriptionObserver(this);
  try {
    var cleanup = subscriber(observer);
    var subscription = cleanup;
    if (cleanup != null) {
      if (typeof cleanup.unsubscribe === 'function') cleanup = function () { subscription.unsubscribe(); };
      else aFunction(cleanup);
      this._c = cleanup;
    }
  } catch (e) {
    observer.error(e);
    return;
  } if (subscriptionClosed(this)) cleanupSubscription(this);
};

Subscription.prototype = redefineAll({}, {
  unsubscribe: function unsubscribe() { closeSubscription(this); }
});

var SubscriptionObserver = function (subscription) {
  this._s = subscription;
};

SubscriptionObserver.prototype = redefineAll({}, {
  next: function next(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      try {
        var m = getMethod(observer.next);
        if (m) return m.call(observer, value);
      } catch (e) {
        try {
          closeSubscription(subscription);
        } finally {
          throw e;
        }
      }
    }
  },
  error: function error(value) {
    var subscription = this._s;
    if (subscriptionClosed(subscription)) throw value;
    var observer = subscription._o;
    subscription._o = undefined;
    try {
      var m = getMethod(observer.error);
      if (!m) throw value;
      value = m.call(observer, value);
    } catch (e) {
      try {
        cleanupSubscription(subscription);
      } finally {
        throw e;
      }
    } cleanupSubscription(subscription);
    return value;
  },
  complete: function complete(value) {
    var subscription = this._s;
    if (!subscriptionClosed(subscription)) {
      var observer = subscription._o;
      subscription._o = undefined;
      try {
        var m = getMethod(observer.complete);
        value = m ? m.call(observer, value) : undefined;
      } catch (e) {
        try {
          cleanupSubscription(subscription);
        } finally {
          throw e;
        }
      } cleanupSubscription(subscription);
      return value;
    }
  }
});

var $Observable = function Observable(subscriber) {
  anInstance(this, $Observable, 'Observable', '_f')._f = aFunction(subscriber);
};

redefineAll($Observable.prototype, {
  subscribe: function subscribe(observer) {
    return new Subscription(observer, this._f);
  },
  forEach: function forEach(fn) {
    var that = this;
    return new (core.Promise || global.Promise)(function (resolve, reject) {
      aFunction(fn);
      var subscription = that.subscribe({
        next: function (value) {
          try {
            return fn(value);
          } catch (e) {
            reject(e);
            subscription.unsubscribe();
          }
        },
        error: reject,
        complete: resolve
      });
    });
  }
});

redefineAll($Observable, {
  from: function from(x) {
    var C = typeof this === 'function' ? this : $Observable;
    var method = getMethod(anObject(x)[OBSERVABLE]);
    if (method) {
      var observable = anObject(method.call(x));
      return observable.constructor === C ? observable : new C(function (observer) {
        return observable.subscribe(observer);
      });
    }
    return new C(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          try {
            if (forOf(x, false, function (it) {
              observer.next(it);
              if (done) return RETURN;
            }) === RETURN) return;
          } catch (e) {
            if (done) throw e;
            observer.error(e);
            return;
          } observer.complete();
        }
      });
      return function () { done = true; };
    });
  },
  of: function of() {
    for (var i = 0, l = arguments.length, items = new Array(l); i < l;) items[i] = arguments[i++];
    return new (typeof this === 'function' ? this : $Observable)(function (observer) {
      var done = false;
      microtask(function () {
        if (!done) {
          for (var j = 0; j < items.length; ++j) {
            observer.next(items[j]);
            if (done) return;
          } observer.complete();
        }
      });
      return function () { done = true; };
    });
  }
});

hide($Observable.prototype, OBSERVABLE, function () { return this; });

$export($export.G, { Observable: $Observable });

__webpack_require__(38)('Observable');


/***/ }),
/* 330 */
/***/ (function(module, exports, __webpack_require__) {

// ie9- setTimeout & setInterval additional parameters fix
var global = __webpack_require__(2);
var $export = __webpack_require__(0);
var userAgent = __webpack_require__(91);
var slice = [].slice;
var MSIE = /MSIE .\./.test(userAgent); // <- dirty ie9- check
var wrap = function (set) {
  return function (fn, time /* , ...args */) {
    var boundArgs = arguments.length > 2;
    var args = boundArgs ? slice.call(arguments, 2) : false;
    return set(boundArgs ? function () {
      // eslint-disable-next-line no-new-func
      (typeof fn == 'function' ? fn : Function(fn)).apply(this, args);
    } : fn, time);
  };
};
$export($export.G + $export.B + $export.F * MSIE, {
  setTimeout: wrap(global.setTimeout),
  setInterval: wrap(global.setInterval)
});


/***/ }),
/* 331 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(0);
var $task = __webpack_require__(87);
$export($export.G + $export.B, {
  setImmediate: $task.set,
  clearImmediate: $task.clear
});


/***/ }),
/* 332 */
/***/ (function(module, exports, __webpack_require__) {

var $iterators = __webpack_require__(86);
var getKeys = __webpack_require__(34);
var redefine = __webpack_require__(13);
var global = __webpack_require__(2);
var hide = __webpack_require__(12);
var Iterators = __webpack_require__(44);
var wks = __webpack_require__(5);
var ITERATOR = wks('iterator');
var TO_STRING_TAG = wks('toStringTag');
var ArrayValues = Iterators.Array;

var DOMIterables = {
  CSSRuleList: true, // TODO: Not spec compliant, should be false.
  CSSStyleDeclaration: false,
  CSSValueList: false,
  ClientRectList: false,
  DOMRectList: false,
  DOMStringList: false,
  DOMTokenList: true,
  DataTransferItemList: false,
  FileList: false,
  HTMLAllCollection: false,
  HTMLCollection: false,
  HTMLFormElement: false,
  HTMLSelectElement: false,
  MediaList: true, // TODO: Not spec compliant, should be false.
  MimeTypeArray: false,
  NamedNodeMap: false,
  NodeList: true,
  PaintRequestList: false,
  Plugin: false,
  PluginArray: false,
  SVGLengthList: false,
  SVGNumberList: false,
  SVGPathSegList: false,
  SVGPointList: false,
  SVGStringList: false,
  SVGTransformList: false,
  SourceBufferList: false,
  StyleSheetList: true, // TODO: Not spec compliant, should be false.
  TextTrackCueList: false,
  TextTrackList: false,
  TouchList: false
};

for (var collections = getKeys(DOMIterables), i = 0; i < collections.length; i++) {
  var NAME = collections[i];
  var explicit = DOMIterables[NAME];
  var Collection = global[NAME];
  var proto = Collection && Collection.prototype;
  var key;
  if (proto) {
    if (!proto[ITERATOR]) hide(proto, ITERATOR, ArrayValues);
    if (!proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
    Iterators[NAME] = ArrayValues;
    if (explicit) for (key in $iterators) if (!proto[key]) redefine(proto, key, $iterators[key], true);
  }
}


/***/ }),
/* 333 */
/***/ (function(module, exports) {

/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

!(function(global) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  var inModule = typeof module === "object";
  var runtime = global.regeneratorRuntime;
  if (runtime) {
    if (inModule) {
      // If regeneratorRuntime is defined globally and we're in a module,
      // make the exports object identical to regeneratorRuntime.
      module.exports = runtime;
    }
    // Don't bother evaluating the rest of this file if the runtime was
    // already defined globally.
    return;
  }

  // Define the runtime globally (as expected by generated code) as either
  // module.exports (if we're in a module) or a new, empty object.
  runtime = global.regeneratorRuntime = inModule ? module.exports : {};

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  runtime.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  runtime.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  runtime.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  runtime.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return Promise.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration. If the Promise is rejected, however, the
          // result for this iteration will be rejected with the same
          // reason. Note that rejections of yielded Promises are not
          // thrown back into the generator function, as is the case
          // when an awaited Promise is rejected. This difference in
          // behavior between yield and await is important, because it
          // allows the consumer to decide what to do with the yielded
          // rejection (swallow it and continue, manually .throw it back
          // into the generator, abandon iteration, whatever). With
          // await, by contrast, there is no opportunity to examine the
          // rejection reason outside the generator function, so the
          // only option is to throw it from the await expression, and
          // let the generator function handle the exception.
          result.value = unwrapped;
          resolve(result);
        }, reject);
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  runtime.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  runtime.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return runtime.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        if (delegate.iterator.return) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  runtime.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  runtime.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };
})(
  // In sloppy mode, unbound `this` refers to the global object, fallback to
  // Function constructor if we're in global strict mode. That is sadly a form
  // of indirect eval which violates Content Security Policy.
  (function() { return this })() || Function("return this")()
);


/***/ }),
/* 334 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(335);
module.exports = __webpack_require__(21).RegExp.escape;


/***/ }),
/* 335 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/benjamingr/RexExp.escape
var $export = __webpack_require__(0);
var $re = __webpack_require__(336)(/[\\^$*+?.()|[\]{}]/g, '\\$&');

$export($export.S, 'RegExp', { escape: function escape(it) { return $re(it); } });


/***/ }),
/* 336 */
/***/ (function(module, exports) {

module.exports = function (regExp, replace) {
  var replacer = replace === Object(replace) ? function (part) {
    return replace[part];
  } : replace;
  return function (it) {
    return String(it).replace(regExp, replacer);
  };
};


/***/ }),
/* 337 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getTouches = undefined;

var _math = __webpack_require__(46);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Touch = function Touch(touch) {
  var supersampling = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

  _classCallCheck(this, Touch);

  this.position = (0, _math.pt)(touch.pageX * supersampling, touch.pageY * supersampling);
};

exports.default = Touch;
var getTouches = exports.getTouches = function getTouches(touchEvent) {
  var supersampling = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

  var arr = [];
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = touchEvent.touches[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var touch = _step.value;

      arr.push(new Touch(touch, supersampling));
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return arr;
};

/***/ }),
/* 338 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var clamp = exports.clamp = function clamp(num, min, max) {
  return Math.min(Math.max(num, min), max);
};

/***/ }),
/* 339 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Circle = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Circle = exports.Circle = function () {
  function Circle() {
    var pos = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : (0, _math.pt)(0, 0);
    var radius = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 5;

    _classCallCheck(this, Circle);

    this.position = pos;
    this.radius = radius;
  }

  _createClass(Circle, [{
    key: 'intersectsCircle',
    value: function intersectsCircle(circle) {
      var dist = (0, _math.distance)(this.position, circle.position);
      if (dist < this.radius + circle.radius) {
        return true;
      }
      return false;
    }
  }, {
    key: 'intersectsPt',
    value: function intersectsPt(pt) {
      var dist = (0, _math.distance)(this.position, pt);
      if (dist < this.radius) {
        return true;
      }
      return false;
    }
  }, {
    key: 'intersectsPoly',
    value: function intersectsPoly(poly) {
      if (poly.intersectsPt(this.position)) {
        return true;
      }
      for (var i = 0, j = 1; i < poly.verticies.length; i++, j = (j + 1) % poly.verticies.length) {
        var p0 = poly.verticies[i];
        var p1 = poly.verticies[j];
        if (this.pDistance(this.position.x, this.position.y, p0.x, p0.y, p1.x, p1.y) < this.radius) {
          return true;
        }
      }
      return false;
    }
  }, {
    key: 'getEdgeFromPoly',
    value: function getEdgeFromPoly(poly) {
      for (var i = 0, j = 1; i < poly.verticies.length; i++, j = (j + 1) % poly.verticies.length) {
        var p0 = poly.verticies[i];
        var p1 = poly.verticies[j];
        if (this.pDistance(this.position.x, this.position.y, p0.x, p0.y, p1.x, p1.y) < this.radius) {
          return [p0, p1];
        }
      }
      return null;
    }
  }, {
    key: 'pDistance',
    value: function pDistance(x, y, x1, y1, x2, y2) {
      var A = x - x1;
      var B = y - y1;
      var C = x2 - x1;
      var D = y2 - y1;

      var dot = A * C + B * D;
      var lenSq = C * C + D * D;
      var param = -1;
      if (lenSq !== 0) {
        param = dot / lenSq;
      }
      var xx, yy;

      if (param < 0) {
        xx = x1;
        yy = y1;
      } else if (param > 1) {
        xx = x2;
        yy = y2;
      } else {
        xx = x1 + param * C;
        yy = y1 + param * D;
      }

      var dx = x - xx;
      var dy = y - yy;
      return Math.sqrt(dx * dx + dy * dy);
    }
  }, {
    key: 'translate',
    value: function translate(x, y) {
      this.position = (0, _math.sum)(this.position, (0, _math.pt)(x, y));
    }
  }]);

  return Circle;
}();

/***/ }),
/* 340 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var noop = function noop(_) {};

var Scene = function Scene() {
  var keyEvents = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var onEnter = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : noop;
  var onClick = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : noop;
  var render = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : noop;
  var update = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : noop;
  var keyUp = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : noop;

  _classCallCheck(this, Scene);

  this.state = {};

  this.keyEvents = keyEvents;
  this.onEnter = onEnter;
  this.onClick = onClick;
  this.render = render;
  this.update = update;
  this.keyUp = keyUp;
  this.goto = noop;
};

var SceneManager = function () {
  function SceneManager(engine, scenes) {
    _classCallCheck(this, SceneManager);

    this.engine = null;
    this.currentScene = null;
    this.scenes = {};

    this.engine = engine;
    this.scenes = scenes;
  }

  _createClass(SceneManager, [{
    key: 'mount',
    value: function mount(scene) {
      var silent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

      scene.goto = this.goto.bind(this);
      var oldScene = this.currentScene;
      if (this.currentScene) {
        this.currentScene.goto = noop;
      }
      this.currentScene = scene;
      this.engine.keyEvents = scene.keyEvents;
      this.engine.onClick = scene.onClick.bind(this);
      this.engine.draw = scene.render.bind(this);
      this.engine.update = scene.update.bind(this);
      this.engine.keyUp = scene.keyUp.bind(this);
      if (!silent) {
        scene.onEnter(this.engine, oldScene, this);
      }
    }
  }, {
    key: 'goto',
    value: function goto(sceneName) {
      var silent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

      var scene = this.scenes[sceneName];
      if (scene) {
        this.mount(scene, silent);
      } else {
        throw Error('Scene not found!');
      }
    }
  }]);

  return SceneManager;
}();

exports.Scene = Scene;
exports.SceneManager = SceneManager;

/***/ }),
/* 341 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ImageButton = exports.Draggable = exports.Container = exports.KeyBoardButtonManager = exports.Button = exports.UIElement = undefined;

var _uielement = __webpack_require__(343);

var _uielement2 = _interopRequireDefault(_uielement);

var _keyboardbuttonmanager = __webpack_require__(348);

var _keyboardbuttonmanager2 = _interopRequireDefault(_keyboardbuttonmanager);

var _container = __webpack_require__(344);

var _container2 = _interopRequireDefault(_container);

var _draggable = __webpack_require__(349);

var _draggable2 = _interopRequireDefault(_draggable);

var _button = __webpack_require__(345);

var _button2 = _interopRequireDefault(_button);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.UIElement = _uielement2.default;
exports.Button = _button2.default;
exports.KeyBoardButtonManager = _keyboardbuttonmanager2.default;
exports.Container = _container2.default;
exports.Draggable = _draggable2.default;
exports.ImageButton = _button.ImageButton;

/***/ }),
/* 342 */,
/* 343 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var noop = function noop(_) {};

var UIElement = function () {
  function UIElement(_ref) {
    var _ref$update = _ref.update,
        update = _ref$update === undefined ? noop : _ref$update,
        _ref$render = _ref.render,
        render = _ref$render === undefined ? noop : _ref$render,
        _ref$position = _ref.position,
        position = _ref$position === undefined ? (0, _math.pt)(0, 0) : _ref$position,
        _ref$children = _ref.children,
        children = _ref$children === undefined ? [] : _ref$children;

    _classCallCheck(this, UIElement);

    this.position = position;
    this.render = render.bind(this);
    this.update = update.bind(this);
    this.children = children;
    this.parent = null;
  }

  _createClass(UIElement, [{
    key: 'addChildren',
    value: function addChildren() {
      var _children;

      for (var _len = arguments.length, children = Array(_len), _key = 0; _key < _len; _key++) {
        children[_key] = arguments[_key];
      }

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var child = _step.value;

          child.parent = this;
          child._onChildAdd();
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      (_children = this.children).push.apply(_children, children);
    }
  }, {
    key: 'renderChildren',
    value: function renderChildren(c, e) {
      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = this.children[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var child = _step2.value;

          child.render(c, e);
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }
    }
  }, {
    key: 'handleUpdate',
    value: function handleUpdate(e, scene) {
      this.update(e, scene);
      var _iteratorNormalCompletion3 = true;
      var _didIteratorError3 = false;
      var _iteratorError3 = undefined;

      try {
        for (var _iterator3 = this.children[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
          var child = _step3.value;

          child.update(e, scene, child);
        }
      } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion3 && _iterator3.return) {
            _iterator3.return();
          }
        } finally {
          if (_didIteratorError3) {
            throw _iteratorError3;
          }
        }
      }
    }
  }, {
    key: '_onChildAdd',
    value: function _onChildAdd() {}
  }, {
    key: 'globalPosition',
    get: function get() {
      if (this.parent) {
        return (0, _math.sum)(this.parent.globalPosition, this.position);
      } else {
        return this.position;
      }
    }
  }]);

  return UIElement;
}();

exports.default = UIElement;

/***/ }),
/* 344 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _math = __webpack_require__(46);

var _uielement = __webpack_require__(343);

var _uielement2 = _interopRequireDefault(_uielement);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Container = function (_UIElement) {
  _inherits(Container, _UIElement);

  function Container(_ref) {
    var _ref$dimensions = _ref.dimensions,
        dimensions = _ref$dimensions === undefined ? (0, _math.rectToPolygon)(0, 0, 100, 100) : _ref$dimensions,
        _ref$render = _ref.render,
        render = _ref$render === undefined ? function (c, e) {
      return _this.renderChildren(c, e);
    } : _ref$render,
        rest = _objectWithoutProperties(_ref, ['dimensions', 'render']);

    _classCallCheck(this, Container);

    var _this = _possibleConstructorReturn(this, (Container.__proto__ || Object.getPrototypeOf(Container)).call(this, _extends({ render: render }, rest)));

    _this.dimensions = dimensions;
    return _this;
  }

  return Container;
}(_uielement2.default);

exports.default = Container;

/***/ }),
/* 345 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ImageButton = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _container = __webpack_require__(344);

var _container2 = _interopRequireDefault(_container);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var noop = function noop(_) {};

var defaultHoverButtonRender = function defaultHoverButtonRender(c) {
  c.fillStyle = this.fillColor;
  var rect = this.dimensions.AABB();
  c.fillRect(this.globalPosition.x, this.globalPosition.y, rect.width, rect.height);
  c.fillStyle = this.textColor;
  c.font = this.fontSize + 'px ' + this.font;
  var width = c.measureText(this.text);
  var x = 0;
  var y = 0;
  if (this.textAlign === 'center') {
    x = this.globalPosition.x + rect.width / 2 - Math.min(width.width / 2, rect.width / 2);
  } else {
    x = this.globalPosition.x;
  }
  if (this.verticalAlign === 'center') {
    y = this.globalPosition.y + rect.height * 1 / 2 + this.fontSize / 4;
  } else {
    y = this.globalPosition.y + this.fontSize;
  }
  c.fillText(this.text, x, y, rect.width);
  this.renderChildren(c);
};

var defaultButtonRender = function defaultButtonRender(c) {
  var rect = this.dimensions.AABB();
  c.fillStyle = this.strokeColor;
  c.fillRect(this.globalPosition.x, this.globalPosition.y, rect.width, rect.height);
  c.fillStyle = this.fillColor;
  c.fillRect(this.globalPosition.x, this.globalPosition.y, rect.width, rect.height * 0.75);
  c.fillStyle = this.textColor;
  c.font = this.fontSize + 'px ' + this.font;
  var width = c.measureText(this.text);
  var x = 0;
  var y = 0;
  if (this.textAlign === 'center') {
    x = this.globalPosition.x + rect.width / 2 - Math.min(width.width / 2, rect.width / 2);
  } else {
    x = this.globalPosition.x;
  }
  if (this.verticalAlign === 'center') {
    y = this.globalPosition.y + rect.height * 1 / 2 + this.fontSize / 4;
  } else {
    y = this.globalPosition.y + this.fontSize;
  }
  c.fillText(this.text, x, y, rect.width);
  this.renderChildren(c);
};

var imageButtonRender = function imageButtonRender(c, e, img) {
  var rect = this.dimensions.AABB();
  c.fillStyle = this.strokeColor;
  if (this.state === 1) {
    c.drawImage(e.state.imageLoader.images[img.imageHover], this.globalPosition.x - 50, this.globalPosition.y, rect.width + 50, rect.height);
  } else if (this.state === 2) {
    c.drawImage(e.state.imageLoader.images[img.imageDown], this.globalPosition.x - 50, this.globalPosition.y, rect.width + 50, rect.height);
  } else {
    c.drawImage(e.state.imageLoader.images[img.image], this.globalPosition.x, this.globalPosition.y, rect.width, rect.height);
  }
  c.fillStyle = this.fillColor;
  // c.fillRect(this.globalPosition.x, this.globalPosition.y, rect.width, rect.height * 0.75)
  c.fillStyle = this.textColor;
  c.font = this.fontSize + 'px ' + this.font;
  var width = c.measureText(this.text);
  var x = 0;
  var y = 0;
  if (this.textAlign === 'center') {
    x = this.globalPosition.x + rect.width / 2 - Math.min(width.width / 2, rect.width / 2);
  } else {
    x = this.globalPosition.x;
  }
  if (this.verticalAlign === 'center') {
    y = this.globalPosition.y + rect.height * 1 / 2 + this.fontSize / 4;
  } else {
    y = this.globalPosition.y + this.fontSize;
  }
  c.fillText(this.text, x, y, rect.width);
  this.renderChildren(c);
};

var Button = function (_Container) {
  _inherits(Button, _Container);

  function Button(_ref) {
    var _ref$text = _ref.text,
        text = _ref$text === undefined ? '' : _ref$text,
        _ref$font = _ref.font,
        font = _ref$font === undefined ? 'MTV2C, sans-serif' : _ref$font,
        _ref$fontSize = _ref.fontSize,
        fontSize = _ref$fontSize === undefined ? 14 : _ref$fontSize,
        _ref$textColor = _ref.textColor,
        textColor = _ref$textColor === undefined ? '#fff' : _ref$textColor,
        _ref$fillColor = _ref.fillColor,
        fillColor = _ref$fillColor === undefined ? '#2E9AFE' : _ref$fillColor,
        _ref$strokeColor = _ref.strokeColor,
        strokeColor = _ref$strokeColor === undefined ? '#084B8A' : _ref$strokeColor,
        _ref$textAlign = _ref.textAlign,
        textAlign = _ref$textAlign === undefined ? 'center' : _ref$textAlign,
        _ref$verticalAlign = _ref.verticalAlign,
        verticalAlign = _ref$verticalAlign === undefined ? 'center' : _ref$verticalAlign,
        _ref$update = _ref.update,
        update = _ref$update === undefined ? noop : _ref$update,
        _ref$onClick = _ref.onClick,
        onClick = _ref$onClick === undefined ? function (_) {
      return console.log('click');
    } : _ref$onClick,
        _ref$render = _ref.render,
        render = _ref$render === undefined ? function (c, _e) {
      if (_this.state === 1) {
        _this.renderHover(c);
      } else if (_this.state === 2) {
        _this.renderDown(c);
      } else {
        _this.renderDefault(c);
      }
    } : _ref$render,
        _ref$renderDefault = _ref.renderDefault,
        renderDefault = _ref$renderDefault === undefined ? defaultButtonRender : _ref$renderDefault,
        _ref$renderHover = _ref.renderHover,
        renderHover = _ref$renderHover === undefined ? defaultHoverButtonRender : _ref$renderHover,
        _ref$renderDown = _ref.renderDown,
        renderDown = _ref$renderDown === undefined ? defaultButtonRender : _ref$renderDown,
        rest = _objectWithoutProperties(_ref, ['text', 'font', 'fontSize', 'textColor', 'fillColor', 'strokeColor', 'textAlign', 'verticalAlign', 'update', 'onClick', 'render', 'renderDefault', 'renderHover', 'renderDown']);

    _classCallCheck(this, Button);

    var _this = _possibleConstructorReturn(this, (Button.__proto__ || Object.getPrototypeOf(Button)).call(this, _extends({ render: render, update: update }, rest)));

    var oldUpdate = _this.update;
    var u = function u(e, scene) {
      _this.dimensions.translate(_this.globalPosition.x, _this.globalPosition.y);
      var intersects = _this.dimensions.intersectsPt(e.mouse);
      _this.dimensions.translate(-_this.globalPosition.x, -_this.globalPosition.y);
      var down = e.mouse.down;
      if (intersects && down) {
        _this.state = 2;
      } else if (intersects && !down) {
        _this.state = 1;
      } else {
        _this.state = 0;
      }
      oldUpdate(e, scene, _this);
    };
    _this.text = text;
    _this.font = font;
    _this.fontSize = fontSize;
    _this.textColor = textColor;
    _this.fillColor = fillColor;
    _this.strokeColor = strokeColor;
    _this.textAlign = textAlign;
    _this.verticalAlign = verticalAlign;
    _this.renderDefault = renderDefault;
    _this.renderHover = renderHover;
    _this.renderDown = renderDown;
    _this.update = u;
    _this.onClick = onClick;
    _this.state = 0;
    return _this;
  }

  _createClass(Button, [{
    key: 'handleClick',
    value: function handleClick(e) {
      if (this.state === 2) {
        this.onClick(e);
      }
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var child = _step.value;

          if (child.handleClick) {
            child.handleClick(e);
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    }
  }, {
    key: '_addClickHandler',
    value: function _addClickHandler() {
      if (this.parent && !this.parent.handleClick) {
        this.parent.handleClick = this.handleClick;
        this.parent.handleClick();
      }
    }
  }, {
    key: '_onChildAdd',
    value: function _onChildAdd() {
      this._addClickHandler();
    }
  }]);

  return Button;
}(_container2.default);

Button.states = ['default', 'hover', 'down'];
exports.default = Button;

var ImageButton = exports.ImageButton = function (_Button) {
  _inherits(ImageButton, _Button);

  function ImageButton(_ref2) {
    var _ref2$image = _ref2.image,
        image = _ref2$image === undefined ? 'buttonStatic' : _ref2$image,
        _ref2$imageHover = _ref2.imageHover,
        imageHover = _ref2$imageHover === undefined ? 'buttonHover' : _ref2$imageHover,
        _ref2$imageDown = _ref2.imageDown,
        imageDown = _ref2$imageDown === undefined ? 'buttonClicked' : _ref2$imageDown,
        rest = _objectWithoutProperties(_ref2, ['image', 'imageHover', 'imageDown']);

    _classCallCheck(this, ImageButton);

    var _this2 = _possibleConstructorReturn(this, (ImageButton.__proto__ || Object.getPrototypeOf(ImageButton)).call(this, _extends({}, rest)));

    _this2.renderDown = imageButtonRender;
    _this2.renderHover = imageButtonRender;
    _this2.renderDefault = imageButtonRender;
    _this2.image = image;
    _this2.imageHover = imageHover;
    _this2.imageDown = imageDown;
    var r = function r(c, e) {
      if (_this2.state === 1) {
        _this2.renderHover(c, e, _this2);
      } else if (_this2.state === 2) {
        _this2.renderDown(c, e, _this2);
      } else {
        _this2.renderDefault(c, e, _this2);
      }
    };
    _this2.render = r;
    return _this2;
  }

  return ImageButton;
}(Button);

/***/ }),
/* 346 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keyM$addEdge, _keyM$addEdge2, _keyM$addEdge3, _keyM$addEdge4, _keyM$addEdge5;

var _scene = __webpack_require__(340);

var _math = __webpack_require__(46);

var _UI = __webpack_require__(341);

var _keys = __webpack_require__(130);

var keys = _interopRequireWildcard(_keys);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var settings = new _scene.Scene();
settings.state.controls = {
  UP: [keys.KEY_UP, keys.W],
  DOWN: [keys.KEY_DOWN, keys.S],
  LEFT: [keys.KEY_LEFT, keys.A],
  RIGHT: [keys.KEY_RIGHT, keys.D],
  SPRINT: [keys.SHIFT]
};

settings.state.FOV = 250;
settings.state.stretchTexture = false;
settings.state.music = 100;
settings.state.sound = 100;

var centerButton = function centerButton(margins) {
  var _offset = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;

  return function (e, btn) {
    btn.position.x = e.width * margins;
    btn.dimensions = (0, _math.rectToPolygon)(0, 0, e.width * (1 - margins * 2), btn.dimensions.verticies[2].y);
  };
};

var settingsContainer = new _UI.Container({
  dimensions: (0, _math.rectToPolygon)(0, 0, 900, 500),
  position: (0, _math.pt)(0, 0)
});

var i = 1;
var height = 125;
var width = 500;
var fontSize = 35;
var offset = -100;

var musicButton = new _UI.ImageButton({
  position: (0, _math.pt)(40, i++ * (height + 25) + offset),
  text: 'Music',
  update: function update(e, scene, btn) {
    centerButton(0.25)(e, btn);
    btn.text = 'Music Volume: ' + settings.state.music;
  },
  fontSize: fontSize,
  onClick: function onClick(_) {
    settings.state.music = (settings.state.music + 10) % 110;
  },
  dimensions: (0, _math.rectToPolygon)(0, 0, width, height)
});

var soundButton = new _UI.ImageButton({
  position: (0, _math.pt)(40, i++ * (height + 25) + offset),
  text: 'Sounds',
  onClick: function onClick(_) {
    settings.state.sound = (settings.state.sound + 10) % 110;
  },
  update: function update(e, scene, btn) {
    centerButton(0.25)(e, btn);
    btn.text = 'Sound Volume: ' + settings.state.sound;
  },
  fontSize: fontSize,
  dimensions: (0, _math.rectToPolygon)(0, 0, width, height)
});

var textureStretch = new _UI.ImageButton({
  position: (0, _math.pt)(40, i++ * (height + 25) + offset),
  text: 'Texture Stretch',
  onClick: function onClick(_) {
    settings.state.stretchTexture = !settings.state.stretchTexture;
  },
  update: function update(e, scene, btn) {
    centerButton(0.25)(e, btn);
    btn.text = 'Texture Stretch: ' + (settings.state.stretchTexture ? 'On' : 'Off');
  },
  fontSize: fontSize,
  dimensions: (0, _math.rectToPolygon)(0, 0, width, height)
});

var backButton = new _UI.ImageButton({
  position: (0, _math.pt)(40, i++ * (height + 25) + offset),
  text: 'Back',
  update: function update(e, scene, btn) {
    centerButton(0.25)(e, btn);
  },
  onClick: function onClick(_) {
    return settings.goto('start');
  },
  fontSize: fontSize,
  dimensions: (0, _math.rectToPolygon)(0, 0, width, height)
});

var keyM = new _UI.KeyBoardButtonManager({});

keyM.addEdge(musicButton, (_keyM$addEdge = {}, _defineProperty(_keyM$addEdge, keys.KEY_UP, backButton), _defineProperty(_keyM$addEdge, keys.KEY_DOWN, soundButton), _defineProperty(_keyM$addEdge, keys.ENTER, function (btn) {
  return btn.onClick();
}), _keyM$addEdge));

keyM.addEdge(soundButton, (_keyM$addEdge2 = {}, _defineProperty(_keyM$addEdge2, keys.KEY_UP, musicButton), _defineProperty(_keyM$addEdge2, keys.KEY_DOWN, textureStretch), _defineProperty(_keyM$addEdge2, keys.ENTER, function (btn) {
  return btn.onClick();
}), _keyM$addEdge2));

keyM.addEdge(textureStretch, (_keyM$addEdge3 = {}, _defineProperty(_keyM$addEdge3, keys.KEY_UP, soundButton), _defineProperty(_keyM$addEdge3, keys.KEY_DOWN, backButton), _defineProperty(_keyM$addEdge3, keys.ENTER, function (btn) {
  return btn.onClick();
}), _keyM$addEdge3));

keyM.addEdge(textureStretch, (_keyM$addEdge4 = {}, _defineProperty(_keyM$addEdge4, keys.KEY_UP, soundButton), _defineProperty(_keyM$addEdge4, keys.KEY_DOWN, backButton), _defineProperty(_keyM$addEdge4, keys.ENTER, function (btn) {
  return btn.onClick();
}), _keyM$addEdge4));

keyM.addEdge(backButton, (_keyM$addEdge5 = {}, _defineProperty(_keyM$addEdge5, keys.KEY_UP, textureStretch), _defineProperty(_keyM$addEdge5, keys.KEY_DOWN, musicButton), _defineProperty(_keyM$addEdge5, keys.ENTER, function (btn) {
  return btn.onClick();
}), _keyM$addEdge5));

settingsContainer.addChildren(musicButton, soundButton, textureStretch, backButton);

var render = function render(e, c) {
  c.clearRect(0, 0, e.width, e.height);

  var bgimg = e.state.imageLoader.images.floor2;
  var tileSize = 512;
  var x = Math.ceil(e.width / tileSize) + 1;
  var y = Math.ceil(e.height / tileSize) + 1;
  for (var _i = 0; _i < x; _i++) {
    for (var j = 0; j < y; j++) {
      c.drawImage(bgimg, _i * tileSize, j * tileSize, tileSize, tileSize);
    }
  }

  settingsContainer.render(c, e);

  c.fillStyle = '#f00';
  c.fillRect(e.mouse.x - 1, e.mouse.y - 1, 3, 3);
};

var update = function update(e) {
  settingsContainer.handleUpdate(e, settings);
  keyM.handleUpdate(e);
};

var keyUp = function keyUp(e, key, evt) {
  keyM.handleKey(e, key, evt);
  if (!keyM.selected) {
    keyM.select(keyM.children[0]);
  }
};

settings.render = render;
settings.update = update;
settings.onClick = function (e) {
  return settingsContainer.handleClick(e);
};
settings.keyUp = keyUp;
exports.default = settings;

/***/ }),
/* 347 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var defaultHash = function defaultHash() {
  for (var _len = arguments.length, a = Array(_len), _key = 0; _key < _len; _key++) {
    a[_key] = arguments[_key];
  }

  return a.reduce(function (acc, cur) {
    return cur.toString() + '_' + acc;
  }, '');
};

var memoize = exports.memoize = function memoize(fn) {
  var hash = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultHash;

  var cache = {};
  var memoized = function memoized() {
    var hsh = hash.apply(undefined, arguments);
    var cacheVal = cache[hsh];
    if (cacheVal) {
      return cacheVal;
    } else {
      cache[hsh] = fn.apply(undefined, arguments);
      return cache[hsh];
    }
  };
  memoized._memoizeCache = cache;
  return memoized;
};

var vibrate = exports.vibrate = function vibrate(ms) {
  if (window && window.navigator && window.navigator.vibrate) {
    window.navigator.vibrate(ms);
  }
};

/***/ }),
/* 348 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var KeyBoardButtonManager = function () {
  function KeyBoardButtonManager(_ref) {
    var _ref$children = _ref.children,
        children = _ref$children === undefined ? [] : _ref$children;

    _classCallCheck(this, KeyBoardButtonManager);

    this.selected = null;
    this.children = children;
  }

  _createClass(KeyBoardButtonManager, [{
    key: 'addEdge',
    value: function addEdge(btn, _ref2) {
      var rest = _objectWithoutProperties(_ref2, []);

      btn.buttons = rest;
      this.children.push(btn);
    }
  }, {
    key: 'select',
    value: function select(btn) {
      this.selected = btn;
    }
  }, {
    key: 'callDirection',
    value: function callDirection(direction) {
      if (this.selected) {
        if (this.selected.buttons) {
          if (_typeof(this.selected.buttons[direction]) === 'object') {
            this.select(this.selected.buttons[direction]);
          } else if (typeof this.selected.buttons[direction] === 'function') {
            this.selected.buttons[direction](this.selected, this);
          }
        } else {
          throw new Error('Selected is either not a button or has no method for direction');
        }
      }
    }
  }, {
    key: 'handleUpdate',
    value: function handleUpdate(_e) {
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var btn = _step.value;

          if (btn.state === 1) {
            this.select(btn);
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = this.children[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var _btn = _step2.value;

          if (this.selected === _btn && _btn.state < 2) {
            _btn.state = 1;
          }
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }
    }
  }, {
    key: 'handleKey',
    value: function handleKey(e, key, _evt) {
      this.callDirection(key);
    }
  }]);

  return KeyBoardButtonManager;
}();

exports.default = KeyBoardButtonManager;

/***/ }),
/* 349 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _math = __webpack_require__(46);

var _button = __webpack_require__(345);

var _button2 = _interopRequireDefault(_button);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Draggable = function (_Button) {
  _inherits(Draggable, _Button);

  function Draggable(_ref) {
    var rest = _objectWithoutProperties(_ref, []);

    _classCallCheck(this, Draggable);

    var _this = _possibleConstructorReturn(this, (Draggable.__proto__ || Object.getPrototypeOf(Draggable)).call(this, _extends({}, rest)));

    _this.dragging = null;
    _this.originalPosition = null;
    _this.lastState = 0;
    var oldUpdate = _this.update;
    var u = function u(e, scene) {
      if (_this.state === 2 && _this.lastState === 1 && !_this.dragging) {
        _this.dragging = (0, _math.pt)(e.mouse.x, e.mouse.y);
        _this.originalPosition = (0, _math.pt)(_this.position.x, _this.position.y);
      }
      if (_this.dragging && e.mouse.down) {
        var difference = (0, _math.sub)(e.mouse, _this.dragging);
        _this.position = (0, _math.sum)(_this.originalPosition, difference);
      } else if (!e.mouse.down && _this.dragging) {
        _this.dragging = null;
        _this.originalPosition = null;
      }
      _this.lastState = _this.state;
      oldUpdate(e, scene);
    };
    _this.update = u;
    return _this;
  }

  return Draggable;
}(_button2.default);

exports.default = Draggable;

/***/ }),
/* 350 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AudioLoader = exports.ImageLoader = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _howler = __webpack_require__(351);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ImageLoader = exports.ImageLoader = function () {
  function ImageLoader(manifest) {
    var _this = this;

    _classCallCheck(this, ImageLoader);

    this.manifest = manifest;
    this.images = {};

    var _loop = function _loop(name) {
      var img = new Image();
      img.src = manifest[name];
      img.loaded = false;
      _this.images[name] = img;
      img.addEventListener('load', function (_) {
        img.loaded = true;
      }, false);
    };

    for (var name in manifest) {
      _loop(name);
    }
  }

  _createClass(ImageLoader, [{
    key: 'loaded',
    get: function get() {
      var i = 0;
      for (var name in this.images) {
        var _img = this.images[name];
        if (_img.loaded) {
          i++;
        }
      }
      return i;
    }
  }, {
    key: 'total',
    get: function get() {
      var i = 0;
      for (var _name in this.images) {
        i++;
      }
      return i;
    }
  }]);

  return ImageLoader;
}();

var AudioLoader = exports.AudioLoader = function () {
  function AudioLoader(manifest) {
    var _this2 = this;

    _classCallCheck(this, AudioLoader);

    this.manifest = manifest;
    this.assets = {};

    var _loop2 = function _loop2(name) {
      var src = null;
      if (typeof manifest[name] === 'string') {
        src = [manifest[name]];
      } else {
        src = manifest[name];
      }
      var asset = new _howler.Howl({
        src: src,
        volume: 0.5
      });
      asset.loaded = false;
      _this2.assets[name] = asset;
      asset.once('load', function (_) {
        asset.loaded = true;
      }, false);
    };

    for (var name in manifest) {
      _loop2(name);
    }
  }

  _createClass(AudioLoader, [{
    key: 'loaded',
    get: function get() {
      var i = 0;
      for (var name in this.assets) {
        var _asset = this.assets[name];
        if (_asset.loaded) {
          i++;
        }
      }
      return i;
    }
  }, {
    key: 'total',
    get: function get() {
      var i = 0;
      for (var _name in this.assets) {
        i++;
      }
      return i;
    }
  }]);

  return AudioLoader;
}();

/***/ }),
/* 351 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
 *  howler.js v2.0.7
 *  howlerjs.com
 *
 *  (c) 2013-2017, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */

(function() {

  'use strict';

  /** Global Methods **/
  /***************************************************************************/

  /**
   * Create the global controller. All contained methods and properties apply
   * to all sounds that are currently playing or will be in the future.
   */
  var HowlerGlobal = function() {
    this.init();
  };
  HowlerGlobal.prototype = {
    /**
     * Initialize the global Howler object.
     * @return {Howler}
     */
    init: function() {
      var self = this || Howler;

      // Create a global ID counter.
      self._counter = 1000;

      // Internal properties.
      self._codecs = {};
      self._howls = [];
      self._muted = false;
      self._volume = 1;
      self._canPlayEvent = 'canplaythrough';
      self._navigator = (typeof window !== 'undefined' && window.navigator) ? window.navigator : null;

      // Public properties.
      self.masterGain = null;
      self.noAudio = false;
      self.usingWebAudio = true;
      self.autoSuspend = true;
      self.ctx = null;

      // Set to false to disable the auto iOS enabler.
      self.mobileAutoEnable = true;

      // Setup the various state values for global tracking.
      self._setup();

      return self;
    },

    /**
     * Get/set the global volume for all sounds.
     * @param  {Float} vol Volume from 0.0 to 1.0.
     * @return {Howler/Float}     Returns self or current volume.
     */
    volume: function(vol) {
      var self = this || Howler;
      vol = parseFloat(vol);

      // If we don't have an AudioContext created yet, run the setup.
      if (!self.ctx) {
        setupAudioContext();
      }

      if (typeof vol !== 'undefined' && vol >= 0 && vol <= 1) {
        self._volume = vol;

        // Don't update any of the nodes if we are muted.
        if (self._muted) {
          return self;
        }

        // When using Web Audio, we just need to adjust the master gain.
        if (self.usingWebAudio) {
          self.masterGain.gain.setValueAtTime(vol, Howler.ctx.currentTime);
        }

        // Loop through and change volume for all HTML5 audio nodes.
        for (var i=0; i<self._howls.length; i++) {
          if (!self._howls[i]._webAudio) {
            // Get all of the sounds in this Howl group.
            var ids = self._howls[i]._getSoundIds();

            // Loop through all sounds and change the volumes.
            for (var j=0; j<ids.length; j++) {
              var sound = self._howls[i]._soundById(ids[j]);

              if (sound && sound._node) {
                sound._node.volume = sound._volume * vol;
              }
            }
          }
        }

        return self;
      }

      return self._volume;
    },

    /**
     * Handle muting and unmuting globally.
     * @param  {Boolean} muted Is muted or not.
     */
    mute: function(muted) {
      var self = this || Howler;

      // If we don't have an AudioContext created yet, run the setup.
      if (!self.ctx) {
        setupAudioContext();
      }

      self._muted = muted;

      // With Web Audio, we just need to mute the master gain.
      if (self.usingWebAudio) {
        self.masterGain.gain.setValueAtTime(muted ? 0 : self._volume, Howler.ctx.currentTime);
      }

      // Loop through and mute all HTML5 Audio nodes.
      for (var i=0; i<self._howls.length; i++) {
        if (!self._howls[i]._webAudio) {
          // Get all of the sounds in this Howl group.
          var ids = self._howls[i]._getSoundIds();

          // Loop through all sounds and mark the audio node as muted.
          for (var j=0; j<ids.length; j++) {
            var sound = self._howls[i]._soundById(ids[j]);

            if (sound && sound._node) {
              sound._node.muted = (muted) ? true : sound._muted;
            }
          }
        }
      }

      return self;
    },

    /**
     * Unload and destroy all currently loaded Howl objects.
     * @return {Howler}
     */
    unload: function() {
      var self = this || Howler;

      for (var i=self._howls.length-1; i>=0; i--) {
        self._howls[i].unload();
      }

      // Create a new AudioContext to make sure it is fully reset.
      if (self.usingWebAudio && self.ctx && typeof self.ctx.close !== 'undefined') {
        self.ctx.close();
        self.ctx = null;
        setupAudioContext();
      }

      return self;
    },

    /**
     * Check for codec support of specific extension.
     * @param  {String} ext Audio file extention.
     * @return {Boolean}
     */
    codecs: function(ext) {
      return (this || Howler)._codecs[ext.replace(/^x-/, '')];
    },

    /**
     * Setup various state values for global tracking.
     * @return {Howler}
     */
    _setup: function() {
      var self = this || Howler;

      // Keeps track of the suspend/resume state of the AudioContext.
      self.state = self.ctx ? self.ctx.state || 'running' : 'running';

      // Automatically begin the 30-second suspend process
      self._autoSuspend();

      // Check if audio is available.
      if (!self.usingWebAudio) {
        // No audio is available on this system if noAudio is set to true.
        if (typeof Audio !== 'undefined') {
          try {
            var test = new Audio();

            // Check if the canplaythrough event is available.
            if (typeof test.oncanplaythrough === 'undefined') {
              self._canPlayEvent = 'canplay';
            }
          } catch(e) {
            self.noAudio = true;
          }
        } else {
          self.noAudio = true;
        }
      }

      // Test to make sure audio isn't disabled in Internet Explorer.
      try {
        var test = new Audio();
        if (test.muted) {
          self.noAudio = true;
        }
      } catch (e) {}

      // Check for supported codecs.
      if (!self.noAudio) {
        self._setupCodecs();
      }

      return self;
    },

    /**
     * Check for browser support for various codecs and cache the results.
     * @return {Howler}
     */
    _setupCodecs: function() {
      var self = this || Howler;
      var audioTest = null;

      // Must wrap in a try/catch because IE11 in server mode throws an error.
      try {
        audioTest = (typeof Audio !== 'undefined') ? new Audio() : null;
      } catch (err) {
        return self;
      }

      if (!audioTest || typeof audioTest.canPlayType !== 'function') {
        return self;
      }

      var mpegTest = audioTest.canPlayType('audio/mpeg;').replace(/^no$/, '');

      // Opera version <33 has mixed MP3 support, so we need to check for and block it.
      var checkOpera = self._navigator && self._navigator.userAgent.match(/OPR\/([0-6].)/g);
      var isOldOpera = (checkOpera && parseInt(checkOpera[0].split('/')[1], 10) < 33);

      self._codecs = {
        mp3: !!(!isOldOpera && (mpegTest || audioTest.canPlayType('audio/mp3;').replace(/^no$/, ''))),
        mpeg: !!mpegTest,
        opus: !!audioTest.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/, ''),
        ogg: !!audioTest.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ''),
        oga: !!audioTest.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/, ''),
        wav: !!audioTest.canPlayType('audio/wav; codecs="1"').replace(/^no$/, ''),
        aac: !!audioTest.canPlayType('audio/aac;').replace(/^no$/, ''),
        caf: !!audioTest.canPlayType('audio/x-caf;').replace(/^no$/, ''),
        m4a: !!(audioTest.canPlayType('audio/x-m4a;') || audioTest.canPlayType('audio/m4a;') || audioTest.canPlayType('audio/aac;')).replace(/^no$/, ''),
        mp4: !!(audioTest.canPlayType('audio/x-mp4;') || audioTest.canPlayType('audio/mp4;') || audioTest.canPlayType('audio/aac;')).replace(/^no$/, ''),
        weba: !!audioTest.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, ''),
        webm: !!audioTest.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/, ''),
        dolby: !!audioTest.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/, ''),
        flac: !!(audioTest.canPlayType('audio/x-flac;') || audioTest.canPlayType('audio/flac;')).replace(/^no$/, '')
      };

      return self;
    },

    /**
     * Mobile browsers will only allow audio to be played after a user interaction.
     * Attempt to automatically unlock audio on the first user interaction.
     * Concept from: http://paulbakaus.com/tutorials/html5/web-audio-on-ios/
     * @return {Howler}
     */
    _enableMobileAudio: function() {
      var self = this || Howler;

      // Only run this on mobile devices if audio isn't already eanbled.
      var isMobile = /iPhone|iPad|iPod|Android|BlackBerry|BB10|Silk|Mobi/i.test(self._navigator && self._navigator.userAgent);
      var isTouch = !!(('ontouchend' in window) || (self._navigator && self._navigator.maxTouchPoints > 0) || (self._navigator && self._navigator.msMaxTouchPoints > 0));
      if (self._mobileEnabled || !self.ctx || (!isMobile && !isTouch)) {
        return;
      }

      self._mobileEnabled = false;

      // Some mobile devices/platforms have distortion issues when opening/closing tabs and/or web views.
      // Bugs in the browser (especially Mobile Safari) can cause the sampleRate to change from 44100 to 48000.
      // By calling Howler.unload(), we create a new AudioContext with the correct sampleRate.
      if (!self._mobileUnloaded && self.ctx.sampleRate !== 44100) {
        self._mobileUnloaded = true;
        self.unload();
      }

      // Scratch buffer for enabling iOS to dispose of web audio buffers correctly, as per:
      // http://stackoverflow.com/questions/24119684
      self._scratchBuffer = self.ctx.createBuffer(1, 1, 22050);

      // Call this method on touch start to create and play a buffer,
      // then check if the audio actually played to determine if
      // audio has now been unlocked on iOS, Android, etc.
      var unlock = function() {
        // Fix Android can not play in suspend state.
        Howler._autoResume();

        // Create an empty buffer.
        var source = self.ctx.createBufferSource();
        source.buffer = self._scratchBuffer;
        source.connect(self.ctx.destination);

        // Play the empty buffer.
        if (typeof source.start === 'undefined') {
          source.noteOn(0);
        } else {
          source.start(0);
        }

        // Calling resume() on a stack initiated by user gesture is what actually unlocks the audio on Android Chrome >= 55.
        if (typeof self.ctx.resume === 'function') {
          self.ctx.resume();
        }

        // Setup a timeout to check that we are unlocked on the next event loop.
        source.onended = function() {
          source.disconnect(0);

          // Update the unlocked state and prevent this check from happening again.
          self._mobileEnabled = true;
          self.mobileAutoEnable = false;

          // Remove the touch start listener.
          document.removeEventListener('touchstart', unlock, true);
          document.removeEventListener('touchend', unlock, true);
        };
      };

      // Setup a touch start listener to attempt an unlock in.
      document.addEventListener('touchstart', unlock, true);
      document.addEventListener('touchend', unlock, true);

      return self;
    },

    /**
     * Automatically suspend the Web Audio AudioContext after no sound has played for 30 seconds.
     * This saves processing/energy and fixes various browser-specific bugs with audio getting stuck.
     * @return {Howler}
     */
    _autoSuspend: function() {
      var self = this;

      if (!self.autoSuspend || !self.ctx || typeof self.ctx.suspend === 'undefined' || !Howler.usingWebAudio) {
        return;
      }

      // Check if any sounds are playing.
      for (var i=0; i<self._howls.length; i++) {
        if (self._howls[i]._webAudio) {
          for (var j=0; j<self._howls[i]._sounds.length; j++) {
            if (!self._howls[i]._sounds[j]._paused) {
              return self;
            }
          }
        }
      }

      if (self._suspendTimer) {
        clearTimeout(self._suspendTimer);
      }

      // If no sound has played after 30 seconds, suspend the context.
      self._suspendTimer = setTimeout(function() {
        if (!self.autoSuspend) {
          return;
        }

        self._suspendTimer = null;
        self.state = 'suspending';
        self.ctx.suspend().then(function() {
          self.state = 'suspended';

          if (self._resumeAfterSuspend) {
            delete self._resumeAfterSuspend;
            self._autoResume();
          }
        });
      }, 30000);

      return self;
    },

    /**
     * Automatically resume the Web Audio AudioContext when a new sound is played.
     * @return {Howler}
     */
    _autoResume: function() {
      var self = this;

      if (!self.ctx || typeof self.ctx.resume === 'undefined' || !Howler.usingWebAudio) {
        return;
      }

      if (self.state === 'running' && self._suspendTimer) {
        clearTimeout(self._suspendTimer);
        self._suspendTimer = null;
      } else if (self.state === 'suspended') {
        self.ctx.resume().then(function() {
          self.state = 'running';

          // Emit to all Howls that the audio has resumed.
          for (var i=0; i<self._howls.length; i++) {
            self._howls[i]._emit('resume');
          }
        });

        if (self._suspendTimer) {
          clearTimeout(self._suspendTimer);
          self._suspendTimer = null;
        }
      } else if (self.state === 'suspending') {
        self._resumeAfterSuspend = true;
      }

      return self;
    }
  };

  // Setup the global audio controller.
  var Howler = new HowlerGlobal();

  /** Group Methods **/
  /***************************************************************************/

  /**
   * Create an audio group controller.
   * @param {Object} o Passed in properties for this group.
   */
  var Howl = function(o) {
    var self = this;

    // Throw an error if no source is provided.
    if (!o.src || o.src.length === 0) {
      console.error('An array of source files must be passed with any new Howl.');
      return;
    }

    self.init(o);
  };
  Howl.prototype = {
    /**
     * Initialize a new Howl group object.
     * @param  {Object} o Passed in properties for this group.
     * @return {Howl}
     */
    init: function(o) {
      var self = this;

      // If we don't have an AudioContext created yet, run the setup.
      if (!Howler.ctx) {
        setupAudioContext();
      }

      // Setup user-defined default properties.
      self._autoplay = o.autoplay || false;
      self._format = (typeof o.format !== 'string') ? o.format : [o.format];
      self._html5 = o.html5 || false;
      self._muted = o.mute || false;
      self._loop = o.loop || false;
      self._pool = o.pool || 5;
      self._preload = (typeof o.preload === 'boolean') ? o.preload : true;
      self._rate = o.rate || 1;
      self._sprite = o.sprite || {};
      self._src = (typeof o.src !== 'string') ? o.src : [o.src];
      self._volume = o.volume !== undefined ? o.volume : 1;
      self._xhrWithCredentials = o.xhrWithCredentials || false;

      // Setup all other default properties.
      self._duration = 0;
      self._state = 'unloaded';
      self._sounds = [];
      self._endTimers = {};
      self._queue = [];
      self._playLock = false;

      // Setup event listeners.
      self._onend = o.onend ? [{fn: o.onend}] : [];
      self._onfade = o.onfade ? [{fn: o.onfade}] : [];
      self._onload = o.onload ? [{fn: o.onload}] : [];
      self._onloaderror = o.onloaderror ? [{fn: o.onloaderror}] : [];
      self._onplayerror = o.onplayerror ? [{fn: o.onplayerror}] : [];
      self._onpause = o.onpause ? [{fn: o.onpause}] : [];
      self._onplay = o.onplay ? [{fn: o.onplay}] : [];
      self._onstop = o.onstop ? [{fn: o.onstop}] : [];
      self._onmute = o.onmute ? [{fn: o.onmute}] : [];
      self._onvolume = o.onvolume ? [{fn: o.onvolume}] : [];
      self._onrate = o.onrate ? [{fn: o.onrate}] : [];
      self._onseek = o.onseek ? [{fn: o.onseek}] : [];
      self._onresume = [];

      // Web Audio or HTML5 Audio?
      self._webAudio = Howler.usingWebAudio && !self._html5;

      // Automatically try to enable audio on iOS.
      if (typeof Howler.ctx !== 'undefined' && Howler.ctx && Howler.mobileAutoEnable) {
        Howler._enableMobileAudio();
      }

      // Keep track of this Howl group in the global controller.
      Howler._howls.push(self);

      // If they selected autoplay, add a play event to the load queue.
      if (self._autoplay) {
        self._queue.push({
          event: 'play',
          action: function() {
            self.play();
          }
        });
      }

      // Load the source file unless otherwise specified.
      if (self._preload) {
        self.load();
      }

      return self;
    },

    /**
     * Load the audio file.
     * @return {Howler}
     */
    load: function() {
      var self = this;
      var url = null;

      // If no audio is available, quit immediately.
      if (Howler.noAudio) {
        self._emit('loaderror', null, 'No audio support.');
        return;
      }

      // Make sure our source is in an array.
      if (typeof self._src === 'string') {
        self._src = [self._src];
      }

      // Loop through the sources and pick the first one that is compatible.
      for (var i=0; i<self._src.length; i++) {
        var ext, str;

        if (self._format && self._format[i]) {
          // If an extension was specified, use that instead.
          ext = self._format[i];
        } else {
          // Make sure the source is a string.
          str = self._src[i];
          if (typeof str !== 'string') {
            self._emit('loaderror', null, 'Non-string found in selected audio sources - ignoring.');
            continue;
          }

          // Extract the file extension from the URL or base64 data URI.
          ext = /^data:audio\/([^;,]+);/i.exec(str);
          if (!ext) {
            ext = /\.([^.]+)$/.exec(str.split('?', 1)[0]);
          }

          if (ext) {
            ext = ext[1].toLowerCase();
          }
        }

        // Log a warning if no extension was found.
        if (!ext) {
          console.warn('No file extension was found. Consider using the "format" property or specify an extension.');
        }

        // Check if this extension is available.
        if (ext && Howler.codecs(ext)) {
          url = self._src[i];
          break;
        }
      }

      if (!url) {
        self._emit('loaderror', null, 'No codec support for selected audio sources.');
        return;
      }

      self._src = url;
      self._state = 'loading';

      // If the hosting page is HTTPS and the source isn't,
      // drop down to HTML5 Audio to avoid Mixed Content errors.
      if (window.location.protocol === 'https:' && url.slice(0, 5) === 'http:') {
        self._html5 = true;
        self._webAudio = false;
      }

      // Create a new sound object and add it to the pool.
      new Sound(self);

      // Load and decode the audio data for playback.
      if (self._webAudio) {
        loadBuffer(self);
      }

      return self;
    },

    /**
     * Play a sound or resume previous playback.
     * @param  {String/Number} sprite   Sprite name for sprite playback or sound id to continue previous.
     * @param  {Boolean} internal Internal Use: true prevents event firing.
     * @return {Number}          Sound ID.
     */
    play: function(sprite, internal) {
      var self = this;
      var id = null;

      // Determine if a sprite, sound id or nothing was passed
      if (typeof sprite === 'number') {
        id = sprite;
        sprite = null;
      } else if (typeof sprite === 'string' && self._state === 'loaded' && !self._sprite[sprite]) {
        // If the passed sprite doesn't exist, do nothing.
        return null;
      } else if (typeof sprite === 'undefined') {
        // Use the default sound sprite (plays the full audio length).
        sprite = '__default';

        // Check if there is a single paused sound that isn't ended.
        // If there is, play that sound. If not, continue as usual.
        var num = 0;
        for (var i=0; i<self._sounds.length; i++) {
          if (self._sounds[i]._paused && !self._sounds[i]._ended) {
            num++;
            id = self._sounds[i]._id;
          }
        }

        if (num === 1) {
          sprite = null;
        } else {
          id = null;
        }
      }

      // Get the selected node, or get one from the pool.
      var sound = id ? self._soundById(id) : self._inactiveSound();

      // If the sound doesn't exist, do nothing.
      if (!sound) {
        return null;
      }

      // Select the sprite definition.
      if (id && !sprite) {
        sprite = sound._sprite || '__default';
      }

      // If the sound hasn't loaded, we must wait to get the audio's duration.
      // We also need to wait to make sure we don't run into race conditions with
      // the order of function calls.
      if (self._state !== 'loaded') {
        // Set the sprite value on this sound.
        sound._sprite = sprite;

        // Makr this sounded as not ended in case another sound is played before this one loads.
        sound._ended = false;

        // Add the sound to the queue to be played on load.
        var soundId = sound._id;
        self._queue.push({
          event: 'play',
          action: function() {
            self.play(soundId);
          }
        });

        return soundId;
      }

      // Don't play the sound if an id was passed and it is already playing.
      if (id && !sound._paused) {
        // Trigger the play event, in order to keep iterating through queue.
        if (!internal) {
          setTimeout(function() {
            self._emit('play', sound._id);
          }, 0);
        }

        return sound._id;
      }

      // Make sure the AudioContext isn't suspended, and resume it if it is.
      if (self._webAudio) {
        Howler._autoResume();
      }

      // Determine how long to play for and where to start playing.
      var seek = Math.max(0, sound._seek > 0 ? sound._seek : self._sprite[sprite][0] / 1000);
      var duration = Math.max(0, ((self._sprite[sprite][0] + self._sprite[sprite][1]) / 1000) - seek);
      var timeout = (duration * 1000) / Math.abs(sound._rate);

      // Update the parameters of the sound
      sound._paused = false;
      sound._ended = false;
      sound._sprite = sprite;
      sound._seek = seek;
      sound._start = self._sprite[sprite][0] / 1000;
      sound._stop = (self._sprite[sprite][0] + self._sprite[sprite][1]) / 1000;
      sound._loop = !!(sound._loop || self._sprite[sprite][2]);

      // Begin the actual playback.
      var node = sound._node;
      if (self._webAudio) {
        // Fire this when the sound is ready to play to begin Web Audio playback.
        var playWebAudio = function() {
          self._refreshBuffer(sound);

          // Setup the playback params.
          var vol = (sound._muted || self._muted) ? 0 : sound._volume;
          node.gain.setValueAtTime(vol, Howler.ctx.currentTime);
          sound._playStart = Howler.ctx.currentTime;

          // Play the sound using the supported method.
          if (typeof node.bufferSource.start === 'undefined') {
            sound._loop ? node.bufferSource.noteGrainOn(0, seek, 86400) : node.bufferSource.noteGrainOn(0, seek, duration);
          } else {
            sound._loop ? node.bufferSource.start(0, seek, 86400) : node.bufferSource.start(0, seek, duration);
          }

          // Start a new timer if none is present.
          if (timeout !== Infinity) {
            self._endTimers[sound._id] = setTimeout(self._ended.bind(self, sound), timeout);
          }

          if (!internal) {
            setTimeout(function() {
              self._emit('play', sound._id);
            }, 0);
          }
        };

        if (Howler.state === 'running') {
          playWebAudio();
        } else {
          self.once('resume', playWebAudio);

          // Cancel the end timer.
          self._clearTimer(sound._id);
        }
      } else {
        // Fire this when the sound is ready to play to begin HTML5 Audio playback.
        var playHtml5 = function() {
          node.currentTime = seek;
          node.muted = sound._muted || self._muted || Howler._muted || node.muted;
          node.volume = sound._volume * Howler.volume();
          node.playbackRate = sound._rate;

          // Mobile browsers will throw an error if this is called without user interaction.
          try {
            var play = node.play();

            // Support older browsers that don't support promises, and thus don't have this issue.
            if (typeof Promise !== 'undefined' && play instanceof Promise) {
              // Implements a lock to prevent DOMException: The play() request was interrupted by a call to pause().
              self._playLock = true;

              // Releases the lock and executes queued actions.
              play.then(function () {
                self._playLock = false;
                self._loadQueue();
              });
            }

            // If the node is still paused, then we can assume there was a playback issue.
            if (node.paused) {
              self._emit('playerror', sound._id, 'Playback was unable to start. This is most commonly an issue ' +
                'on mobile devices where playback was not within a user interaction.');
              return;
            }

            // Setup the new end timer.
            if (timeout !== Infinity) {
              self._endTimers[sound._id] = setTimeout(self._ended.bind(self, sound), timeout);
            }

            if (!internal) {
              self._emit('play', sound._id);
            }
          } catch (err) {
            self._emit('playerror', sound._id, err);
          }
        };

        // Play immediately if ready, or wait for the 'canplaythrough'e vent.
        var loadedNoReadyState = (window && window.ejecta) || (!node.readyState && Howler._navigator.isCocoonJS);
        if (node.readyState === 4 || loadedNoReadyState) {
          playHtml5();
        } else {
          var listener = function() {
            // Begin playback.
            playHtml5();

            // Clear this listener.
            node.removeEventListener(Howler._canPlayEvent, listener, false);
          };
          node.addEventListener(Howler._canPlayEvent, listener, false);

          // Cancel the end timer.
          self._clearTimer(sound._id);
        }
      }

      return sound._id;
    },

    /**
     * Pause playback and save current position.
     * @param  {Number} id The sound ID (empty to pause all in group).
     * @return {Howl}
     */
    pause: function(id) {
      var self = this;

      // If the sound hasn't loaded or a play() promise is pending, add it to the load queue to pause when capable.
      if (self._state !== 'loaded' || self._playLock) {
        self._queue.push({
          event: 'pause',
          action: function() {
            self.pause(id);
          }
        });

        return self;
      }

      // If no id is passed, get all ID's to be paused.
      var ids = self._getSoundIds(id);

      for (var i=0; i<ids.length; i++) {
        // Clear the end timer.
        self._clearTimer(ids[i]);

        // Get the sound.
        var sound = self._soundById(ids[i]);

        if (sound && !sound._paused) {
          // Reset the seek position.
          sound._seek = self.seek(ids[i]);
          sound._rateSeek = 0;
          sound._paused = true;

          // Stop currently running fades.
          self._stopFade(ids[i]);

          if (sound._node) {
            if (self._webAudio) {
              // Make sure the sound has been created.
              if (!sound._node.bufferSource) {
                continue;
              }

              if (typeof sound._node.bufferSource.stop === 'undefined') {
                sound._node.bufferSource.noteOff(0);
              } else {
                sound._node.bufferSource.stop(0);
              }

              // Clean up the buffer source.
              self._cleanBuffer(sound._node);
            } else if (!isNaN(sound._node.duration) || sound._node.duration === Infinity) {
              sound._node.pause();
            }
          }
        }

        // Fire the pause event, unless `true` is passed as the 2nd argument.
        if (!arguments[1]) {
          self._emit('pause', sound ? sound._id : null);
        }
      }

      return self;
    },

    /**
     * Stop playback and reset to start.
     * @param  {Number} id The sound ID (empty to stop all in group).
     * @param  {Boolean} internal Internal Use: true prevents event firing.
     * @return {Howl}
     */
    stop: function(id, internal) {
      var self = this;

      // If the sound hasn't loaded, add it to the load queue to stop when capable.
      if (self._state !== 'loaded') {
        self._queue.push({
          event: 'stop',
          action: function() {
            self.stop(id);
          }
        });

        return self;
      }

      // If no id is passed, get all ID's to be stopped.
      var ids = self._getSoundIds(id);

      for (var i=0; i<ids.length; i++) {
        // Clear the end timer.
        self._clearTimer(ids[i]);

        // Get the sound.
        var sound = self._soundById(ids[i]);

        if (sound) {
          // Reset the seek position.
          sound._seek = sound._start || 0;
          sound._rateSeek = 0;
          sound._paused = true;
          sound._ended = true;

          // Stop currently running fades.
          self._stopFade(ids[i]);

          if (sound._node) {
            if (self._webAudio) {
              // Make sure the sound's AudioBufferSourceNode has been created.
              if (sound._node.bufferSource) {
                if (typeof sound._node.bufferSource.stop === 'undefined') {
                  sound._node.bufferSource.noteOff(0);
                } else {
                  sound._node.bufferSource.stop(0);
                }

                // Clean up the buffer source.
                self._cleanBuffer(sound._node);
              }
            } else if (!isNaN(sound._node.duration) || sound._node.duration === Infinity) {
              sound._node.currentTime = sound._start || 0;
              sound._node.pause();
            }
          }

          if (!internal) {
            self._emit('stop', sound._id);
          }
        }
      }

      return self;
    },

    /**
     * Mute/unmute a single sound or all sounds in this Howl group.
     * @param  {Boolean} muted Set to true to mute and false to unmute.
     * @param  {Number} id    The sound ID to update (omit to mute/unmute all).
     * @return {Howl}
     */
    mute: function(muted, id) {
      var self = this;

      // If the sound hasn't loaded, add it to the load queue to mute when capable.
      if (self._state !== 'loaded') {
        self._queue.push({
          event: 'mute',
          action: function() {
            self.mute(muted, id);
          }
        });

        return self;
      }

      // If applying mute/unmute to all sounds, update the group's value.
      if (typeof id === 'undefined') {
        if (typeof muted === 'boolean') {
          self._muted = muted;
        } else {
          return self._muted;
        }
      }

      // If no id is passed, get all ID's to be muted.
      var ids = self._getSoundIds(id);

      for (var i=0; i<ids.length; i++) {
        // Get the sound.
        var sound = self._soundById(ids[i]);

        if (sound) {
          sound._muted = muted;

          // Cancel active fade and set the volume to the end value.
          if (sound._interval) {
            self._stopFade(sound._id);
          }

          if (self._webAudio && sound._node) {
            sound._node.gain.setValueAtTime(muted ? 0 : sound._volume, Howler.ctx.currentTime);
          } else if (sound._node) {
            sound._node.muted = Howler._muted ? true : muted;
          }

          self._emit('mute', sound._id);
        }
      }

      return self;
    },

    /**
     * Get/set the volume of this sound or of the Howl group. This method can optionally take 0, 1 or 2 arguments.
     *   volume() -> Returns the group's volume value.
     *   volume(id) -> Returns the sound id's current volume.
     *   volume(vol) -> Sets the volume of all sounds in this Howl group.
     *   volume(vol, id) -> Sets the volume of passed sound id.
     * @return {Howl/Number} Returns self or current volume.
     */
    volume: function() {
      var self = this;
      var args = arguments;
      var vol, id;

      // Determine the values based on arguments.
      if (args.length === 0) {
        // Return the value of the groups' volume.
        return self._volume;
      } else if (args.length === 1 || args.length === 2 && typeof args[1] === 'undefined') {
        // First check if this is an ID, and if not, assume it is a new volume.
        var ids = self._getSoundIds();
        var index = ids.indexOf(args[0]);
        if (index >= 0) {
          id = parseInt(args[0], 10);
        } else {
          vol = parseFloat(args[0]);
        }
      } else if (args.length >= 2) {
        vol = parseFloat(args[0]);
        id = parseInt(args[1], 10);
      }

      // Update the volume or return the current volume.
      var sound;
      if (typeof vol !== 'undefined' && vol >= 0 && vol <= 1) {
        // If the sound hasn't loaded, add it to the load queue to change volume when capable.
        if (self._state !== 'loaded') {
          self._queue.push({
            event: 'volume',
            action: function() {
              self.volume.apply(self, args);
            }
          });

          return self;
        }

        // Set the group volume.
        if (typeof id === 'undefined') {
          self._volume = vol;
        }

        // Update one or all volumes.
        id = self._getSoundIds(id);
        for (var i=0; i<id.length; i++) {
          // Get the sound.
          sound = self._soundById(id[i]);

          if (sound) {
            sound._volume = vol;

            // Stop currently running fades.
            if (!args[2]) {
              self._stopFade(id[i]);
            }

            if (self._webAudio && sound._node && !sound._muted) {
              sound._node.gain.setValueAtTime(vol, Howler.ctx.currentTime);
            } else if (sound._node && !sound._muted) {
              sound._node.volume = vol * Howler.volume();
            }

            self._emit('volume', sound._id);
          }
        }
      } else {
        sound = id ? self._soundById(id) : self._sounds[0];
        return sound ? sound._volume : 0;
      }

      return self;
    },

    /**
     * Fade a currently playing sound between two volumes (if no id is passsed, all sounds will fade).
     * @param  {Number} from The value to fade from (0.0 to 1.0).
     * @param  {Number} to   The volume to fade to (0.0 to 1.0).
     * @param  {Number} len  Time in milliseconds to fade.
     * @param  {Number} id   The sound id (omit to fade all sounds).
     * @return {Howl}
     */
    fade: function(from, to, len, id) {
      var self = this;

      // If the sound hasn't loaded, add it to the load queue to fade when capable.
      if (self._state !== 'loaded') {
        self._queue.push({
          event: 'fade',
          action: function() {
            self.fade(from, to, len, id);
          }
        });

        return self;
      }

      // Set the volume to the start position.
      self.volume(from, id);

      // Fade the volume of one or all sounds.
      var ids = self._getSoundIds(id);
      for (var i=0; i<ids.length; i++) {
        // Get the sound.
        var sound = self._soundById(ids[i]);

        // Create a linear fade or fall back to timeouts with HTML5 Audio.
        if (sound) {
          // Stop the previous fade if no sprite is being used (otherwise, volume handles this).
          if (!id) {
            self._stopFade(ids[i]);
          }

          // If we are using Web Audio, let the native methods do the actual fade.
          if (self._webAudio && !sound._muted) {
            var currentTime = Howler.ctx.currentTime;
            var end = currentTime + (len / 1000);
            sound._volume = from;
            sound._node.gain.setValueAtTime(from, currentTime);
            sound._node.gain.linearRampToValueAtTime(to, end);
          }

          self._startFadeInterval(sound, from, to, len, ids[i], typeof id === 'undefined');
        }
      }

      return self;
    },

    /**
     * Starts the internal interval to fade a sound.
     * @param  {Object} sound Reference to sound to fade.
     * @param  {Number} from The value to fade from (0.0 to 1.0).
     * @param  {Number} to   The volume to fade to (0.0 to 1.0).
     * @param  {Number} len  Time in milliseconds to fade.
     * @param  {Number} id   The sound id to fade.
     * @param  {Boolean} isGroup   If true, set the volume on the group.
     */
    _startFadeInterval: function(sound, from, to, len, id, isGroup) {
      var self = this;
      var vol = from;
      var dir = from > to ? 'out' : 'in';
      var diff = Math.abs(from - to);
      var steps = diff / 0.01;
      var stepLen = (steps > 0) ? len / steps : len;

      // Since browsers clamp timeouts to 4ms, we need to clamp our steps to that too.
      if (stepLen < 4) {
        steps = Math.ceil(steps / (4 / stepLen));
        stepLen = 4;
      }

      // Store the value being faded to.
      sound._fadeTo = to;

      // Update the volume value on each interval tick.
      sound._interval = setInterval(function() {
        // Update the volume amount, but only if the volume should change.
        if (steps > 0) {
          vol += (dir === 'in' ? 0.01 : -0.01);
        }

        // Make sure the volume is in the right bounds.
        vol = Math.max(0, vol);
        vol = Math.min(1, vol);

        // Round to within 2 decimal points.
        vol = Math.round(vol * 100) / 100;

        // Change the volume.
        if (self._webAudio) {
          sound._volume = vol;
        } else {
          self.volume(vol, sound._id, true);
        }

        // Set the group's volume.
        if (isGroup) {
          self._volume = vol;
        }

        // When the fade is complete, stop it and fire event.
        if ((to < from && vol <= to) || (to > from && vol >= to)) {
          clearInterval(sound._interval);
          sound._interval = null;
          sound._fadeTo = null;
          self.volume(to, sound._id);
          self._emit('fade', sound._id);
        }
      }, stepLen);
    },

    /**
     * Internal method that stops the currently playing fade when
     * a new fade starts, volume is changed or the sound is stopped.
     * @param  {Number} id The sound id.
     * @return {Howl}
     */
    _stopFade: function(id) {
      var self = this;
      var sound = self._soundById(id);

      if (sound && sound._interval) {
        if (self._webAudio) {
          sound._node.gain.cancelScheduledValues(Howler.ctx.currentTime);
        }

        clearInterval(sound._interval);
        sound._interval = null;
        self.volume(sound._fadeTo, id);
        sound._fadeTo = null;
        self._emit('fade', id);
      }

      return self;
    },

    /**
     * Get/set the loop parameter on a sound. This method can optionally take 0, 1 or 2 arguments.
     *   loop() -> Returns the group's loop value.
     *   loop(id) -> Returns the sound id's loop value.
     *   loop(loop) -> Sets the loop value for all sounds in this Howl group.
     *   loop(loop, id) -> Sets the loop value of passed sound id.
     * @return {Howl/Boolean} Returns self or current loop value.
     */
    loop: function() {
      var self = this;
      var args = arguments;
      var loop, id, sound;

      // Determine the values for loop and id.
      if (args.length === 0) {
        // Return the grou's loop value.
        return self._loop;
      } else if (args.length === 1) {
        if (typeof args[0] === 'boolean') {
          loop = args[0];
          self._loop = loop;
        } else {
          // Return this sound's loop value.
          sound = self._soundById(parseInt(args[0], 10));
          return sound ? sound._loop : false;
        }
      } else if (args.length === 2) {
        loop = args[0];
        id = parseInt(args[1], 10);
      }

      // If no id is passed, get all ID's to be looped.
      var ids = self._getSoundIds(id);
      for (var i=0; i<ids.length; i++) {
        sound = self._soundById(ids[i]);

        if (sound) {
          sound._loop = loop;
          if (self._webAudio && sound._node && sound._node.bufferSource) {
            sound._node.bufferSource.loop = loop;
            if (loop) {
              sound._node.bufferSource.loopStart = sound._start || 0;
              sound._node.bufferSource.loopEnd = sound._stop;
            }
          }
        }
      }

      return self;
    },

    /**
     * Get/set the playback rate of a sound. This method can optionally take 0, 1 or 2 arguments.
     *   rate() -> Returns the first sound node's current playback rate.
     *   rate(id) -> Returns the sound id's current playback rate.
     *   rate(rate) -> Sets the playback rate of all sounds in this Howl group.
     *   rate(rate, id) -> Sets the playback rate of passed sound id.
     * @return {Howl/Number} Returns self or the current playback rate.
     */
    rate: function() {
      var self = this;
      var args = arguments;
      var rate, id;

      // Determine the values based on arguments.
      if (args.length === 0) {
        // We will simply return the current rate of the first node.
        id = self._sounds[0]._id;
      } else if (args.length === 1) {
        // First check if this is an ID, and if not, assume it is a new rate value.
        var ids = self._getSoundIds();
        var index = ids.indexOf(args[0]);
        if (index >= 0) {
          id = parseInt(args[0], 10);
        } else {
          rate = parseFloat(args[0]);
        }
      } else if (args.length === 2) {
        rate = parseFloat(args[0]);
        id = parseInt(args[1], 10);
      }

      // Update the playback rate or return the current value.
      var sound;
      if (typeof rate === 'number') {
        // If the sound hasn't loaded, add it to the load queue to change playback rate when capable.
        if (self._state !== 'loaded') {
          self._queue.push({
            event: 'rate',
            action: function() {
              self.rate.apply(self, args);
            }
          });

          return self;
        }

        // Set the group rate.
        if (typeof id === 'undefined') {
          self._rate = rate;
        }

        // Update one or all volumes.
        id = self._getSoundIds(id);
        for (var i=0; i<id.length; i++) {
          // Get the sound.
          sound = self._soundById(id[i]);

          if (sound) {
            // Keep track of our position when the rate changed and update the playback
            // start position so we can properly adjust the seek position for time elapsed.
            sound._rateSeek = self.seek(id[i]);
            sound._playStart = self._webAudio ? Howler.ctx.currentTime : sound._playStart;
            sound._rate = rate;

            // Change the playback rate.
            if (self._webAudio && sound._node && sound._node.bufferSource) {
              sound._node.bufferSource.playbackRate.value = rate;
            } else if (sound._node) {
              sound._node.playbackRate = rate;
            }

            // Reset the timers.
            var seek = self.seek(id[i]);
            var duration = ((self._sprite[sound._sprite][0] + self._sprite[sound._sprite][1]) / 1000) - seek;
            var timeout = (duration * 1000) / Math.abs(sound._rate);

            // Start a new end timer if sound is already playing.
            if (self._endTimers[id[i]] || !sound._paused) {
              self._clearTimer(id[i]);
              self._endTimers[id[i]] = setTimeout(self._ended.bind(self, sound), timeout);
            }

            self._emit('rate', sound._id);
          }
        }
      } else {
        sound = self._soundById(id);
        return sound ? sound._rate : self._rate;
      }

      return self;
    },

    /**
     * Get/set the seek position of a sound. This method can optionally take 0, 1 or 2 arguments.
     *   seek() -> Returns the first sound node's current seek position.
     *   seek(id) -> Returns the sound id's current seek position.
     *   seek(seek) -> Sets the seek position of the first sound node.
     *   seek(seek, id) -> Sets the seek position of passed sound id.
     * @return {Howl/Number} Returns self or the current seek position.
     */
    seek: function() {
      var self = this;
      var args = arguments;
      var seek, id;

      // Determine the values based on arguments.
      if (args.length === 0) {
        // We will simply return the current position of the first node.
        id = self._sounds[0]._id;
      } else if (args.length === 1) {
        // First check if this is an ID, and if not, assume it is a new seek position.
        var ids = self._getSoundIds();
        var index = ids.indexOf(args[0]);
        if (index >= 0) {
          id = parseInt(args[0], 10);
        } else if (self._sounds.length) {
          id = self._sounds[0]._id;
          seek = parseFloat(args[0]);
        }
      } else if (args.length === 2) {
        seek = parseFloat(args[0]);
        id = parseInt(args[1], 10);
      }

      // If there is no ID, bail out.
      if (typeof id === 'undefined') {
        return self;
      }

      // If the sound hasn't loaded, add it to the load queue to seek when capable.
      if (self._state !== 'loaded') {
        self._queue.push({
          event: 'seek',
          action: function() {
            self.seek.apply(self, args);
          }
        });

        return self;
      }

      // Get the sound.
      var sound = self._soundById(id);

      if (sound) {
        if (typeof seek === 'number' && seek >= 0) {
          // Pause the sound and update position for restarting playback.
          var playing = self.playing(id);
          if (playing) {
            self.pause(id, true);
          }

          // Move the position of the track and cancel timer.
          sound._seek = seek;
          sound._ended = false;
          self._clearTimer(id);

          // Restart the playback if the sound was playing.
          if (playing) {
            self.play(id, true);
          }

          // Update the seek position for HTML5 Audio.
          if (!self._webAudio && sound._node) {
            sound._node.currentTime = seek;
          }

          self._emit('seek', id);
        } else {
          if (self._webAudio) {
            var realTime = self.playing(id) ? Howler.ctx.currentTime - sound._playStart : 0;
            var rateSeek = sound._rateSeek ? sound._rateSeek - sound._seek : 0;
            return sound._seek + (rateSeek + realTime * Math.abs(sound._rate));
          } else {
            return sound._node.currentTime;
          }
        }
      }

      return self;
    },

    /**
     * Check if a specific sound is currently playing or not (if id is provided), or check if at least one of the sounds in the group is playing or not.
     * @param  {Number}  id The sound id to check. If none is passed, the whole sound group is checked.
     * @return {Boolean} True if playing and false if not.
     */
    playing: function(id) {
      var self = this;

      // Check the passed sound ID (if any).
      if (typeof id === 'number') {
        var sound = self._soundById(id);
        return sound ? !sound._paused : false;
      }

      // Otherwise, loop through all sounds and check if any are playing.
      for (var i=0; i<self._sounds.length; i++) {
        if (!self._sounds[i]._paused) {
          return true;
        }
      }

      return false;
    },

    /**
     * Get the duration of this sound. Passing a sound id will return the sprite duration.
     * @param  {Number} id The sound id to check. If none is passed, return full source duration.
     * @return {Number} Audio duration in seconds.
     */
    duration: function(id) {
      var self = this;
      var duration = self._duration;

      // If we pass an ID, get the sound and return the sprite length.
      var sound = self._soundById(id);
      if (sound) {
        duration = self._sprite[sound._sprite][1] / 1000;
      }

      return duration;
    },

    /**
     * Returns the current loaded state of this Howl.
     * @return {String} 'unloaded', 'loading', 'loaded'
     */
    state: function() {
      return this._state;
    },

    /**
     * Unload and destroy the current Howl object.
     * This will immediately stop all sound instances attached to this group.
     */
    unload: function() {
      var self = this;

      // Stop playing any active sounds.
      var sounds = self._sounds;
      for (var i=0; i<sounds.length; i++) {
        // Stop the sound if it is currently playing.
        if (!sounds[i]._paused) {
          self.stop(sounds[i]._id);
        }

        // Remove the source or disconnect.
        if (!self._webAudio) {
          // Set the source to 0-second silence to stop any downloading (except in IE).
          var checkIE = /MSIE |Trident\//.test(Howler._navigator && Howler._navigator.userAgent);
          if (!checkIE) {
            sounds[i]._node.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
          }

          // Remove any event listeners.
          sounds[i]._node.removeEventListener('error', sounds[i]._errorFn, false);
          sounds[i]._node.removeEventListener(Howler._canPlayEvent, sounds[i]._loadFn, false);
        }

        // Empty out all of the nodes.
        delete sounds[i]._node;

        // Make sure all timers are cleared out.
        self._clearTimer(sounds[i]._id);

        // Remove the references in the global Howler object.
        var index = Howler._howls.indexOf(self);
        if (index >= 0) {
          Howler._howls.splice(index, 1);
        }
      }

      // Delete this sound from the cache (if no other Howl is using it).
      var remCache = true;
      for (i=0; i<Howler._howls.length; i++) {
        if (Howler._howls[i]._src === self._src) {
          remCache = false;
          break;
        }
      }

      if (cache && remCache) {
        delete cache[self._src];
      }

      // Clear global errors.
      Howler.noAudio = false;

      // Clear out `self`.
      self._state = 'unloaded';
      self._sounds = [];
      self = null;

      return null;
    },

    /**
     * Listen to a custom event.
     * @param  {String}   event Event name.
     * @param  {Function} fn    Listener to call.
     * @param  {Number}   id    (optional) Only listen to events for this sound.
     * @param  {Number}   once  (INTERNAL) Marks event to fire only once.
     * @return {Howl}
     */
    on: function(event, fn, id, once) {
      var self = this;
      var events = self['_on' + event];

      if (typeof fn === 'function') {
        events.push(once ? {id: id, fn: fn, once: once} : {id: id, fn: fn});
      }

      return self;
    },

    /**
     * Remove a custom event. Call without parameters to remove all events.
     * @param  {String}   event Event name.
     * @param  {Function} fn    Listener to remove. Leave empty to remove all.
     * @param  {Number}   id    (optional) Only remove events for this sound.
     * @return {Howl}
     */
    off: function(event, fn, id) {
      var self = this;
      var events = self['_on' + event];
      var i = 0;

      // Allow passing just an event and ID.
      if (typeof fn === 'number') {
        id = fn;
        fn = null;
      }

      if (fn || id) {
        // Loop through event store and remove the passed function.
        for (i=0; i<events.length; i++) {
          var isId = (id === events[i].id);
          if (fn === events[i].fn && isId || !fn && isId) {
            events.splice(i, 1);
            break;
          }
        }
      } else if (event) {
        // Clear out all events of this type.
        self['_on' + event] = [];
      } else {
        // Clear out all events of every type.
        var keys = Object.keys(self);
        for (i=0; i<keys.length; i++) {
          if ((keys[i].indexOf('_on') === 0) && Array.isArray(self[keys[i]])) {
            self[keys[i]] = [];
          }
        }
      }

      return self;
    },

    /**
     * Listen to a custom event and remove it once fired.
     * @param  {String}   event Event name.
     * @param  {Function} fn    Listener to call.
     * @param  {Number}   id    (optional) Only listen to events for this sound.
     * @return {Howl}
     */
    once: function(event, fn, id) {
      var self = this;

      // Setup the event listener.
      self.on(event, fn, id, 1);

      return self;
    },

    /**
     * Emit all events of a specific type and pass the sound id.
     * @param  {String} event Event name.
     * @param  {Number} id    Sound ID.
     * @param  {Number} msg   Message to go with event.
     * @return {Howl}
     */
    _emit: function(event, id, msg) {
      var self = this;
      var events = self['_on' + event];

      // Loop through event store and fire all functions.
      for (var i=events.length-1; i>=0; i--) {
        if (!events[i].id || events[i].id === id || event === 'load') {
          setTimeout(function(fn) {
            fn.call(this, id, msg);
          }.bind(self, events[i].fn), 0);

          // If this event was setup with `once`, remove it.
          if (events[i].once) {
            self.off(event, events[i].fn, events[i].id);
          }
        }
      }

      return self;
    },

    /**
     * Queue of actions initiated before the sound has loaded.
     * These will be called in sequence, with the next only firing
     * after the previous has finished executing (even if async like play).
     * @return {Howl}
     */
    _loadQueue: function() {
      var self = this;

      if (self._queue.length > 0) {
        var task = self._queue[0];

        // don't move onto the next task until this one is done
        self.once(task.event, function() {
          self._queue.shift();
          self._loadQueue();
        });

        task.action();
      }

      return self;
    },

    /**
     * Fired when playback ends at the end of the duration.
     * @param  {Sound} sound The sound object to work with.
     * @return {Howl}
     */
    _ended: function(sound) {
      var self = this;
      var sprite = sound._sprite;

      // If we are using IE and there was network latency we may be clipping
      // audio before it completes playing. Lets check the node to make sure it
      // believes it has completed, before ending the playback.
      if (!self._webAudio && sound._node && !sound._node.paused && !sound._node.ended && sound._node.currentTime < sound._stop) {
        setTimeout(self._ended.bind(self, sound), 100);
        return self;
      }

      // Should this sound loop?
      var loop = !!(sound._loop || self._sprite[sprite][2]);

      // Fire the ended event.
      self._emit('end', sound._id);

      // Restart the playback for HTML5 Audio loop.
      if (!self._webAudio && loop) {
        self.stop(sound._id, true).play(sound._id);
      }

      // Restart this timer if on a Web Audio loop.
      if (self._webAudio && loop) {
        self._emit('play', sound._id);
        sound._seek = sound._start || 0;
        sound._rateSeek = 0;
        sound._playStart = Howler.ctx.currentTime;

        var timeout = ((sound._stop - sound._start) * 1000) / Math.abs(sound._rate);
        self._endTimers[sound._id] = setTimeout(self._ended.bind(self, sound), timeout);
      }

      // Mark the node as paused.
      if (self._webAudio && !loop) {
        sound._paused = true;
        sound._ended = true;
        sound._seek = sound._start || 0;
        sound._rateSeek = 0;
        self._clearTimer(sound._id);

        // Clean up the buffer source.
        self._cleanBuffer(sound._node);

        // Attempt to auto-suspend AudioContext if no sounds are still playing.
        Howler._autoSuspend();
      }

      // When using a sprite, end the track.
      if (!self._webAudio && !loop) {
        self.stop(sound._id);
      }

      return self;
    },

    /**
     * Clear the end timer for a sound playback.
     * @param  {Number} id The sound ID.
     * @return {Howl}
     */
    _clearTimer: function(id) {
      var self = this;

      if (self._endTimers[id]) {
        clearTimeout(self._endTimers[id]);
        delete self._endTimers[id];
      }

      return self;
    },

    /**
     * Return the sound identified by this ID, or return null.
     * @param  {Number} id Sound ID
     * @return {Object}    Sound object or null.
     */
    _soundById: function(id) {
      var self = this;

      // Loop through all sounds and find the one with this ID.
      for (var i=0; i<self._sounds.length; i++) {
        if (id === self._sounds[i]._id) {
          return self._sounds[i];
        }
      }

      return null;
    },

    /**
     * Return an inactive sound from the pool or create a new one.
     * @return {Sound} Sound playback object.
     */
    _inactiveSound: function() {
      var self = this;

      self._drain();

      // Find the first inactive node to recycle.
      for (var i=0; i<self._sounds.length; i++) {
        if (self._sounds[i]._ended) {
          return self._sounds[i].reset();
        }
      }

      // If no inactive node was found, create a new one.
      return new Sound(self);
    },

    /**
     * Drain excess inactive sounds from the pool.
     */
    _drain: function() {
      var self = this;
      var limit = self._pool;
      var cnt = 0;
      var i = 0;

      // If there are less sounds than the max pool size, we are done.
      if (self._sounds.length < limit) {
        return;
      }

      // Count the number of inactive sounds.
      for (i=0; i<self._sounds.length; i++) {
        if (self._sounds[i]._ended) {
          cnt++;
        }
      }

      // Remove excess inactive sounds, going in reverse order.
      for (i=self._sounds.length - 1; i>=0; i--) {
        if (cnt <= limit) {
          return;
        }

        if (self._sounds[i]._ended) {
          // Disconnect the audio source when using Web Audio.
          if (self._webAudio && self._sounds[i]._node) {
            self._sounds[i]._node.disconnect(0);
          }

          // Remove sounds until we have the pool size.
          self._sounds.splice(i, 1);
          cnt--;
        }
      }
    },

    /**
     * Get all ID's from the sounds pool.
     * @param  {Number} id Only return one ID if one is passed.
     * @return {Array}    Array of IDs.
     */
    _getSoundIds: function(id) {
      var self = this;

      if (typeof id === 'undefined') {
        var ids = [];
        for (var i=0; i<self._sounds.length; i++) {
          ids.push(self._sounds[i]._id);
        }

        return ids;
      } else {
        return [id];
      }
    },

    /**
     * Load the sound back into the buffer source.
     * @param  {Sound} sound The sound object to work with.
     * @return {Howl}
     */
    _refreshBuffer: function(sound) {
      var self = this;

      // Setup the buffer source for playback.
      sound._node.bufferSource = Howler.ctx.createBufferSource();
      sound._node.bufferSource.buffer = cache[self._src];

      // Connect to the correct node.
      if (sound._panner) {
        sound._node.bufferSource.connect(sound._panner);
      } else {
        sound._node.bufferSource.connect(sound._node);
      }

      // Setup looping and playback rate.
      sound._node.bufferSource.loop = sound._loop;
      if (sound._loop) {
        sound._node.bufferSource.loopStart = sound._start || 0;
        sound._node.bufferSource.loopEnd = sound._stop;
      }
      sound._node.bufferSource.playbackRate.value = sound._rate;

      return self;
    },

    /**
     * Prevent memory leaks by cleaning up the buffer source after playback.
     * @param  {Object} node Sound's audio node containing the buffer source.
     * @return {Howl}
     */
    _cleanBuffer: function(node) {
      var self = this;

      if (Howler._scratchBuffer) {
        node.bufferSource.onended = null;
        node.bufferSource.disconnect(0);
        try { node.bufferSource.buffer = Howler._scratchBuffer; } catch(e) {}
      }
      node.bufferSource = null;

      return self;
    }
  };

  /** Single Sound Methods **/
  /***************************************************************************/

  /**
   * Setup the sound object, which each node attached to a Howl group is contained in.
   * @param {Object} howl The Howl parent group.
   */
  var Sound = function(howl) {
    this._parent = howl;
    this.init();
  };
  Sound.prototype = {
    /**
     * Initialize a new Sound object.
     * @return {Sound}
     */
    init: function() {
      var self = this;
      var parent = self._parent;

      // Setup the default parameters.
      self._muted = parent._muted;
      self._loop = parent._loop;
      self._volume = parent._volume;
      self._rate = parent._rate;
      self._seek = 0;
      self._paused = true;
      self._ended = true;
      self._sprite = '__default';

      // Generate a unique ID for this sound.
      self._id = ++Howler._counter;

      // Add itself to the parent's pool.
      parent._sounds.push(self);

      // Create the new node.
      self.create();

      return self;
    },

    /**
     * Create and setup a new sound object, whether HTML5 Audio or Web Audio.
     * @return {Sound}
     */
    create: function() {
      var self = this;
      var parent = self._parent;
      var volume = (Howler._muted || self._muted || self._parent._muted) ? 0 : self._volume;

      if (parent._webAudio) {
        // Create the gain node for controlling volume (the source will connect to this).
        self._node = (typeof Howler.ctx.createGain === 'undefined') ? Howler.ctx.createGainNode() : Howler.ctx.createGain();
        self._node.gain.setValueAtTime(volume, Howler.ctx.currentTime);
        self._node.paused = true;
        self._node.connect(Howler.masterGain);
      } else {
        self._node = new Audio();

        // Listen for errors (http://dev.w3.org/html5/spec-author-view/spec.html#mediaerror).
        self._errorFn = self._errorListener.bind(self);
        self._node.addEventListener('error', self._errorFn, false);

        // Listen for 'canplaythrough' event to let us know the sound is ready.
        self._loadFn = self._loadListener.bind(self);
        self._node.addEventListener(Howler._canPlayEvent, self._loadFn, false);

        // Setup the new audio node.
        self._node.src = parent._src;
        self._node.preload = 'auto';
        self._node.volume = volume * Howler.volume();

        // Begin loading the source.
        self._node.load();
      }

      return self;
    },

    /**
     * Reset the parameters of this sound to the original state (for recycle).
     * @return {Sound}
     */
    reset: function() {
      var self = this;
      var parent = self._parent;

      // Reset all of the parameters of this sound.
      self._muted = parent._muted;
      self._loop = parent._loop;
      self._volume = parent._volume;
      self._rate = parent._rate;
      self._seek = 0;
      self._rateSeek = 0;
      self._paused = true;
      self._ended = true;
      self._sprite = '__default';

      // Generate a new ID so that it isn't confused with the previous sound.
      self._id = ++Howler._counter;

      return self;
    },

    /**
     * HTML5 Audio error listener callback.
     */
    _errorListener: function() {
      var self = this;

      // Fire an error event and pass back the code.
      self._parent._emit('loaderror', self._id, self._node.error ? self._node.error.code : 0);

      // Clear the event listener.
      self._node.removeEventListener('error', self._errorFn, false);
    },

    /**
     * HTML5 Audio canplaythrough listener callback.
     */
    _loadListener: function() {
      var self = this;
      var parent = self._parent;

      // Round up the duration to account for the lower precision in HTML5 Audio.
      parent._duration = Math.ceil(self._node.duration * 10) / 10;

      // Setup a sprite if none is defined.
      if (Object.keys(parent._sprite).length === 0) {
        parent._sprite = {__default: [0, parent._duration * 1000]};
      }

      if (parent._state !== 'loaded') {
        parent._state = 'loaded';
        parent._emit('load');
        parent._loadQueue();
      }

      // Clear the event listener.
      self._node.removeEventListener(Howler._canPlayEvent, self._loadFn, false);
    }
  };

  /** Helper Methods **/
  /***************************************************************************/

  var cache = {};

  /**
   * Buffer a sound from URL, Data URI or cache and decode to audio source (Web Audio API).
   * @param  {Howl} self
   */
  var loadBuffer = function(self) {
    var url = self._src;

    // Check if the buffer has already been cached and use it instead.
    if (cache[url]) {
      // Set the duration from the cache.
      self._duration = cache[url].duration;

      // Load the sound into this Howl.
      loadSound(self);

      return;
    }

    if (/^data:[^;]+;base64,/.test(url)) {
      // Decode the base64 data URI without XHR, since some browsers don't support it.
      var data = atob(url.split(',')[1]);
      var dataView = new Uint8Array(data.length);
      for (var i=0; i<data.length; ++i) {
        dataView[i] = data.charCodeAt(i);
      }

      decodeAudioData(dataView.buffer, self);
    } else {
      // Load the buffer from the URL.
      var xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.withCredentials = self._xhrWithCredentials;
      xhr.responseType = 'arraybuffer';
      xhr.onload = function() {
        // Make sure we get a successful response back.
        var code = (xhr.status + '')[0];
        if (code !== '0' && code !== '2' && code !== '3') {
          self._emit('loaderror', null, 'Failed loading audio file with status: ' + xhr.status + '.');
          return;
        }

        decodeAudioData(xhr.response, self);
      };
      xhr.onerror = function() {
        // If there is an error, switch to HTML5 Audio.
        if (self._webAudio) {
          self._html5 = true;
          self._webAudio = false;
          self._sounds = [];
          delete cache[url];
          self.load();
        }
      };
      safeXhrSend(xhr);
    }
  };

  /**
   * Send the XHR request wrapped in a try/catch.
   * @param  {Object} xhr XHR to send.
   */
  var safeXhrSend = function(xhr) {
    try {
      xhr.send();
    } catch (e) {
      xhr.onerror();
    }
  };

  /**
   * Decode audio data from an array buffer.
   * @param  {ArrayBuffer} arraybuffer The audio data.
   * @param  {Howl}        self
   */
  var decodeAudioData = function(arraybuffer, self) {
    // Decode the buffer into an audio source.
    Howler.ctx.decodeAudioData(arraybuffer, function(buffer) {
      if (buffer && self._sounds.length > 0) {
        cache[self._src] = buffer;
        loadSound(self, buffer);
      }
    }, function() {
      self._emit('loaderror', null, 'Decoding audio data failed.');
    });
  };

  /**
   * Sound is now loaded, so finish setting everything up and fire the loaded event.
   * @param  {Howl} self
   * @param  {Object} buffer The decoded buffer sound source.
   */
  var loadSound = function(self, buffer) {
    // Set the duration.
    if (buffer && !self._duration) {
      self._duration = buffer.duration;
    }

    // Setup a sprite if none is defined.
    if (Object.keys(self._sprite).length === 0) {
      self._sprite = {__default: [0, self._duration * 1000]};
    }

    // Fire the loaded event.
    if (self._state !== 'loaded') {
      self._state = 'loaded';
      self._emit('load');
      self._loadQueue();
    }
  };

  /**
   * Setup the audio context when available, or switch to HTML5 Audio mode.
   */
  var setupAudioContext = function() {
    // Check if we are using Web Audio and setup the AudioContext if we are.
    try {
      if (typeof AudioContext !== 'undefined') {
        Howler.ctx = new AudioContext();
      } else if (typeof webkitAudioContext !== 'undefined') {
        Howler.ctx = new webkitAudioContext();
      } else {
        Howler.usingWebAudio = false;
      }
    } catch(e) {
      Howler.usingWebAudio = false;
    }

    // Check if a webview is being used on iOS8 or earlier (rather than the browser).
    // If it is, disable Web Audio as it causes crashing.
    var iOS = (/iP(hone|od|ad)/.test(Howler._navigator && Howler._navigator.platform));
    var appVersion = Howler._navigator && Howler._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/);
    var version = appVersion ? parseInt(appVersion[1], 10) : null;
    if (iOS && version && version < 9) {
      var safari = /safari/.test(Howler._navigator && Howler._navigator.userAgent.toLowerCase());
      if (Howler._navigator && Howler._navigator.standalone && !safari || Howler._navigator && !Howler._navigator.standalone && !safari) {
        Howler.usingWebAudio = false;
      }
    }

    // Create and expose the master GainNode when using Web Audio (useful for plugins or advanced usage).
    if (Howler.usingWebAudio) {
      Howler.masterGain = (typeof Howler.ctx.createGain === 'undefined') ? Howler.ctx.createGainNode() : Howler.ctx.createGain();
      Howler.masterGain.gain.setValueAtTime(Howler._muted ? 0 : 1, Howler.ctx.currentTime);
      Howler.masterGain.connect(Howler.ctx.destination);
    }

    // Re-run the setup on Howler.
    Howler._setup();
  };

  // Add support for AMD (Asynchronous Module Definition) libraries such as require.js.
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function() {
      return {
        Howler: Howler,
        Howl: Howl
      };
    }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  }

  // Add support for CommonJS libraries such as browserify.
  if (true) {
    exports.Howler = Howler;
    exports.Howl = Howl;
  }

  // Define globally in case AMD is not available or unused.
  if (typeof window !== 'undefined') {
    window.HowlerGlobal = HowlerGlobal;
    window.Howler = Howler;
    window.Howl = Howl;
    window.Sound = Sound;
  } else if (typeof global !== 'undefined') { // Add to global in Node.js (for testing, etc).
    global.HowlerGlobal = HowlerGlobal;
    global.Howler = Howler;
    global.Howl = Howl;
    global.Sound = Sound;
  }
})();


/*!
 *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
 *  
 *  howler.js v2.0.7
 *  howlerjs.com
 *
 *  (c) 2013-2017, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */

(function() {

  'use strict';

  // Setup default properties.
  HowlerGlobal.prototype._pos = [0, 0, 0];
  HowlerGlobal.prototype._orientation = [0, 0, -1, 0, 1, 0];
  
  /** Global Methods **/
  /***************************************************************************/

  /**
   * Helper method to update the stereo panning position of all current Howls.
   * Future Howls will not use this value unless explicitly set.
   * @param  {Number} pan A value of -1.0 is all the way left and 1.0 is all the way right.
   * @return {Howler/Number}     Self or current stereo panning value.
   */
  HowlerGlobal.prototype.stereo = function(pan) {
    var self = this;

    // Stop right here if not using Web Audio.
    if (!self.ctx || !self.ctx.listener) {
      return self;
    }

    // Loop through all Howls and update their stereo panning.
    for (var i=self._howls.length-1; i>=0; i--) {
      self._howls[i].stereo(pan);
    }

    return self;
  };

  /**
   * Get/set the position of the listener in 3D cartesian space. Sounds using
   * 3D position will be relative to the listener's position.
   * @param  {Number} x The x-position of the listener.
   * @param  {Number} y The y-position of the listener.
   * @param  {Number} z The z-position of the listener.
   * @return {Howler/Array}   Self or current listener position.
   */
  HowlerGlobal.prototype.pos = function(x, y, z) {
    var self = this;

    // Stop right here if not using Web Audio.
    if (!self.ctx || !self.ctx.listener) {
      return self;
    }

    // Set the defaults for optional 'y' & 'z'.
    y = (typeof y !== 'number') ? self._pos[1] : y;
    z = (typeof z !== 'number') ? self._pos[2] : z;

    if (typeof x === 'number') {
      self._pos = [x, y, z];
      self.ctx.listener.setPosition(self._pos[0], self._pos[1], self._pos[2]);
    } else {
      return self._pos;
    }

    return self;
  };

  /**
   * Get/set the direction the listener is pointing in the 3D cartesian space.
   * A front and up vector must be provided. The front is the direction the
   * face of the listener is pointing, and up is the direction the top of the
   * listener is pointing. Thus, these values are expected to be at right angles
   * from each other.
   * @param  {Number} x   The x-orientation of the listener.
   * @param  {Number} y   The y-orientation of the listener.
   * @param  {Number} z   The z-orientation of the listener.
   * @param  {Number} xUp The x-orientation of the top of the listener.
   * @param  {Number} yUp The y-orientation of the top of the listener.
   * @param  {Number} zUp The z-orientation of the top of the listener.
   * @return {Howler/Array}     Returns self or the current orientation vectors.
   */
  HowlerGlobal.prototype.orientation = function(x, y, z, xUp, yUp, zUp) {
    var self = this;

    // Stop right here if not using Web Audio.
    if (!self.ctx || !self.ctx.listener) {
      return self;
    }

    // Set the defaults for optional 'y' & 'z'.
    var or = self._orientation;
    y = (typeof y !== 'number') ? or[1] : y;
    z = (typeof z !== 'number') ? or[2] : z;
    xUp = (typeof xUp !== 'number') ? or[3] : xUp;
    yUp = (typeof yUp !== 'number') ? or[4] : yUp;
    zUp = (typeof zUp !== 'number') ? or[5] : zUp;

    if (typeof x === 'number') {
      self._orientation = [x, y, z, xUp, yUp, zUp];
      self.ctx.listener.setOrientation(x, y, z, xUp, yUp, zUp);
    } else {
      return or;
    }

    return self;
  };

  /** Group Methods **/
  /***************************************************************************/

  /**
   * Add new properties to the core init.
   * @param  {Function} _super Core init method.
   * @return {Howl}
   */
  Howl.prototype.init = (function(_super) {
    return function(o) {
      var self = this;

      // Setup user-defined default properties.
      self._orientation = o.orientation || [1, 0, 0];
      self._stereo = o.stereo || null;
      self._pos = o.pos || null;
      self._pannerAttr = {
        coneInnerAngle: typeof o.coneInnerAngle !== 'undefined' ? o.coneInnerAngle : 360,
        coneOuterAngle: typeof o.coneOuterAngle !== 'undefined' ? o.coneOuterAngle : 360,
        coneOuterGain: typeof o.coneOuterGain !== 'undefined' ? o.coneOuterGain : 0,
        distanceModel: typeof o.distanceModel !== 'undefined' ? o.distanceModel : 'inverse',
        maxDistance: typeof o.maxDistance !== 'undefined' ? o.maxDistance : 10000,
        panningModel: typeof o.panningModel !== 'undefined' ? o.panningModel : 'HRTF',
        refDistance: typeof o.refDistance !== 'undefined' ? o.refDistance : 1,
        rolloffFactor: typeof o.rolloffFactor !== 'undefined' ? o.rolloffFactor : 1
      };

      // Setup event listeners.
      self._onstereo = o.onstereo ? [{fn: o.onstereo}] : [];
      self._onpos = o.onpos ? [{fn: o.onpos}] : [];
      self._onorientation = o.onorientation ? [{fn: o.onorientation}] : [];

      // Complete initilization with howler.js core's init function.
      return _super.call(this, o);
    };
  })(Howl.prototype.init);

  /**
   * Get/set the stereo panning of the audio source for this sound or all in the group.
   * @param  {Number} pan  A value of -1.0 is all the way left and 1.0 is all the way right.
   * @param  {Number} id (optional) The sound ID. If none is passed, all in group will be updated.
   * @return {Howl/Number}    Returns self or the current stereo panning value.
   */
  Howl.prototype.stereo = function(pan, id) {
    var self = this;

    // Stop right here if not using Web Audio.
    if (!self._webAudio) {
      return self;
    }

    // If the sound hasn't loaded, add it to the load queue to change stereo pan when capable.
    if (self._state !== 'loaded') {
      self._queue.push({
        event: 'stereo',
        action: function() {
          self.stereo(pan, id);
        }
      });

      return self;
    }

    // Check for PannerStereoNode support and fallback to PannerNode if it doesn't exist.
    var pannerType = (typeof Howler.ctx.createStereoPanner === 'undefined') ? 'spatial' : 'stereo';

    // Setup the group's stereo panning if no ID is passed.
    if (typeof id === 'undefined') {
      // Return the group's stereo panning if no parameters are passed.
      if (typeof pan === 'number') {
        self._stereo = pan;
        self._pos = [pan, 0, 0];
      } else {
        return self._stereo;
      }
    }

    // Change the streo panning of one or all sounds in group.
    var ids = self._getSoundIds(id);
    for (var i=0; i<ids.length; i++) {
      // Get the sound.
      var sound = self._soundById(ids[i]);

      if (sound) {
        if (typeof pan === 'number') {
          sound._stereo = pan;
          sound._pos = [pan, 0, 0];

          if (sound._node) {
            // If we are falling back, make sure the panningModel is equalpower.
            sound._pannerAttr.panningModel = 'equalpower';

            // Check if there is a panner setup and create a new one if not.
            if (!sound._panner || !sound._panner.pan) {
              setupPanner(sound, pannerType);
            }

            if (pannerType === 'spatial') {
              sound._panner.setPosition(pan, 0, 0);
            } else {
              sound._panner.pan.setValueAtTime(pan, Howler.ctx.currentTime);
            }
          }

          self._emit('stereo', sound._id);
        } else {
          return sound._stereo;
        }
      }
    }

    return self;
  };

  /**
   * Get/set the 3D spatial position of the audio source for this sound or group relative to the global listener.
   * @param  {Number} x  The x-position of the audio source.
   * @param  {Number} y  The y-position of the audio source.
   * @param  {Number} z  The z-position of the audio source.
   * @param  {Number} id (optional) The sound ID. If none is passed, all in group will be updated.
   * @return {Howl/Array}    Returns self or the current 3D spatial position: [x, y, z].
   */
  Howl.prototype.pos = function(x, y, z, id) {
    var self = this;

    // Stop right here if not using Web Audio.
    if (!self._webAudio) {
      return self;
    }

    // If the sound hasn't loaded, add it to the load queue to change position when capable.
    if (self._state !== 'loaded') {
      self._queue.push({
        event: 'pos',
        action: function() {
          self.pos(x, y, z, id);
        }
      });

      return self;
    }

    // Set the defaults for optional 'y' & 'z'.
    y = (typeof y !== 'number') ? 0 : y;
    z = (typeof z !== 'number') ? -0.5 : z;

    // Setup the group's spatial position if no ID is passed.
    if (typeof id === 'undefined') {
      // Return the group's spatial position if no parameters are passed.
      if (typeof x === 'number') {
        self._pos = [x, y, z];
      } else {
        return self._pos;
      }
    }

    // Change the spatial position of one or all sounds in group.
    var ids = self._getSoundIds(id);
    for (var i=0; i<ids.length; i++) {
      // Get the sound.
      var sound = self._soundById(ids[i]);

      if (sound) {
        if (typeof x === 'number') {
          sound._pos = [x, y, z];

          if (sound._node) {
            // Check if there is a panner setup and create a new one if not.
            if (!sound._panner || sound._panner.pan) {
              setupPanner(sound, 'spatial');
            }

            sound._panner.setPosition(x, y, z);
          }

          self._emit('pos', sound._id);
        } else {
          return sound._pos;
        }
      }
    }

    return self;
  };

  /**
   * Get/set the direction the audio source is pointing in the 3D cartesian coordinate
   * space. Depending on how direction the sound is, based on the `cone` attributes,
   * a sound pointing away from the listener can be quiet or silent.
   * @param  {Number} x  The x-orientation of the source.
   * @param  {Number} y  The y-orientation of the source.
   * @param  {Number} z  The z-orientation of the source.
   * @param  {Number} id (optional) The sound ID. If none is passed, all in group will be updated.
   * @return {Howl/Array}    Returns self or the current 3D spatial orientation: [x, y, z].
   */
  Howl.prototype.orientation = function(x, y, z, id) {
    var self = this;

    // Stop right here if not using Web Audio.
    if (!self._webAudio) {
      return self;
    }

    // If the sound hasn't loaded, add it to the load queue to change orientation when capable.
    if (self._state !== 'loaded') {
      self._queue.push({
        event: 'orientation',
        action: function() {
          self.orientation(x, y, z, id);
        }
      });

      return self;
    }

    // Set the defaults for optional 'y' & 'z'.
    y = (typeof y !== 'number') ? self._orientation[1] : y;
    z = (typeof z !== 'number') ? self._orientation[2] : z;

    // Setup the group's spatial orientation if no ID is passed.
    if (typeof id === 'undefined') {
      // Return the group's spatial orientation if no parameters are passed.
      if (typeof x === 'number') {
        self._orientation = [x, y, z];
      } else {
        return self._orientation;
      }
    }

    // Change the spatial orientation of one or all sounds in group.
    var ids = self._getSoundIds(id);
    for (var i=0; i<ids.length; i++) {
      // Get the sound.
      var sound = self._soundById(ids[i]);

      if (sound) {
        if (typeof x === 'number') {
          sound._orientation = [x, y, z];

          if (sound._node) {
            // Check if there is a panner setup and create a new one if not.
            if (!sound._panner) {
              // Make sure we have a position to setup the node with.
              if (!sound._pos) {
                sound._pos = self._pos || [0, 0, -0.5];
              }

              setupPanner(sound, 'spatial');
            }

            sound._panner.setOrientation(x, y, z);
          }

          self._emit('orientation', sound._id);
        } else {
          return sound._orientation;
        }
      }
    }

    return self;
  };

  /**
   * Get/set the panner node's attributes for a sound or group of sounds.
   * This method can optionall take 0, 1 or 2 arguments.
   *   pannerAttr() -> Returns the group's values.
   *   pannerAttr(id) -> Returns the sound id's values.
   *   pannerAttr(o) -> Set's the values of all sounds in this Howl group.
   *   pannerAttr(o, id) -> Set's the values of passed sound id.
   *
   *   Attributes:
   *     coneInnerAngle - (360 by default) A parameter for directional audio sources, this is an angle, in degrees,
   *                      inside of which there will be no volume reduction.
   *     coneOuterAngle - (360 by default) A parameter for directional audio sources, this is an angle, in degrees,
   *                      outside of which the volume will be reduced to a constant value of `coneOuterGain`.
   *     coneOuterGain - (0 by default) A parameter for directional audio sources, this is the gain outside of the
   *                     `coneOuterAngle`. It is a linear value in the range `[0, 1]`.
   *     distanceModel - ('inverse' by default) Determines algorithm used to reduce volume as audio moves away from
   *                     listener. Can be `linear`, `inverse` or `exponential.
   *     maxDistance - (10000 by default) The maximum distance between source and listener, after which the volume
   *                   will not be reduced any further.
   *     refDistance - (1 by default) A reference distance for reducing volume as source moves further from the listener.
   *                   This is simply a variable of the distance model and has a different effect depending on which model
   *                   is used and the scale of your coordinates. Generally, volume will be equal to 1 at this distance.
   *     rolloffFactor - (1 by default) How quickly the volume reduces as source moves from listener. This is simply a
   *                     variable of the distance model and can be in the range of `[0, 1]` with `linear` and `[0, ∞]`
   *                     with `inverse` and `exponential`.
   *     panningModel - ('HRTF' by default) Determines which spatialization algorithm is used to position audio.
   *                     Can be `HRTF` or `equalpower`.
   * 
   * @return {Howl/Object} Returns self or current panner attributes.
   */
  Howl.prototype.pannerAttr = function() {
    var self = this;
    var args = arguments;
    var o, id, sound;

    // Stop right here if not using Web Audio.
    if (!self._webAudio) {
      return self;
    }

    // Determine the values based on arguments.
    if (args.length === 0) {
      // Return the group's panner attribute values.
      return self._pannerAttr;
    } else if (args.length === 1) {
      if (typeof args[0] === 'object') {
        o = args[0];

        // Set the grou's panner attribute values.
        if (typeof id === 'undefined') {
          if (!o.pannerAttr) {
            o.pannerAttr = {
              coneInnerAngle: o.coneInnerAngle,
              coneOuterAngle: o.coneOuterAngle,
              coneOuterGain: o.coneOuterGain,
              distanceModel: o.distanceModel,
              maxDistance: o.maxDistance,
              refDistance: o.refDistance,
              rolloffFactor: o.rolloffFactor,
              panningModel: o.panningModel
            };
          }

          self._pannerAttr = {
            coneInnerAngle: typeof o.pannerAttr.coneInnerAngle !== 'undefined' ? o.pannerAttr.coneInnerAngle : self._coneInnerAngle,
            coneOuterAngle: typeof o.pannerAttr.coneOuterAngle !== 'undefined' ? o.pannerAttr.coneOuterAngle : self._coneOuterAngle,
            coneOuterGain: typeof o.pannerAttr.coneOuterGain !== 'undefined' ? o.pannerAttr.coneOuterGain : self._coneOuterGain,
            distanceModel: typeof o.pannerAttr.distanceModel !== 'undefined' ? o.pannerAttr.distanceModel : self._distanceModel,
            maxDistance: typeof o.pannerAttr.maxDistance !== 'undefined' ? o.pannerAttr.maxDistance : self._maxDistance,
            refDistance: typeof o.pannerAttr.refDistance !== 'undefined' ? o.pannerAttr.refDistance : self._refDistance,
            rolloffFactor: typeof o.pannerAttr.rolloffFactor !== 'undefined' ? o.pannerAttr.rolloffFactor : self._rolloffFactor,
            panningModel: typeof o.pannerAttr.panningModel !== 'undefined' ? o.pannerAttr.panningModel : self._panningModel
          };
        }
      } else {
        // Return this sound's panner attribute values.
        sound = self._soundById(parseInt(args[0], 10));
        return sound ? sound._pannerAttr : self._pannerAttr;
      }
    } else if (args.length === 2) {
      o = args[0];
      id = parseInt(args[1], 10);
    }

    // Update the values of the specified sounds.
    var ids = self._getSoundIds(id);
    for (var i=0; i<ids.length; i++) {
      sound = self._soundById(ids[i]);

      if (sound) {
        // Merge the new values into the sound.
        var pa = sound._pannerAttr;
        pa = {
          coneInnerAngle: typeof o.coneInnerAngle !== 'undefined' ? o.coneInnerAngle : pa.coneInnerAngle,
          coneOuterAngle: typeof o.coneOuterAngle !== 'undefined' ? o.coneOuterAngle : pa.coneOuterAngle,
          coneOuterGain: typeof o.coneOuterGain !== 'undefined' ? o.coneOuterGain : pa.coneOuterGain,
          distanceModel: typeof o.distanceModel !== 'undefined' ? o.distanceModel : pa.distanceModel,
          maxDistance: typeof o.maxDistance !== 'undefined' ? o.maxDistance : pa.maxDistance,
          refDistance: typeof o.refDistance !== 'undefined' ? o.refDistance : pa.refDistance,
          rolloffFactor: typeof o.rolloffFactor !== 'undefined' ? o.rolloffFactor : pa.rolloffFactor,
          panningModel: typeof o.panningModel !== 'undefined' ? o.panningModel : pa.panningModel
        };

        // Update the panner values or create a new panner if none exists.
        var panner = sound._panner;
        if (panner) {
          panner.coneInnerAngle = pa.coneInnerAngle;
          panner.coneOuterAngle = pa.coneOuterAngle;
          panner.coneOuterGain = pa.coneOuterGain;
          panner.distanceModel = pa.distanceModel;
          panner.maxDistance = pa.maxDistance;
          panner.refDistance = pa.refDistance;
          panner.rolloffFactor = pa.rolloffFactor;
          panner.panningModel = pa.panningModel;
        } else {
          // Make sure we have a position to setup the node with.
          if (!sound._pos) {
            sound._pos = self._pos || [0, 0, -0.5];
          }

          // Create a new panner node.
          setupPanner(sound, 'spatial');
        }
      }
    }

    return self;
  };

  /** Single Sound Methods **/
  /***************************************************************************/

  /**
   * Add new properties to the core Sound init.
   * @param  {Function} _super Core Sound init method.
   * @return {Sound}
   */
  Sound.prototype.init = (function(_super) {
    return function() {
      var self = this;
      var parent = self._parent;

      // Setup user-defined default properties.
      self._orientation = parent._orientation;
      self._stereo = parent._stereo;
      self._pos = parent._pos;
      self._pannerAttr = parent._pannerAttr;

      // Complete initilization with howler.js core Sound's init function.
      _super.call(this);

      // If a stereo or position was specified, set it up.
      if (self._stereo) {
        parent.stereo(self._stereo);
      } else if (self._pos) {
        parent.pos(self._pos[0], self._pos[1], self._pos[2], self._id);
      }
    };
  })(Sound.prototype.init);

  /**
   * Override the Sound.reset method to clean up properties from the spatial plugin.
   * @param  {Function} _super Sound reset method.
   * @return {Sound}
   */
  Sound.prototype.reset = (function(_super) {
    return function() {
      var self = this;
      var parent = self._parent;

      // Reset all spatial plugin properties on this sound.
      self._orientation = parent._orientation;
      self._pos = parent._pos;
      self._pannerAttr = parent._pannerAttr;

      // Complete resetting of the sound.
      return _super.call(this);
    };
  })(Sound.prototype.reset);

  /** Helper Methods **/
  /***************************************************************************/

  /**
   * Create a new panner node and save it on the sound.
   * @param  {Sound} sound Specific sound to setup panning on.
   * @param {String} type Type of panner to create: 'stereo' or 'spatial'.
   */
  var setupPanner = function(sound, type) {
    type = type || 'spatial';

    // Create the new panner node.
    if (type === 'spatial') {
      sound._panner = Howler.ctx.createPanner();
      sound._panner.coneInnerAngle = sound._pannerAttr.coneInnerAngle;
      sound._panner.coneOuterAngle = sound._pannerAttr.coneOuterAngle;
      sound._panner.coneOuterGain = sound._pannerAttr.coneOuterGain;
      sound._panner.distanceModel = sound._pannerAttr.distanceModel;
      sound._panner.maxDistance = sound._pannerAttr.maxDistance;
      sound._panner.refDistance = sound._pannerAttr.refDistance;
      sound._panner.rolloffFactor = sound._pannerAttr.rolloffFactor;
      sound._panner.panningModel = sound._pannerAttr.panningModel;
      sound._panner.setPosition(sound._pos[0], sound._pos[1], sound._pos[2]);
      sound._panner.setOrientation(sound._orientation[0], sound._orientation[1], sound._orientation[2]);
    } else {
      sound._panner = Howler.ctx.createStereoPanner();
      sound._panner.pan.setValueAtTime(sound._stereo, Howler.ctx.currentTime);
    }

    sound._panner.connect(sound._node);

    // Update the connections.
    if (!sound._paused) {
      sound._parent.pause(sound._id, true).play(sound._id);
    }
  };
})();

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 352 */
/***/ (function(module, exports) {

/**
 * Expose `PriorityQueue`.
 */
module.exports = PriorityQueue;

/**
 * Initializes a new empty `PriorityQueue` with the given `comparator(a, b)`
 * function, uses `.DEFAULT_COMPARATOR()` when no function is provided.
 *
 * The comparator function must return a positive number when `a > b`, 0 when
 * `a == b` and a negative number when `a < b`.
 *
 * @param {Function}
 * @return {PriorityQueue}
 * @api public
 */
function PriorityQueue(comparator) {
  this._comparator = comparator || PriorityQueue.DEFAULT_COMPARATOR;
  this._elements = [];
}

/**
 * Compares `a` and `b`, when `a > b` it returns a positive number, when
 * it returns 0 and when `a < b` it returns a negative number.
 *
 * @param {String|Number} a
 * @param {String|Number} b
 * @return {Number}
 * @api public
 */
PriorityQueue.DEFAULT_COMPARATOR = function(a, b) {
  if (typeof a === 'number' && typeof b === 'number') {
    return a - b;
  } else {
    a = a.toString();
    b = b.toString();

    if (a == b) return 0;

    return (a > b) ? 1 : -1;
  }
};

/**
 * Returns whether the priority queue is empty or not.
 *
 * @return {Boolean}
 * @api public
 */
PriorityQueue.prototype.isEmpty = function() {
  return this.size() === 0;
};

/**
 * Peeks at the top element of the priority queue.
 *
 * @return {Object}
 * @throws {Error} when the queue is empty.
 * @api public
 */
PriorityQueue.prototype.peek = function() {
  if (this.isEmpty()) throw new Error('PriorityQueue is empty');

  return this._elements[0];
};

/**
 * Dequeues the top element of the priority queue.
 *
 * @return {Object}
 * @throws {Error} when the queue is empty.
 * @api public
 */
PriorityQueue.prototype.deq = function() {
  var first = this.peek();
  var last = this._elements.pop();
  var size = this.size();

  if (size === 0) return first;

  this._elements[0] = last;
  var current = 0;

  while (current < size) {
    var largest = current;
    var left = (2 * current) + 1;
    var right = (2 * current) + 2;

    if (left < size && this._compare(left, largest) >= 0) {
      largest = left;
    }

    if (right < size && this._compare(right, largest) >= 0) {
      largest = right;
    }

    if (largest === current) break;

    this._swap(largest, current);
    current = largest;
  }

  return first;
};

/**
 * Enqueues the `element` at the priority queue and returns its new size.
 *
 * @param {Object} element
 * @return {Number}
 * @api public
 */
PriorityQueue.prototype.enq = function(element) {
  var size = this._elements.push(element);
  var current = size - 1;

  while (current > 0) {
    var parent = Math.floor((current - 1) / 2);

    if (this._compare(current, parent) <= 0) break;

    this._swap(parent, current);
    current = parent;
  }

  return size;
};

/**
 * Returns the size of the priority queue.
 *
 * @return {Number}
 * @api public
 */
PriorityQueue.prototype.size = function() {
  return this._elements.length;
};

/**
 *  Iterates over queue elements
 *
 *  @param {Function} fn
 */
PriorityQueue.prototype.forEach = function(fn) {
  return this._elements.forEach(fn);
};

/**
 * Compares the values at position `a` and `b` in the priority queue using its
 * comparator function.
 *
 * @param {Number} a
 * @param {Number} b
 * @return {Number}
 * @api private
 */
PriorityQueue.prototype._compare = function(a, b) {
  return this._comparator(this._elements[a], this._elements[b]);
};

/**
 * Swaps the values at position `a` and `b` in the priority queue.
 *
 * @param {Number} a
 * @param {Number} b
 * @api private
 */
PriorityQueue.prototype._swap = function(a, b) {
  var aux = this._elements[a];
  this._elements[a] = this._elements[b];
  this._elements[b] = aux;
};


/***/ }),
/* 353 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scene = __webpack_require__(340);

var _stage = __webpack_require__(375);

var _stage2 = _interopRequireDefault(_stage);

var _testlevel = __webpack_require__(383);

var _testlevel2 = _interopRequireDefault(_testlevel);

var _level = __webpack_require__(384);

var _level2 = _interopRequireDefault(_level);

var _level3 = __webpack_require__(385);

var _level4 = _interopRequireDefault(_level3);

var _level5 = __webpack_require__(386);

var _level6 = _interopRequireDefault(_level5);

var _level7 = __webpack_require__(387);

var _level8 = _interopRequireDefault(_level7);

var _level9 = __webpack_require__(388);

var _level10 = _interopRequireDefault(_level9);

var _level11 = __webpack_require__(389);

var _level12 = _interopRequireDefault(_level11);

var _level13 = __webpack_require__(390);

var _level14 = _interopRequireDefault(_level13);

var _tutorial = __webpack_require__(391);

var _tutorial2 = _interopRequireDefault(_tutorial);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var game = new _scene.Scene();
game.state.currentLevel = 'test';

var getLevel = function getLevel(levelStr) {
  console.log(levelStr);
  switch (levelStr) {
    case 'tutorial':
      return _tutorial2.default;
    case 'level1':
      return _level2.default;
    case 'level2':
      return _level4.default;
    case 'level3':
      return _level6.default;
    case 'level4':
      return _level8.default;
    case 'level5':
      return _level10.default;
    case 'level6':
      return _level12.default;
    case 'level7':
      return _level14.default;
    default:
      alert('Level Not Loaded');
      return _testlevel2.default;
  }
};

var currentStage = new _stage2.default({
  level: _testlevel2.default,
  onMount: function onMount(_) {}
});

game.onEnter = function (_) {
  console.log('currentStage');
  console.log(currentStage);
  currentStage.start(game);
  currentStage.loadLevel(getLevel(game.state.currentLevel));
};

currentStage.start(game);
exports.default = game;

/***/ }),
/* 354 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NavPoint = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

var _priorityqueuejs = __webpack_require__(352);

var _priorityqueuejs2 = _interopRequireDefault(_priorityqueuejs);

var _utils = __webpack_require__(347);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var NavPoint = exports.NavPoint = function () {
  function NavPoint() {
    var pos = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : (0, _math.pt)(0, 0);

    _classCallCheck(this, NavPoint);

    this.position = pos;
    this.neighbors = [];
    this.label = -1;
  }

  _createClass(NavPoint, [{
    key: 'addNeighbors',
    value: function addNeighbors() {
      for (var _len = arguments.length, neighbors = Array(_len), _key = 0; _key < _len; _key++) {
        neighbors[_key] = arguments[_key];
      }

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = neighbors[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var neighbor = _step.value;

          var n = { cost: (0, _math.distance)(this.position, neighbor.position), point: neighbor };
          this.neighbors.push(n);
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    }
  }]);

  return NavPoint;
}();

var NavMesh = function () {
  function NavMesh() {
    var points = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

    _classCallCheck(this, NavMesh);

    this.points = [];
    this.addPoints.apply(this, _toConsumableArray(points));
    this.newPQ();
    this.search = (0, _utils.memoize)(this.search, function (src, dest) {
      return src.label + '_' + dest.label;
    });
    this.size = 0;
  }

  _createClass(NavMesh, [{
    key: 'newPQ',
    value: function newPQ() {
      this.pq = new _priorityqueuejs2.default(function (a, b) {
        return -(a.cost - b.cost);
      });
    }
  }, {
    key: 'addPoints',
    value: function addPoints() {
      for (var _len2 = arguments.length, points = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        points[_key2] = arguments[_key2];
      }

      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = points[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var point = _step2.value;

          point.label = this.size++;
          this.points.push(point);
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }
    }
  }, {
    key: 'search',
    value: function search(source, target) {
      if (!source || !target) return [];
      var frontier = new _priorityqueuejs2.default(function (a, b) {
        return -(a.cost - b.cost);
      });
      // List of cost. Also used for the closed set
      var costSet = {};
      costSet[source.label] = 0;
      frontier.enq({ cost: 0, point: source, parent: null });
      while (!frontier.isEmpty()) {
        var current = frontier.deq();
        if (current.point === target) {
          var returnList = [current];
          for (var node = current.parent; node !== null; node = node.parent) {
            returnList.unshift(node);
          }
          return returnList;
        }
        var _iteratorNormalCompletion3 = true;
        var _didIteratorError3 = false;
        var _iteratorError3 = undefined;

        try {
          for (var _iterator3 = current.point.neighbors[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
            var next = _step3.value;

            var newCost = costSet[current.point.label] + next.cost;
            if (!(next.point.label in costSet) || newCost < costSet[next.point.label]) {
              costSet[next.point.label] = newCost;
              frontier.enq({
                cost: newCost + (0, _math.distance)(target.position, next.point.position),
                point: next.point,
                parent: current
              });
            }
          }
        } catch (err) {
          _didIteratorError3 = true;
          _iteratorError3 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion3 && _iterator3.return) {
              _iterator3.return();
            }
          } finally {
            if (_didIteratorError3) {
              throw _iteratorError3;
            }
          }
        }
      }
      return [];
    }
  }, {
    key: 'computeNavmeshNeighbors',
    value: function computeNavmeshNeighbors(geometry) {
      for (var i = this.points.length - 1; i >= 0; i--) {
        var nav = this.points[i];
        var circle = new _math.Circle(nav.position, 30);
        var _iteratorNormalCompletion4 = true;
        var _didIteratorError4 = false;
        var _iteratorError4 = undefined;

        try {
          for (var _iterator4 = geometry[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
            var geom = _step4.value;

            if (circle.intersectsPoly(geom.polygon)) {
              this.points.splice(i, 1);
              break;
            }
          }
        } catch (err) {
          _didIteratorError4 = true;
          _iteratorError4 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion4 && _iterator4.return) {
              _iterator4.return();
            }
          } finally {
            if (_didIteratorError4) {
              throw _iteratorError4;
            }
          }
        }
      }

      var _iteratorNormalCompletion5 = true;
      var _didIteratorError5 = false;
      var _iteratorError5 = undefined;

      try {
        for (var _iterator5 = this.points[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
          var _nav = _step5.value;
          var _iteratorNormalCompletion6 = true;
          var _didIteratorError6 = false;
          var _iteratorError6 = undefined;

          try {
            for (var _iterator6 = this.points[Symbol.iterator](), _step6; !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
              var nextNav = _step6.value;

              if (_nav === nextNav) continue;
              var seg = new _math.Segment(_nav.position, nextNav.position);
              var inter = null;
              var _iteratorNormalCompletion7 = true;
              var _didIteratorError7 = false;
              var _iteratorError7 = undefined;

              try {
                for (var _iterator7 = geometry[Symbol.iterator](), _step7; !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
                  var _geom = _step7.value;

                  inter = _geom.polygon.intersectsSegment(seg);
                  if (inter) break;
                }
              } catch (err) {
                _didIteratorError7 = true;
                _iteratorError7 = err;
              } finally {
                try {
                  if (!_iteratorNormalCompletion7 && _iterator7.return) {
                    _iterator7.return();
                  }
                } finally {
                  if (_didIteratorError7) {
                    throw _iteratorError7;
                  }
                }
              }

              if (!inter) {
                _nav.addNeighbors(nextNav);
              }
            }
          } catch (err) {
            _didIteratorError6 = true;
            _iteratorError6 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion6 && _iterator6.return) {
                _iterator6.return();
              }
            } finally {
              if (_didIteratorError6) {
                throw _iteratorError6;
              }
            }
          }

          _nav.neighbors.sort(function (a, b) {
            return a.cost - b.cost;
          });
          _nav.neighbors.splice(8, 20);
        }
      } catch (err) {
        _didIteratorError5 = true;
        _iteratorError5 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion5 && _iterator5.return) {
            _iterator5.return();
          }
        } finally {
          if (_didIteratorError5) {
            throw _iteratorError5;
          }
        }
      }

      console.log('navmeshComplete');
      console.log(this.points);
    }
  }, {
    key: 'getNearestPoint',
    value: function getNearestPoint(pt) {
      var nearest = Infinity;
      var nearestIndex = -1;
      for (var i = 0, size = this.points.length; i < size; i++) {
        var np = this.points[i].position;
        var dist = (np.x - pt.x) * (np.x - pt.x) + (np.y - pt.y) * (np.y - pt.y);
        if (dist < nearest) {
          nearest = dist;
          nearestIndex = i;
        }
      }
      return this.points[nearestIndex];
    }
  }]);

  return NavMesh;
}();

exports.default = NavMesh;

/***/ }),
/* 355 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BasicEnemy = exports.Mob = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

var _geometry = __webpack_require__(356);

var _ai = __webpack_require__(381);

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Mob = exports.Mob = function () {
  function Mob(circle, update) {
    _classCallCheck(this, Mob);

    this.type = 'Mob';

    this.position = circle.position;
    this.collider = circle;
    if (update) {
      this.update = update;
    }
  }

  _createClass(Mob, [{
    key: 'render',
    value: function render(c, camera, _e) {
      c.fillStyle = '#f22';
      c.beginPath();
      c.arc(this.position.x + camera.position.x, this.position.y + camera.position.y, this.collider.radius, 0, Math.PI * 2);
      c.fill();
    }
  }, {
    key: '_translate',
    value: function _translate(x, y) {
      this.collider.translate(x, y);
      this.position.x += x;
      this.position.y += y;
    }
  }, {
    key: 'translate',
    value: function translate(x, y, camera, e) {
      var mobs = camera.mobs,
          geometry = camera.geometry,
          projectiles = camera.projectiles;

      this._translate(x, y);
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = mobs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var inter = _step.value;

          if (inter !== this && this.collider.intersectsCircle(inter.collider)) {
            this._translate(-x, -y);
            return inter;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = geometry[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var geom = _step2.value;

          if (this.collider.intersectsPoly(geom.polygon) && !geom.noclip) {
            this._translate(-x, -y);
            return geom;
          }
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }

      var _iteratorNormalCompletion3 = true;
      var _didIteratorError3 = false;
      var _iteratorError3 = undefined;

      try {
        for (var _iterator3 = projectiles[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
          var projectile = _step3.value;

          if (this.collider.intersectsCircle(projectile.collider)) {
            projectile.onCollide(this, camera, e);
          }
        }
      } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion3 && _iterator3.return) {
            _iterator3.return();
          }
        } finally {
          if (_didIteratorError3) {
            throw _iteratorError3;
          }
        }
      }

      return null;
    }
  }]);

  return Mob;
}();

var BasicEnemy = exports.BasicEnemy = function (_Mob) {
  _inherits(BasicEnemy, _Mob);

  function BasicEnemy(x, y) {
    var spawnTime = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
    var round = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;

    _classCallCheck(this, BasicEnemy);

    var _this = _possibleConstructorReturn(this, (BasicEnemy.__proto__ || Object.getPrototypeOf(BasicEnemy)).call(this, new _math.Circle((0, _math.pt)(x, y), 20)));

    _this.type = 'BasicEnemy';

    _this.spawnTime = spawnTime;
    _this.targetVector = null;
    _this.round = round;
    _this.path = null;
    _this.speed = 3;
    _this.lastCollision = 0;
    return _this;
  }

  _createClass(BasicEnemy, [{
    key: 'setPath',
    value: function setPath(src, dest, camera) {
      var nearestPt = camera.navMesh.getNearestPoint(src);
      var nearestDestPt = camera.navMesh.getNearestPoint(dest);
      this.path = camera.navMesh.search(nearestPt, nearestDestPt).slice();
      this.path.push({ point: { position: dest } });
      // console.log(this.path)
      // if (!this.path || this.path.age > 5) {
      //   this.path = camera.navMesh.search(src, dest)
      //   if (this.path.length === 0) {
      //     console.log('This one is stuck', this)
      //   }
      //   if (this.path) {
      //     this.path.age = 0
      //   }
      // } else {
      //
      // }
    }
  }, {
    key: 'update',
    value: function update(mob, e, camera, d, stage) {
      // Get path from me to player. If player is ded, some random path.
      this.setPath(this.position, stage.player.alive ? stage.player.position : camera.navMesh.points[0].position, camera);
      if (this.lastCollision) {
        this.lastCollision++;
      }
      // Figure out the next point on the path
      var nextPt = null;
      if (this.path.length > 1) {
        var firstPoint = this.path[0].point.position;
        var secondPoint = this.path[1].point.position;
        var seg = new _math.Segment(firstPoint, secondPoint);

        // Get rid of first point if the second is closer
        if ((0, _math.distance)(firstPoint, this.position) < 10 || (0, _math.distance)(firstPoint, secondPoint) > (0, _math.distance)(this.position, secondPoint) && !(0, _geometry.segmentIntersectsGeometry)(seg, camera.geometry)) {
          this.path.splice(0, 1);
          firstPoint = this.path[0].point.position;
          if (this.path.length > 1) {
            secondPoint = this.path[1].point.position;
          }
        }

        if (this.path.length > 1 && (0, _math.distance)(firstPoint, this.position) > (0, _math.distance)(secondPoint, this.position) && this.lastCollision < 15) {
          nextPt = this.path[1].point;
        } else {
          nextPt = this.path[0].point;
        }
      } else {
        nextPt = this.path[0].point;
      }
      var coords = (0, _ai.moveTo)(this, nextPt.position);
      this.targetVector = coords;
      var cantMove = this.translate(coords.x * d * this.speed, coords.y * d * this.speed, camera, e);
      if (cantMove) {
        this.lastCollision = 0;
        var nearestPt = camera.navMesh.getNearestPoint(this.position);
        var _coords = (0, _ai.moveTo)(this, nearestPt.position);
        this.targetVector = _coords;
        this.translate(_coords.x * d * this.speed, _coords.y * d * this.speed, camera, e);
      }
    }
  }, {
    key: 'render',
    value: function render(c, camera, e) {
      // Draw player image
      var images = e.state.imageLoader.images;
      var x = this.collider.position.x + camera.position.x;
      var y = this.collider.position.y + camera.position.y;
      var width = this.collider.radius * 2;
      var height = this.collider.radius * 2;
      var direction = this.targetVector || (0, _math.pt)(0, 1);
      var degToLook = -Math.atan2(direction.x, direction.y);
      c.save();
      c.translate(x, y);
      c.rotate(degToLook);
      x = 0;
      y = 0;
      c.drawImage(images['basicEnemy'], x - width / 2, y - height / 2, width, height);
      c.restore();

      // Draw hitbox
      if (!global.debug) return;
      c.fillStyle = '#22f';
      c.beginPath();
      c.arc(this.collider.position.x + camera.position.x, this.collider.position.y + camera.position.y, this.collider.radius, 0, Math.PI * 2);
      c.fill();
      if (this.active) {
        c.fillStyle = '#f22';
        c.beginPath();
        c.arc(this.collider.position.x + camera.position.x, this.collider.position.y + camera.position.y, this.collider.radius / 2, 0, Math.PI * 2);
        c.fill();
      }
    }
  }, {
    key: 'translate',
    value: function translate(x, y, camera, e) {
      var mobs = camera.mobs,
          geometry = camera.geometry,
          projectiles = camera.projectiles;

      this._translate(x, y);
      var secondTranlate = (0, _math.pt)(0, 0);
      var _iteratorNormalCompletion4 = true;
      var _didIteratorError4 = false;
      var _iteratorError4 = undefined;

      try {
        for (var _iterator4 = mobs[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
          var inter = _step4.value;

          if (inter !== this && this.collider.intersectsCircle(inter.collider) && inter.type === 'Player') {
            this._translate(-x, -y);
            if (!global.godmode) {
              inter.alive = false;
            }
            return inter;
          } else if (inter !== this && this.collider.intersectsCircle(inter.collider) && inter.type !== 'Player') {
            secondTranlate = (0, _math.scalar)((0, _math.unit)((0, _math.sub)(inter.position, this.position)), -2);
            this._translate(secondTranlate.x, secondTranlate.y);
          }
        }
      } catch (err) {
        _didIteratorError4 = true;
        _iteratorError4 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion4 && _iterator4.return) {
            _iterator4.return();
          }
        } finally {
          if (_didIteratorError4) {
            throw _iteratorError4;
          }
        }
      }

      var _iteratorNormalCompletion5 = true;
      var _didIteratorError5 = false;
      var _iteratorError5 = undefined;

      try {
        for (var _iterator5 = geometry[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
          var geom = _step5.value;

          if (this.collider.intersectsPoly(geom.polygon) && !geom.noclip) {
            this._translate(-x, -y);
            this._translate(-secondTranlate.x, -secondTranlate.y);
            return geom;
          }
        }
      } catch (err) {
        _didIteratorError5 = true;
        _iteratorError5 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion5 && _iterator5.return) {
            _iterator5.return();
          }
        } finally {
          if (_didIteratorError5) {
            throw _iteratorError5;
          }
        }
      }

      var _iteratorNormalCompletion6 = true;
      var _didIteratorError6 = false;
      var _iteratorError6 = undefined;

      try {
        for (var _iterator6 = projectiles[Symbol.iterator](), _step6; !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
          var projectile = _step6.value;

          if (this.collider.intersectsCircle(projectile.collider)) {
            projectile.onCollide(this, camera, e);
          }
        }
      } catch (err) {
        _didIteratorError6 = true;
        _iteratorError6 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion6 && _iterator6.return) {
            _iterator6.return();
          }
        } finally {
          if (_didIteratorError6) {
            throw _iteratorError6;
          }
        }
      }

      return null;
    }
  }]);

  return BasicEnemy;
}(Mob);
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 356 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.segmentIntersectsGeometry = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

var _renderer = __webpack_require__(131);

var _settings = __webpack_require__(346);

var _settings2 = _interopRequireDefault(_settings);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var drawTexturedPolygon = function drawTexturedPolygon(c, camera, poly, texture, e, geo) {
  // c.fillStyle = color
  var images = e.state.imageLoader.images;
  c.strokeStyle = geo.strokeColor || 'white';
  c.lineWidth = geo.strokeLength || 0;
  c.save();
  c.beginPath();
  c.moveTo(poly.verticies[0].x, poly.verticies[0].y);
  // c.fillRect(poly.verticies[0].x - 1, poly.verticies[0].y - 1, 3, 3)
  for (var i = 1; i < poly.verticies.length; i++) {
    var vertex = poly.verticies[i];
    c.lineTo(vertex.x, vertex.y);
    // c.fillRect(vertex.x - 1, vertex.y - 1, 3, 3)
  }
  c.lineTo(poly.verticies[0].x, poly.verticies[0].y);
  c.closePath();
  c.clip();
  var box = poly.AABB();
  c.fillStyle = 'rgba(255, 255, 255, 0.00)';
  if (geo.stretch || _settings2.default.state.textureStretch) {
    c.drawImage(images[texture], box.x, box.y, box.width, box.height);
  } else {
    var imageWidth = geo.tileSize * (images[texture].height / images[texture].width);
    var imageHeight = geo.tileSize * (images[texture].height / images[texture].width);
    var x = Math.ceil(box.width / imageWidth);
    var y = Math.ceil(box.height / imageHeight);
    for (var _i = 0; _i < x; _i++) {
      for (var j = 0; j < y; j++) {
        c.drawImage(images[texture], Math.floor(box.x + _i * imageWidth), Math.floor(box.y + j * imageHeight), imageWidth, imageHeight);
      }
    }
  }

  c.fill();
  if (global.debug || geo.strokeLength) {
    // c.stroke()
  }
  c.restore();
};

var Geometry = function () {
  function Geometry(_ref) {
    var _ref$polygon = _ref.polygon,
        polygon = _ref$polygon === undefined ? new _math.Polygon((0, _math.pt)(0, 0), (0, _math.pt)(0, 1), (0, _math.pt)(1, 1)) : _ref$polygon,
        _ref$visible = _ref.visible,
        visible = _ref$visible === undefined ? true : _ref$visible,
        _ref$rotation = _ref.rotation,
        rotation = _ref$rotation === undefined ? 0 : _ref$rotation,
        _ref$texture = _ref.texture,
        texture = _ref$texture === undefined ? 'wall' : _ref$texture,
        _ref$strokeLength = _ref.strokeLength,
        strokeLength = _ref$strokeLength === undefined ? 0 : _ref$strokeLength,
        _ref$strokeColor = _ref.strokeColor,
        strokeColor = _ref$strokeColor === undefined ? null : _ref$strokeColor,
        _ref$tileSize = _ref.tileSize,
        tileSize = _ref$tileSize === undefined ? 512 : _ref$tileSize,
        _ref$stretch = _ref.stretch,
        stretch = _ref$stretch === undefined ? false : _ref$stretch;

    _classCallCheck(this, Geometry);

    this.position = polygon.verticies[0];
    this.polygon = polygon;
    this.rotation = rotation;
    this.visible = visible;
    this.strokeLength = strokeLength;
    this.strokeColor = strokeColor;
    this.texture = texture;
    this.tileSize = tileSize;
    this.stretch = stretch;
  }

  _createClass(Geometry, [{
    key: 'render',
    value: function render(c, camera, e) {
      global.camera = camera;
      if (!this.visible) return;
      this.polygon.translate(camera.position.x, camera.position.y);

      if (this.texture) {
        drawTexturedPolygon(c, camera, this.polygon, this.texture, e, this);
      } else {
        (0, _renderer.drawPolygon)(c, this.polygon);
      }

      this.polygon.translate(-camera.position.x, -camera.position.y);
    }
  }]);

  return Geometry;
}();

exports.default = Geometry;
var segmentIntersectsGeometry = exports.segmentIntersectsGeometry = function segmentIntersectsGeometry(seg, geometry) {
  var inter = null;
  for (var i = 0, size = geometry.length; i < size; i++) {
    inter = geometry[i].polygon.intersectsSegment(seg);
    if (inter) break;
  }
  return inter;
};
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 357 */,
/* 358 */,
/* 359 */,
/* 360 */,
/* 361 */,
/* 362 */,
/* 363 */,
/* 364 */,
/* 365 */,
/* 366 */,
/* 367 */,
/* 368 */,
/* 369 */,
/* 370 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

var _isomorphicHelpers = __webpack_require__(132);

var _scene = __webpack_require__(340);

var _engine = __webpack_require__(133);

var _engine2 = _interopRequireDefault(_engine);

var _loading = __webpack_require__(371);

var _loading2 = _interopRequireDefault(_loading);

var _start = __webpack_require__(374);

var _start2 = _interopRequireDefault(_start);

var _settings = __webpack_require__(346);

var _settings2 = _interopRequireDefault(_settings);

var _game = __webpack_require__(353);

var _game2 = _interopRequireDefault(_game);

var _levelselect = __webpack_require__(392);

var _levelselect2 = _interopRequireDefault(_levelselect);

var _pause = __webpack_require__(393);

var _pause2 = _interopRequireDefault(_pause);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

if ((0, _isomorphicHelpers.isNode)()) {
  global.document = new _isomorphicHelpers.DocumentMock();
  global.window = new _isomorphicHelpers.WindowMock();
  console.log('isNode');
} else {
  console.log('isBrowser');
}

var engine = new _engine2.default(document.getElementById('canvas'), 640, 480, true);

var scenes = {
  loading: _loading2.default,
  start: _start2.default,
  settings: _settings2.default,
  game: _game2.default,
  levelSelect: _levelselect2.default,
  pause: _pause2.default
};

console.log('Loaded scenes');
console.log(scenes);

var manager = new _scene.SceneManager(engine, scenes);
manager.goto('loading');
engine.start();
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 371 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scene = __webpack_require__(340);

var _imagemanifest = __webpack_require__(372);

var _imagemanifest2 = _interopRequireDefault(_imagemanifest);

var _audiomanifest = __webpack_require__(373);

var _audiomanifest2 = _interopRequireDefault(_audiomanifest);

var _loaders = __webpack_require__(350);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import { rectToPolygon, pt } from 'math'
// import { Button, Container, KeyBoardButtonManager } from 'engine/UI'

var loading = new _scene.Scene();
var imageLoader = new _loaders.ImageLoader(_imagemanifest2.default);
var audioLoader = new _loaders.AudioLoader(_audiomanifest2.default);

var onEnter = function onEnter(e) {
  e.state.imageLoader = imageLoader;
  e.state.audioLoader = audioLoader;
};

var frame = 0;
var render = function render(e, c) {
  // Clear Frame
  frame++;
  // console.log(c)
  c.clearRect(0, 0, e.width, e.height);

  // Loading with dots
  var fontSize = 30;
  var dots = '...';
  var text = 'Loading';
  c.font = fontSize + 'px sans-serif';
  var textWidth = c.measureText(text).width;
  var dotString = dots.substring(0, Math.floor(frame / 40) % 4);
  c.fillStyle = '#eee';
  c.fillText(text + dotString, e.width / 2 - textWidth / 2, e.height / 4 - fontSize * 0.25);

  // Loading Bar
  var loaded = imageLoader.loaded + audioLoader.loaded;
  var total = imageLoader.total + audioLoader.total;
  var barWidth = 200;
  var barHeight = 100;
  var barX = e.width / 2 - barWidth / 2;
  var barY = e.height * 0.35 - barHeight / 2;
  c.fillStyle = '#f44';
  c.fillRect(barX, barY, barWidth * (loaded / total), barHeight);
  c.strokeStyle = '#eee';
  c.lineWidth = 3;
  c.strokeRect(barX, barY, barWidth, barHeight);

  // Loading Progress
  var loaded2 = ('0' + loaded).slice(-2);
  var total2 = ('0' + total).slice(-2);
  var loadedText = 'Loaded ' + loaded2 + '/' + total2 + ' Assets';
  var loadedTextWidth = c.measureText(loadedText).width;
  c.fillStyle = '#eee';
  c.fillText(loadedText, e.width / 2 - loadedTextWidth / 2, e.height * 0.5 - fontSize * 0.25);

  c.fillStyle = '#f00';
  c.fillRect(e.mouse.x - 1, e.mouse.y - 1, 3, 3);
};

var update = function update(e) {
  var loaded = imageLoader.loaded + audioLoader.loaded;
  var total = imageLoader.total + audioLoader.total;
  if (loaded >= total) {
    loading.goto('start');
    e.setSupersampling(window.devicePixelRatio - 1 || 1);
  }
};

var keyUp = function keyUp(_e, _key, _evt) {
  // console.log(e, key, evt)
};

loading.render = render;
loading.onEnter = onEnter;
loading.update = update;
// loader.onClick = e => startContainer.handleClick(e)
loading.keyUp = keyUp;
exports.default = loading;

/***/ }),
/* 372 */
/***/ (function(module, exports) {

module.exports = {"basicMineInactive":"assets/basic_mine.png","basicMineActive":"assets/basic_mine_activated.png","frostMineInactive":"assets/frost_mine.png","frostMineActive":"assets/frost_mine_activated.png","incendiaryMineInactive":"assets/incendiary_mine.png","incendiaryMineActive":"assets/incendiary_mine_activated.png","basicEnemy":"assets/enemy_basic.png","player":"assets/player_char.png","floor":"assets/floor_texture_1.png","floor2":"assets/floor_texture_2.png","wall":"assets/wall_texture.png","ice":"assets/terrain_frozen_overlay.png","logo":"assets/mine_games_logo.png","crosshair":"assets/crosshairs.png","boostBar":"assets/boost_bar.png","buttonStatic":"assets/button_static.png","buttonHover":"assets/button_hover.png","buttonClicked":"assets/button_clicked.png","tut_enemy":"assets/tut_enemy.png","tut_boost":"assets/tut_left.png","tut_ricochet":"assets/tut_ricochet.png","tut_wasd":"assets/tut_wasd.png"}

/***/ }),
/* 373 */
/***/ (function(module, exports) {

module.exports = {"button":"assets/button58.mp3","boom":"assets/boom_small2.mp3","spawn":"assets/spawn.mp3","win":"assets/win.mp3"}

/***/ }),
/* 374 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keyM$addEdge, _keyM$addEdge2;

var _scene = __webpack_require__(340);

var _math = __webpack_require__(46);

var _UI = __webpack_require__(341);

var _keys = __webpack_require__(130);

var keys = _interopRequireWildcard(_keys);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var start = new _scene.Scene();

var centerButton = function centerButton(margins) {
  return function (e) {
    this.position.x = e.width * margins;
    this.dimensions = (0, _math.rectToPolygon)(0, 0, e.width * (1 - margins * 2), this.dimensions.verticies[2].y);
  };
};

var startContainer = new _UI.Container({
  dimensions: (0, _math.rectToPolygon)(0, 0, 900, 500),
  position: (0, _math.pt)(0, 0)
});

var startButton = new _UI.ImageButton({
  position: (0, _math.pt)(40, 250),
  text: 'Start Game',
  update: centerButton(0.25),
  fontSize: 50,
  onClick: function onClick(_) {
    return start.goto('levelSelect');
  },
  dimensions: (0, _math.rectToPolygon)(0, 0, 500, 150)
});

var settingsButton = new _UI.ImageButton({
  position: (0, _math.pt)(40, 450),
  text: 'Settings',
  update: centerButton(0.25),
  onClick: function onClick(_) {
    return start.goto('settings');
  },
  fontSize: 50,
  dimensions: (0, _math.rectToPolygon)(0, 0, 500, 150)
});

var keyM = new _UI.KeyBoardButtonManager({});

keyM.addEdge(startButton, (_keyM$addEdge = {}, _defineProperty(_keyM$addEdge, keys.KEY_UP, settingsButton), _defineProperty(_keyM$addEdge, keys.KEY_DOWN, settingsButton), _defineProperty(_keyM$addEdge, keys.ENTER, function (btn) {
  return btn.onClick();
}), _keyM$addEdge));

keyM.addEdge(settingsButton, (_keyM$addEdge2 = {}, _defineProperty(_keyM$addEdge2, keys.KEY_UP, startButton), _defineProperty(_keyM$addEdge2, keys.KEY_DOWN, startButton), _defineProperty(_keyM$addEdge2, keys.ENTER, function (btn) {
  return btn.onClick();
}), _keyM$addEdge2));

// keyM.select(startButton)

startContainer.addChildren(startButton, settingsButton);

var render = function render(e, c) {
  c.clearRect(0, 0, e.width, e.height);

  var bgimg = e.state.imageLoader.images.floor2;
  var tileSize = 512;
  var x = Math.ceil(e.width / tileSize) + 1;
  var y = Math.ceil(e.height / tileSize) + 1;
  for (var i = 0; i < x; i++) {
    for (var j = 0; j < y; j++) {
      c.drawImage(bgimg, i * tileSize, j * tileSize, tileSize, tileSize);
    }
  }

  startContainer.render(c, e);

  c.font = '75px MTV2C';
  c.fillStyle = 'white';
  var text = 'Mine Games';
  var w = c.measureText(text);
  c.fillText(text, e.width / 2 - w.width / 2, 150);

  if (e.touches.length <= 0) {
    c.fillStyle = '#f00';
    c.fillRect(e.mouse.x - 1, e.mouse.y - 1, 3, 3);
  } else {
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = e.touches[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var touch = _step.value;

        c.fillStyle = '#f00';
        c.beginPath();
        c.arc(touch.position.x, touch.position.y, 20, 0, Math.PI * 2);
        c.fill();
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }
  }
};

var update = function update(e) {
  startContainer.handleUpdate(e);
  keyM.handleUpdate(e);
};

var keyUp = function keyUp(e, key, evt) {
  keyM.handleKey(e, key, evt);
  if (!keyM.selected) {
    keyM.select(keyM.children[0]);
  }
};

start.render = render;
start.update = update;
start.onClick = function (e) {
  return startContainer.handleClick(e);
};
start.keyUp = keyUp;
exports.default = start;

/***/ }),
/* 375 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

var _keys = __webpack_require__(130);

var keys = _interopRequireWildcard(_keys);

var _camera2 = __webpack_require__(376);

var _camera3 = _interopRequireDefault(_camera2);

var _eventmanager = __webpack_require__(377);

var _eventmanager2 = _interopRequireDefault(_eventmanager);

var _projectile = __webpack_require__(378);

var _levelparser = __webpack_require__(379);

var _renderer = __webpack_require__(131);

var _touch = __webpack_require__(382);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Stage = function () {
  function Stage(_ref) {
    var _this = this,
        _keyEvents;

    var _ref$onMount = _ref.onMount,
        onMount = _ref$onMount === undefined ? function (_) {} : _ref$onMount,
        _ref$level = _ref.level,
        level = _ref$level === undefined ? {} : _ref$level;

    _classCallCheck(this, Stage);

    this.animCount = 0;
    this.rgb = 23;
    this.rgba = 23;

    this.render = function (e, c) {
      _this.animCount++;
      c.clearRect(0, 0, e.width, e.height);
      global.player = _this.player;
      _this.camera.render(c, e, _this);

      if (global.debug) {
        var playerNav = _this.camera.navMesh.getNearestPoint(_this.player.position);
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = undefined;

        try {
          for (var _iterator = _this.camera.navMesh.points[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var nav = _step.value;

            if (nav === playerNav) {
              c.fillStyle = 'white';
            } else {
              c.fillStyle = 'red';
            }
            // Draw the point
            c.fillRect(_this.camera.position.x + nav.position.x, _this.camera.position.y + nav.position.y, 5, 5);
            // Draw neighors
            // for (let neighbor of nav.neighbors) {
            //   let seg = new Segment(sum(nav.position, this.camera.position), sum(neighbor.point.position, this.camera.position))
            //   drawSegment(c, seg)
            // }
          }

          // Draw all mob paths
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }

        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = undefined;

        try {
          for (var _iterator2 = _this.camera.mobs[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var mob = _step2.value;

            var path = mob.path;
            if (path && path.length > 0) {
              for (var i = 0, j = 1; j < path.length; i++, j++) {
                var p0 = path[i];
                var p1 = path[j];
                var seg = new _math.Segment((0, _math.sum)(p0.point.position, _this.camera.position), (0, _math.sum)(p1.point.position, _this.camera.position));
                (0, _renderer.drawSegment)(c, seg, 'yellow');
                if (i === 0) {
                  var seg2 = new _math.Segment((0, _math.sum)(mob.position, _this.camera.position), (0, _math.sum)(p0.point.position, _this.camera.position));
                  (0, _renderer.drawSegment)(c, seg2, 'yellow');
                }
              }
              c.fillStyle = 'green';
              var pt1 = (0, _math.sum)(path[0].point.position, _this.camera.position);
              c.fillRect(pt1.x - 6, pt1.y - 6, 13, 13);
              var pt2 = (0, _math.sum)(path[path.length - 1].point.position, _this.camera.position);
              c.fillRect(pt2.x - 6, pt2.y - 6, 13, 13);
              var closestToMob = _this.camera.navMesh.getNearestPoint(mob.position);
              var toClosest = new _math.Segment((0, _math.sum)(mob.position, _this.camera.position), (0, _math.sum)(closestToMob.position, _this.camera.position));
              (0, _renderer.drawSegment)(c, toClosest, 'red');
            }
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }
      }

      if (!_this.player.alive && !_this.winner) {
        c.font = '52px MTV2C';
        if (_this.animCount % 3 === 0) {
          _this.rgb = Math.floor(255 - Math.random() * 100);
          _this.rgba = Math.floor(Math.random() * 50);
        }
        c.fillStyle = 'rgba(255, ' + _this.rgb + ', ' + _this.rgba + ', 1)';
        var w = c.measureText('Mission Failure');
        c.fillText('Mission Failure', e.width / 2 - w.width / 2, e.height / 2);
      }

      if (_this.winner) {
        c.font = '52px MTV2C';
        if (_this.animCount % 3 === 0) {
          _this.rgb = Math.floor(255 - Math.random() * 100);
          _this.rgba = Math.floor(Math.random() * 50);
        }
        c.fillStyle = 'rgba(255, ' + _this.rgb + ', ' + _this.rgba + ', 1)';
        var _w = c.measureText('Mission Complete');
        c.fillText('Mission Complete', e.width / 2 - _w.width / 2, e.height / 2);
      }

      if (Date.now() - _this.roundStart < 1000 * 3 && !_this.winner && _this.player.alive) {
        c.font = '52px MTV2C';
        if (_this.animCount % 3 === 0) {
          _this.rgb = Math.floor(255 - Math.random() * 100);
          _this.rgba = Math.floor(Math.random() * 50);
        }
        c.fillStyle = 'rgba(255, ' + _this.rgb + ', ' + _this.rgba + ', 1)';
        var text = 'Round Complete';
        if (_this.round === 0) {
          text = 'Mission Start';
        }
        var _w2 = c.measureText(text);
        c.fillText(text, e.width / 2 - _w2.width / 2, e.height / 2);
      }

      c.lineWidth = 3;
      c.fillStyle = '#f4ad42';
      var barWidth = 250;
      c.fillRect(e.width - (barWidth + 20), 20, barWidth * (_this.charge / _this.maxCharge), 75);

      c.drawImage(e.state.imageLoader.images['boostBar'], e.width - (barWidth + 20), 20, barWidth, 75);

      if (!e.touchmode) {
        c.fillStyle = '#f00';
        var crossHairSize = 50;
        var half = Math.floor(crossHairSize / 2);
        c.drawImage(e.state.imageLoader.images['crosshair'], e.mouse.x - half, e.mouse.y - half, crossHairSize, crossHairSize);
      } else {
        _this.leftJoystick.render(c);
        _this.rightJoystick.render(c);
      }
    };

    this.totalDelta = 0;

    this.update = function (e, delta) {
      _this.e = e;
      var roundTime = (Date.now() - _this.roundStart) / 1000;
      var d = (delta - _this.totalDelta) / (1000 / 60);
      if (d > 5) d = 1;
      _this.totalDelta = delta;
      _this.eventManager.events = _this.rounds[_this.round];
      _this.eventManager.update(roundTime, _this.camera);

      if (!_this.player.alive) {
        for (var i = 0; i < _this.camera.mobs.length; i++) {
          var mob = _this.camera.mobs[i];
          if (mob.type === 'Player') {
            _this.camera.mobs.splice(i, 1);
            break;
          }
        }
        _this.player._translate(-0xFFFFFFF, 0);
        _this.selectedMob = _this.camera.mobs[0];
        _this.player.deadCounter++;
        if (_this.player.deadCounter > 60) {
          _this.scene.goto('levelSelect');
        }
      } else {
        if (_this.camera.mobs.indexOf(_this.player) < 0) {
          _this.player.alive = false;
        }
      }

      if (_this.winner) {
        _this.winTime++;
        if (_this.winTime > 60 * 3) {
          _this.scene.goto('levelSelect');
        }
      }

      _this.testObjective(e);
      if (_this.selectedMob) {
        _this.camera.centerOn(_this.selectedMob.position);
      }

      if (e.touchmode) {
        _this.handleTouchControls(e, d);
      } else {
        _this.handleMouseControls(e, d);
      }
      _this.camera.update(e, d, _this);
    };

    this.keyEvents = (_keyEvents = {}, _defineProperty(_keyEvents, keys.ONE, function (_) {
      _this.selectedMob = _this.camera.mobs[0];
    }), _defineProperty(_keyEvents, keys.TWO, function (_) {
      _this.selectedMob = _this.camera.mobs[1];
    }), _defineProperty(_keyEvents, keys.THREE, function (_) {
      _this.selectedMob = _this.camera.mobs[2];
    }), _defineProperty(_keyEvents, keys.ESC, function (_) {
      _this.scene.goto('pause');
    }), _defineProperty(_keyEvents, keys.ENTER, function (_) {
      _this.scene.goto('pause');
    }), _defineProperty(_keyEvents, keys.R, function (_) {
      global.debug = !global.debug;
    }), _defineProperty(_keyEvents, keys.G, function (_) {
      global.godmode = !global.godmode;
    }), _keyEvents);

    this.loadLevel(level);
    this.onMount = onMount;
    this.scene = null;
  }

  _createClass(Stage, [{
    key: 'testObjective',
    value: function testObjective(_e) {
      if (this.camera.mobs.length === 1 && this.camera.mobs[0].type === 'Player' && this.eventManager.events.length <= 0 && !this.winner) {
        this.round++;
        this.roundStart = Date.now();
        if (this.rounds[this.round].length <= 0) {
          this.winner = true;
          this.e.state.audioLoader.assets['win'].play();
        } else {}
      }
    }
  }, {
    key: 'handleTouchControls',
    value: function handleTouchControls(e, d) {
      this.leftJoystick.activationRect = new _math.Rectangle(0, 0, e.width / 2, e.height);
      this.leftJoystick.update(e);
      this.rightJoystick.activationRect = new _math.Rectangle(e.width / 2, 0, e.width / 2, e.height);
      this.rightJoystick.update(e);
      if (this.rightJoystick.position) {
        var dist = (0, _math.distance)(this.rightJoystick.position, this.rightJoystick.currentPosition);
        var chargePercent = dist / this.rightJoystick.maxRange;
        this.charge = chargePercent * this.maxCharge;
      }
    }
  }, {
    key: 'handleRightJoystickFlick',
    value: function handleRightJoystickFlick(joystick) {
      var aimVector = (0, _math.sum)((0, _math.sub)(this.rightJoystick.position, this.rightJoystick.currentPosition), this.player.position);
      this.throwMine(aimVector.x, aimVector.y);
      this.charge = 0;
    }
  }, {
    key: 'handleMouseControls',
    value: function handleMouseControls(e, d) {
      // Charge
      if (e.mouse.down) {
        this.charge = (0, _math.clamp)((this.charge + 1) * d, 0, this.maxCharge);
      }
      if (keys.H in e.keys) {
        this.camera.screenShake(50);
      }
    }
  }, {
    key: 'throwMine',
    value: function throwMine(x, y) {
      var direction = (0, _math.sub)((0, _math.pt)(x, y), this.player.position);
      var mine = new _projectile.BasicMine(this.player.position, direction, 5 + this.charge / this.maxCharge * 17.5);
      this.camera.projectiles.push(mine);
    }
  }, {
    key: 'onClick',
    value: function onClick(e) {
      if (!e.touchmode) {
        var x = e.mouse.x + -this.camera.position.x;
        var y = e.mouse.y + -this.camera.position.y;
        this.throwMine(x, y);
        this.charge = 0;
      }
    }
  }, {
    key: 'keyUp',
    value: function keyUp(_e) {}
  }, {
    key: 'mount',
    value: function mount(scene) {
      scene.render = this.render.bind(this);
      scene.update = this.update.bind(this);
      scene.onClick = this.onClick.bind(this);
      scene.keyUp = this.keyUp.bind(this);
      scene.keyEvents = this.keyEvents;
      this.onMount(scene);
    }
  }, {
    key: 'loadLevel',
    value: function loadLevel(level) {
      var _this2 = this,
          _camera,
          _camera$navMesh;

      this.camera = new _camera3.default();
      this.charge = 0;
      this.maxCharge = 60;
      this.totalDelta = 0;
      this.rounds = [[], [], [], [], [], [], [], [], [], [], []];
      this.round = 0;
      this.winner = false;
      this.winTime = 0;
      this.roundStart = Date.now();
      this.eventManager = new _eventmanager2.default();
      this.leftJoystick = new _touch.VirtualJoystick({});
      this.rightJoystick = new _touch.VirtualJoystick({
        onEnd: function onEnd(joy) {
          return _this2.handleRightJoystickFlick(joy);
        }
      });
      var lvl = (0, _levelparser.loadTiled)(level);
      (_camera = this.camera).addGeometry.apply(_camera, _toConsumableArray(lvl.geometry));
      (_camera$navMesh = this.camera.navMesh).addPoints.apply(_camera$navMesh, _toConsumableArray(lvl.navPoints));
      this.camera.navMesh.computeNavmeshNeighbors(this.camera.geometry);
      var _iteratorNormalCompletion3 = true;
      var _didIteratorError3 = false;
      var _iteratorError3 = undefined;

      try {
        var _loop = function _loop() {
          var mob = _step3.value;

          if (mob.type === 'Player') {
            _this2.player = mob;
          }
          var rnd = mob.round || 0;
          _this2.rounds[rnd].push(new _eventmanager.Event(mob.spawnTime || 0, function (_) {
            _this2.camera.addMob(mob);
            _this2.e.state.audioLoader.assets['spawn'].play();
          }));
        };

        for (var _iterator3 = lvl.mobs[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
          _loop();
        }
      } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion3 && _iterator3.return) {
            _iterator3.return();
          }
        } finally {
          if (_didIteratorError3) {
            throw _iteratorError3;
          }
        }
      }

      this.selectedMob = this.player;
    }
  }, {
    key: 'start',
    value: function start(scene) {
      this.scene = scene;
      this.mount(scene);
    }
  }]);

  return Stage;
}();

exports.default = Stage;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 376 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

var _utils = __webpack_require__(347);

var _navmesh = __webpack_require__(354);

var _navmesh2 = _interopRequireDefault(_navmesh);

var _settings = __webpack_require__(346);

var _settings2 = _interopRequireDefault(_settings);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Camera = function () {
  function Camera() {
    var initialPosition = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : (0, _math.pt)(0, 0);

    _classCallCheck(this, Camera);

    this.position = initialPosition;
    this.height = 400;
    this.width = 400;
    this.tileSize = 512;
    this.shakeDuration = 0;
    this.shakeAmount = 0;
    this.mobs = [];
    this.projectiles = [];
    this.geometry = [];
    this.navMesh = new _navmesh2.default();
    global.camera = this;
  }

  _createClass(Camera, [{
    key: 'render',
    value: function render(c, e) {
      this.width = e.width;
      this.height = e.height;
      this.viewDistance = Math.max(this.width, this.height) + _settings2.default.state.FOV;

      // Drag Ground
      var xOffset = -Math.abs((this.position.x - 0xFFFFFFF) % this.tileSize);
      var yOffset = -Math.abs((this.position.y - 0xFFFFFFF) % this.tileSize);
      var x = Math.ceil(this.width / this.tileSize) + 1;
      var y = Math.ceil(this.height / this.tileSize) + 1;
      for (var i = 0; i < x; i++) {
        for (var j = 0; j < y; j++) {
          c.drawImage(e.state.imageLoader.images['floor'], xOffset + i * this.tileSize, yOffset + j * this.tileSize, this.tileSize, this.tileSize);
        }
      }

      for (var _len = arguments.length, rest = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
        rest[_key - 2] = arguments[_key];
      }

      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.projectiles[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var projectile = _step.value;

          projectile.render.apply(projectile, [c, this, e].concat(rest));
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = this.geometry[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var geom = _step2.value;

          var center = (0, _math.pt)(-this.position.x + this.width / 2, -this.position.y + this.height / 2);
          if ((0, _math.distance)(center, geom.polygon.center()) < this.viewDistance) {
            geom.render.apply(geom, [c, this, e].concat(rest));
          } else {}
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }

      var _iteratorNormalCompletion3 = true;
      var _didIteratorError3 = false;
      var _iteratorError3 = undefined;

      try {
        for (var _iterator3 = this.mobs[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
          var mob = _step3.value;

          mob.render.apply(mob, [c, this, e].concat(rest));
        }
      } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion3 && _iterator3.return) {
            _iterator3.return();
          }
        } finally {
          if (_didIteratorError3) {
            throw _iteratorError3;
          }
        }
      }
    }
  }, {
    key: 'addMob',
    value: function addMob() {
      var _mobs;

      (_mobs = this.mobs).push.apply(_mobs, arguments);
    }
  }, {
    key: 'addProjectile',
    value: function addProjectile() {
      var _projectiles;

      (_projectiles = this.projectiles).push.apply(_projectiles, arguments);
    }
  }, {
    key: 'addGeometry',
    value: function addGeometry() {
      var _geometry;

      for (var _len2 = arguments.length, geometry = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        geometry[_key2] = arguments[_key2];
      }

      var _iteratorNormalCompletion4 = true;
      var _didIteratorError4 = false;
      var _iteratorError4 = undefined;

      try {
        for (var _iterator4 = geometry[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
          var geo = _step4.value;

          var center = geo.polygon.center();
          var _iteratorNormalCompletion5 = true;
          var _didIteratorError5 = false;
          var _iteratorError5 = undefined;

          try {
            for (var _iterator5 = geo.polygon.verticies[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              var vertex = _step5.value;

              var direction = (0, _math.scalar)((0, _math.unit)((0, _math.sub)(vertex, center)), 75);
              var point = (0, _math.pt)(vertex.x + direction.x, vertex.y + direction.y);
              var inter = false;
              var _iteratorNormalCompletion6 = true;
              var _didIteratorError6 = false;
              var _iteratorError6 = undefined;

              try {
                for (var _iterator6 = geometry[Symbol.iterator](), _step6; !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
                  var geo2 = _step6.value;

                  if (geo2.polygon.intersectsPt(point)) {
                    inter = true;
                    break;
                  }
                }
              } catch (err) {
                _didIteratorError6 = true;
                _iteratorError6 = err;
              } finally {
                try {
                  if (!_iteratorNormalCompletion6 && _iterator6.return) {
                    _iterator6.return();
                  }
                } finally {
                  if (_didIteratorError6) {
                    throw _iteratorError6;
                  }
                }
              }

              if (inter) continue;
              var np = new _navmesh.NavPoint(point);
              this.navMesh.addPoints(np);
            }
          } catch (err) {
            _didIteratorError5 = true;
            _iteratorError5 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion5 && _iterator5.return) {
                _iterator5.return();
              }
            } finally {
              if (_didIteratorError5) {
                throw _iteratorError5;
              }
            }
          }
        }
      } catch (err) {
        _didIteratorError4 = true;
        _iteratorError4 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion4 && _iterator4.return) {
            _iterator4.return();
          }
        } finally {
          if (_didIteratorError4) {
            throw _iteratorError4;
          }
        }
      }

      (_geometry = this.geometry).push.apply(_geometry, geometry);
    }
  }, {
    key: 'centerOn',
    value: function centerOn(position) {
      var desired = (0, _math.pt)(-position.x + this.width / 2, -position.y + this.height / 2);
      var delta = (0, _math.sub)(desired, this.position);
      this.position.x += delta.x / 15;
      this.position.y += delta.y / 15;
    }
  }, {
    key: 'update',
    value: function update(e, delta) {
      if (this.shakeDuration) {
        this._screenShake();
        this.shakeDuration--;
      }

      for (var _len3 = arguments.length, rest = Array(_len3 > 2 ? _len3 - 2 : 0), _key3 = 2; _key3 < _len3; _key3++) {
        rest[_key3 - 2] = arguments[_key3];
      }

      var _iteratorNormalCompletion7 = true;
      var _didIteratorError7 = false;
      var _iteratorError7 = undefined;

      try {
        for (var _iterator7 = this.geometry[Symbol.iterator](), _step7; !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
          var geom = _step7.value;

          if (geom.update) {
            geom.update.apply(geom, [geom, e, this, delta].concat(rest));
          }
        }
      } catch (err) {
        _didIteratorError7 = true;
        _iteratorError7 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion7 && _iterator7.return) {
            _iterator7.return();
          }
        } finally {
          if (_didIteratorError7) {
            throw _iteratorError7;
          }
        }
      }

      var _iteratorNormalCompletion8 = true;
      var _didIteratorError8 = false;
      var _iteratorError8 = undefined;

      try {
        for (var _iterator8 = this.mobs[Symbol.iterator](), _step8; !(_iteratorNormalCompletion8 = (_step8 = _iterator8.next()).done); _iteratorNormalCompletion8 = true) {
          var mob = _step8.value;

          if (mob.update) {
            mob.update.apply(mob, [mob, e, this, delta].concat(rest));
          }
        }
      } catch (err) {
        _didIteratorError8 = true;
        _iteratorError8 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion8 && _iterator8.return) {
            _iterator8.return();
          }
        } finally {
          if (_didIteratorError8) {
            throw _iteratorError8;
          }
        }
      }

      var _iteratorNormalCompletion9 = true;
      var _didIteratorError9 = false;
      var _iteratorError9 = undefined;

      try {
        for (var _iterator9 = this.projectiles[Symbol.iterator](), _step9; !(_iteratorNormalCompletion9 = (_step9 = _iterator9.next()).done); _iteratorNormalCompletion9 = true) {
          var projectile = _step9.value;

          if (projectile.update) {
            projectile.update.apply(projectile, [projectile, e, this, delta].concat(rest));
          }
        }
      } catch (err) {
        _didIteratorError9 = true;
        _iteratorError9 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion9 && _iterator9.return) {
            _iterator9.return();
          }
        } finally {
          if (_didIteratorError9) {
            throw _iteratorError9;
          }
        }
      }
    }
  }, {
    key: '_screenShake',
    value: function _screenShake() {
      this.position.x += (Math.random() - 0.5) * this.shakeAmount;
      this.position.y += (Math.random() - 0.5) * this.shakeAmount;
    }
  }, {
    key: 'screenShake',
    value: function screenShake(amount) {
      var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 5;

      this.shakeDuration = Math.max(duration, this.shakeDuration);
      (0, _utils.vibrate)(this.shakeDuration * 1000 / 60);
      this.shakeAmount = amount;
    }
  }]);

  return Camera;
}();

exports.default = Camera;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 377 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Event = exports.Event = function Event() {
  var time = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  var fn = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : function (_) {};

  _classCallCheck(this, Event);

  this.time = time;
  this.run = fn;
};

var EventManager = function () {
  function EventManager() {
    var events = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

    _classCallCheck(this, EventManager);

    this.events = events;
  }

  _createClass(EventManager, [{
    key: "update",
    value: function update(timePassed, camera) {
      for (var i = this.events.length - 1; i >= 0; i--) {
        var evt = this.events[i];
        if (evt.time <= timePassed) {
          evt.run(camera);
          this.events.splice(i, 1);
        }
      }
    }
  }, {
    key: "addEvent",
    value: function addEvent() {
      var _events;

      (_events = this.events).push.apply(_events, arguments);
    }
  }]);

  return EventManager;
}();

exports.default = EventManager;

/***/ }),
/* 378 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Explosion = exports.BasicMine = exports.Projectile = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var SCREEN_SHAKE = 50;

var Projectile = exports.Projectile = function () {
  function Projectile(_ref) {
    var collider = _ref.collider,
        _ref$velocity = _ref.velocity,
        velocity = _ref$velocity === undefined ? 2 : _ref$velocity,
        _ref$acceleration = _ref.acceleration,
        acceleration = _ref$acceleration === undefined ? 1 : _ref$acceleration,
        _ref$friction = _ref.friction,
        friction = _ref$friction === undefined ? 2 : _ref$friction;

    _classCallCheck(this, Projectile);

    this.type = 'Projectile';

    this.collider = collider;
    this.velocity = velocity;
    this.acceleration = acceleration;
    this.friction = friction;
  }

  _createClass(Projectile, [{
    key: 'render',
    value: function render(c, camera, _e) {
      c.fillStyle = '#22f';
      c.beginPath();
      c.arc(this.collider.position.x + camera.position.x, this.collider.position.y + camera.position.y, this.collider.radius, 0, Math.PI * 2);
      c.fill();
    }
  }, {
    key: 'update',
    value: function update(_proj, e, camera, _d) {
      this.translate(1, 1, camera, e);
    }
  }, {
    key: 'onCollide',
    value: function onCollide(_mob, _camera) {
      // console.log(mob, 'BOOOM', camera)
    }
  }, {
    key: '_translate',
    value: function _translate(x, y) {
      this.collider.translate(x, y);
    }
  }, {
    key: 'translate',
    value: function translate(x, y, camera, e) {
      var mobs = camera.mobs,
          geometry = camera.geometry,
          projectiles = camera.projectiles;

      this._translate(x, y);
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = mobs[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var inter = _step.value;

          if (this.collider.intersectsCircle(inter.collider)) {
            this._translate(-x, -y);
            return false;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      var _iteratorNormalCompletion2 = true;
      var _didIteratorError2 = false;
      var _iteratorError2 = undefined;

      try {
        for (var _iterator2 = geometry[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
          var geom = _step2.value;

          if (this.collider.intersectsPoly(geom.polygon)) {
            this._translate(-x, -y);
            return false;
          }
        }
      } catch (err) {
        _didIteratorError2 = true;
        _iteratorError2 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion2 && _iterator2.return) {
            _iterator2.return();
          }
        } finally {
          if (_didIteratorError2) {
            throw _iteratorError2;
          }
        }
      }

      var _iteratorNormalCompletion3 = true;
      var _didIteratorError3 = false;
      var _iteratorError3 = undefined;

      try {
        for (var _iterator3 = projectiles[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
          var projectile = _step3.value;

          if (projectile !== this && this.collider.intersectsCircle(projectile.collider)) {
            projectile.onCollide(this, camera, e);
          }
        }
      } catch (err) {
        _didIteratorError3 = true;
        _iteratorError3 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion3 && _iterator3.return) {
            _iterator3.return();
          }
        } finally {
          if (_didIteratorError3) {
            throw _iteratorError3;
          }
        }
      }

      return true;
    }
  }]);

  return Projectile;
}();

var BasicMine = exports.BasicMine = function (_Projectile) {
  _inherits(BasicMine, _Projectile);

  function BasicMine() {
    var pos = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : (0, _math.pt)(0, 0);
    var target = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : (0, _math.pt)(2, 4);
    var velocity = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 10;
    var acceleration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0.95;

    _classCallCheck(this, BasicMine);

    var _this = _possibleConstructorReturn(this, (BasicMine.__proto__ || Object.getPrototypeOf(BasicMine)).call(this, {
      collider: new _math.Circle(pos, 20),
      acceleration: acceleration
    }));

    _this.type = 'BasicMine';


    _this.active = false;
    _this.velocityVector = (0, _math.scalar)((0, _math.unit)(target), velocity);
    return _this;
  }

  _createClass(BasicMine, [{
    key: 'update',
    value: function update(_proj, e, camera, _d) {
      if ((0, _math.distance)(_math.ZERO, this.velocityVector) > 0.01) {
        this.velocityVector.x *= this.acceleration;
        this.velocityVector.y *= this.acceleration;
      } else {
        return;
      }
      if ((0, _math.distance)(_math.ZERO, this.velocityVector) < 1) {
        this.active = true;
      }
      this.translate(this.velocityVector.x, this.velocityVector.y, camera, e);
    }
  }, {
    key: 'onCollide',
    value: function onCollide(target, camera, e) {
      var found = false;
      if (!this.active && target.type !== 'Explosion') return;
      target.alive = false;
      for (var i = 0; i < camera.mobs.length && !found; i++) {
        var mob = camera.mobs[i];
        if (mob === target) {
          camera.mobs[i].alive = false;
          // if (camera.mobs[i].type === 'Player') throw new Error('ads')
          camera.mobs.splice(i, 1);
          camera.screenShake(SCREEN_SHAKE);
          e.state.audioLoader.assets['boom'].play();
          found = true;
        }
      }
      for (var _i = 0; _i < camera.projectiles.length && !found; _i++) {
        var proj = camera.projectiles[_i];
        if (proj === target) {
          camera.screenShake(SCREEN_SHAKE);
          e.state.audioLoader.assets['boom'].play();
          found = true;
        }
      }
      for (var _i2 = 0; _i2 < camera.projectiles.length; _i2++) {
        var projs = camera.projectiles[_i2];
        if (this === projs) {
          camera.projectiles.splice(_i2, 1);
          camera.projectiles.push(new Explosion(this.collider.position));
          return;
        }
      }
    }
  }, {
    key: 'translate',
    value: function translate(x, y, camera, e) {
      var mobs = camera.mobs,
          geometry = camera.geometry,
          projectiles = camera.projectiles;

      this._translate(x, y);
      var _iteratorNormalCompletion4 = true;
      var _didIteratorError4 = false;
      var _iteratorError4 = undefined;

      try {
        for (var _iterator4 = mobs[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
          var inter = _step4.value;

          if (this.collider.intersectsCircle(inter.collider) && this.active) {
            this._translate(-x, -y);
            this.onCollide(inter, camera, e);
            return false;
          }
        }
      } catch (err) {
        _didIteratorError4 = true;
        _iteratorError4 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion4 && _iterator4.return) {
            _iterator4.return();
          }
        } finally {
          if (_didIteratorError4) {
            throw _iteratorError4;
          }
        }
      }

      var _iteratorNormalCompletion5 = true;
      var _didIteratorError5 = false;
      var _iteratorError5 = undefined;

      try {
        for (var _iterator5 = geometry[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
          var geom = _step5.value;

          if (this.collider.intersectsPoly(geom.polygon)) {
            var edge = this.collider.getEdgeFromPoly(geom.polygon);
            var norm = (0, _math.unit)((0, _math.normal)(edge[0], edge[1]));
            // -2*(V dot N)*N + V
            var reflectionVector = (0, _math.sum)((0, _math.scalar)(norm, (0, _math.dot)(this.velocityVector, norm) * -2), this.velocityVector);
            this._translate(-x, -y);
            this.velocityVector = reflectionVector;
            return false;
          }
        }
      } catch (err) {
        _didIteratorError5 = true;
        _iteratorError5 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion5 && _iterator5.return) {
            _iterator5.return();
          }
        } finally {
          if (_didIteratorError5) {
            throw _iteratorError5;
          }
        }
      }

      var _iteratorNormalCompletion6 = true;
      var _didIteratorError6 = false;
      var _iteratorError6 = undefined;

      try {
        for (var _iterator6 = projectiles[Symbol.iterator](), _step6; !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
          var projectile = _step6.value;

          if (projectile !== this && this.collider.intersectsCircle(projectile.collider)) {
            projectile.onCollide(this, camera, e);
          }
        }
      } catch (err) {
        _didIteratorError6 = true;
        _iteratorError6 = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion6 && _iterator6.return) {
            _iterator6.return();
          }
        } finally {
          if (_didIteratorError6) {
            throw _iteratorError6;
          }
        }
      }

      return true;
    }
  }, {
    key: 'render',
    value: function render(c, camera, e) {
      var images = e.state.imageLoader.images;
      var x = this.collider.position.x + camera.position.x;
      var y = this.collider.position.y + camera.position.y;
      var width = this.collider.radius * 2;
      var height = this.collider.radius * 2;
      var direction = this.velocityVector || (0, _math.pt)(0, 1);
      var degToLook = -Math.atan2(direction.x, direction.y);
      c.save();
      c.translate(x, y);
      c.rotate(degToLook);
      x = 0;
      y = 0;
      if (this.active) {
        c.drawImage(images['basicMineActive'], x - width / 2, y - height / 2, width, height);
      } else {
        c.drawImage(images['basicMineInactive'], x - width / 2, y - height / 2, width, height);
      }
      c.restore();

      if (!global.debug) return;
      c.fillStyle = '#22f';
      c.beginPath();
      c.arc(this.collider.position.x + camera.position.x, this.collider.position.y + camera.position.y, this.collider.radius, 0, Math.PI * 2);
      c.fill();
      if (this.active) {
        c.fillStyle = '#f22';
        c.beginPath();
        c.arc(this.collider.position.x + camera.position.x, this.collider.position.y + camera.position.y, this.collider.radius / 2, 0, Math.PI * 2);
        c.fill();
      }
    }
  }]);

  return BasicMine;
}(Projectile);

var Explosion = exports.Explosion = function (_Projectile2) {
  _inherits(Explosion, _Projectile2);

  function Explosion() {
    var pos = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : (0, _math.pt)(0, 0);
    var maxRadius = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 50;

    _classCallCheck(this, Explosion);

    var _this2 = _possibleConstructorReturn(this, (Explosion.__proto__ || Object.getPrototypeOf(Explosion)).call(this, {
      collider: new _math.Circle(pos, 20),
      acceleration: 0
    }));

    _this2.type = 'Explosion';

    _this2.maxRadius = maxRadius;
    _this2.maxLife = 30;
    _this2.currentLife = 0;
    _this2.active = true;
    return _this2;
  }

  _createClass(Explosion, [{
    key: 'update',
    value: function update(_proj, e, camera, _d) {
      this.collider = new _math.Circle(this.collider.position, (0, _math.clamp)(this.collider.radius + 3, 0, this.maxRadius));
      if (this.collider.radius >= this.maxRadius) {
        this.active = false;
      }
      if (!this.active) {
        this.currentLife++;
        if (this.currentLife > this.maxLife) {
          var index = camera.projectiles.indexOf(this);
          camera.projectiles.splice(index, 1);
        }
        return;
      }
      for (var i = camera.mobs.length - 1; i >= 0; i--) {
        var mob = camera.mobs[i];
        if (this.collider.intersectsCircle(mob.collider)) {
          // if (camera.mobs[i].type === 'Player') throw new Error('ads')
          camera.mobs.splice(i, 1);
        }
      }
      for (var _i3 = camera.projectiles.length - 1; _i3 >= 0; _i3--) {
        var proj = camera.projectiles[_i3];
        if (proj === this) continue;
        if (this.collider.intersectsCircle(proj.collider)) {
          if (proj.type === 'BasicMine') {
            proj.onCollide(this, camera, e);
          } else if (proj.type === 'Explosion') {} else {
            camera.projectiles.splice(_i3, 1);
          }
        }
      }
    }
  }, {
    key: 'onCollide',
    value: function onCollide(target, camera) {
      if (!this.active) return;
      target.alive = false;
      var found = false;
      for (var i = 0; i < camera.mobs.length && !found; i++) {
        var mob = camera.mobs[i];
        if (mob === target) {
          camera.mobs[i].alive = false;
          console.log(target.alive);
          // if (camera.mobs[i].type === 'Player') throw new Error('ads')
          camera.mobs.splice(i, 1);
          found = true;
        }
      }
    }
  }, {
    key: 'render',
    value: function render(c, camera, _e) {
      c.fillStyle = 'rgba(255, ' + Math.floor(255 - Math.random() * 100) + ', ' + Math.floor(Math.random() * 50) + ',' + (1 - this.currentLife / this.maxLife) + ')';
      c.beginPath();
      c.arc(this.collider.position.x + camera.position.x, this.collider.position.y + camera.position.y, this.collider.radius, 0, Math.PI * 2);
      c.fill();
    }
  }]);

  return Explosion;
}(Projectile);
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 379 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.loadTiled = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _math = __webpack_require__(46);

var _player = __webpack_require__(380);

var _player2 = _interopRequireDefault(_player);

var _mob = __webpack_require__(355);

var _navmesh = __webpack_require__(354);

var _geometry = __webpack_require__(356);

var _geometry2 = _interopRequireDefault(_geometry);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var parseGeometry = function parseGeometry(obj) {
  if (obj.polygon) {
    var poly = [];
    var xOffset = obj.x;
    var yOffset = obj.y;
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = obj.polygon[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var point = _step.value;

        var newpt = (0, _math.pt)(xOffset + point.x, yOffset + point.y);
        poly.push(newpt);
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }

    var newpoly = new (Function.prototype.bind.apply(_math.Polygon, [null].concat(poly)))();
    if (obj.rotation) {
      newpoly.rotateDeg(obj, obj.rotation);
    }

    return new _geometry2.default(_extends({}, obj.properties, {
      polygon: newpoly,
      rotation: obj.rotation,
      visible: obj.visible
    }));
  }
};

var parseMobs = function parseMobs(obj) {
  if (obj.properties) {
    switch (obj.properties.mob) {
      case 'player':
        return new _player2.default(obj.x, obj.y);
      case 'basic':
        return new _mob.BasicEnemy(obj.x, obj.y, obj.properties.spawnTime || 0, obj.properties.round || 0);
      default:
    }
    // texture = obj.properties.texture
  }
};

var parseNavMesh = function parseNavMesh(obj) {
  return new _navmesh.NavPoint(obj);
};

var loadTiled = exports.loadTiled = function loadTiled(json) {
  var geometry = [];
  var mobs = [];
  var navPoints = [];
  var _iteratorNormalCompletion2 = true;
  var _didIteratorError2 = false;
  var _iteratorError2 = undefined;

  try {
    for (var _iterator2 = json.layers[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
      var layer = _step2.value;

      switch (layer.name) {
        case 'geometry':
          console.log(layer);
          var _iteratorNormalCompletion3 = true;
          var _didIteratorError3 = false;
          var _iteratorError3 = undefined;

          try {
            for (var _iterator3 = layer.objects[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              var obj = _step3.value;

              var newGeo = parseGeometry(obj);
              if (newGeo) {
                geometry.push(newGeo);
              }
            }
          } catch (err) {
            _didIteratorError3 = true;
            _iteratorError3 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion3 && _iterator3.return) {
                _iterator3.return();
              }
            } finally {
              if (_didIteratorError3) {
                throw _iteratorError3;
              }
            }
          }

          break;
        case 'mobs':
          console.log(layer);
          var _iteratorNormalCompletion4 = true;
          var _didIteratorError4 = false;
          var _iteratorError4 = undefined;

          try {
            for (var _iterator4 = layer.objects[Symbol.iterator](), _step4; !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              var _obj = _step4.value;

              var mob = parseMobs(_obj);
              if (mob) {
                mobs.push(mob);
              }
            }
          } catch (err) {
            _didIteratorError4 = true;
            _iteratorError4 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion4 && _iterator4.return) {
                _iterator4.return();
              }
            } finally {
              if (_didIteratorError4) {
                throw _iteratorError4;
              }
            }
          }

          break;
        case 'navmesh':
          var _iteratorNormalCompletion5 = true;
          var _didIteratorError5 = false;
          var _iteratorError5 = undefined;

          try {
            for (var _iterator5 = layer.objects[Symbol.iterator](), _step5; !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              var _obj2 = _step5.value;

              var navPoint = parseNavMesh(_obj2);
              if (navPoint) {
                navPoints.push(navPoint);
              }
            }
          } catch (err) {
            _didIteratorError5 = true;
            _iteratorError5 = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion5 && _iterator5.return) {
                _iterator5.return();
              }
            } finally {
              if (_didIteratorError5) {
                throw _iteratorError5;
              }
            }
          }

          break;
      }
    }
  } catch (err) {
    _didIteratorError2 = true;
    _iteratorError2 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion2 && _iterator2.return) {
        _iterator2.return();
      }
    } finally {
      if (_didIteratorError2) {
        throw _iteratorError2;
      }
    }
  }

  return {
    geometry: geometry,
    mobs: mobs,
    navPoints: navPoints
  };
};

/***/ }),
/* 380 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

var _mob = __webpack_require__(355);

var _settings = __webpack_require__(346);

var _settings2 = _interopRequireDefault(_settings);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _Settings$state$contr = _settings2.default.state.controls,
    UP = _Settings$state$contr.UP,
    DOWN = _Settings$state$contr.DOWN,
    LEFT = _Settings$state$contr.LEFT,
    RIGHT = _Settings$state$contr.RIGHT,
    SPRINT = _Settings$state$contr.SPRINT;


var actionInKeys = function actionInKeys(action, keys) {
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = action[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var key = _step.value;

      if (key in keys) {
        return true;
      }
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return false;
};

var Player = function (_Mob) {
  _inherits(Player, _Mob);

  function Player(x, y) {
    _classCallCheck(this, Player);

    var _this = _possibleConstructorReturn(this, (Player.__proto__ || Object.getPrototypeOf(Player)).call(this, new _math.Circle((0, _math.pt)(x, y), 25)));

    _this.type = 'Player';

    _this.speed = 2;
    _this.alive = true;
    _this.deadCounter = 0;
    _this.lastDirectionVector = null;
    return _this;
  }

  _createClass(Player, [{
    key: 'handleMouseControls',
    value: function handleMouseControls(mob, e, camera, d) {
      if (actionInKeys(SPRINT, e.keys)) {
        this.speed = 5;
      } else {
        this.speed = 3;
      }
      var dx = 0;
      var dy = 0;
      if (actionInKeys(UP, e.keys)) {
        dy = -1;
      }
      if (actionInKeys(DOWN, e.keys)) {
        dy = 1;
      }
      if (actionInKeys(LEFT, e.keys)) {
        dx = -1;
      }
      if (actionInKeys(RIGHT, e.keys)) {
        dx = 1;
      }
      if (!global.godmode) {
        this.translate(dx * d * this.speed, dy * d * this.speed, camera, e);
      } else {
        this._translate(dx * d * this.speed, dy * d * this.speed, camera, e);
      }
    }
  }, {
    key: 'handleTouchControls',
    value: function handleTouchControls(mob, e, camera, d, stage) {
      if (!stage.leftJoystick.position) return;
      // Because control is analog, we might as well have max speed
      this.speed = 5;
      var travelDirection = (0, _math.unit)((0, _math.sub)(stage.leftJoystick.currentPosition, stage.leftJoystick.position));
      // Fixes divide by 0 issue with the same vectors
      if (isNaN(travelDirection.x) || isNaN(travelDirection.y)) return;
      var dist = (0, _math.distance)(stage.leftJoystick.currentPosition, stage.leftJoystick.position);
      var chargePercent = dist / stage.leftJoystick.maxRange;
      var dx = travelDirection.x * chargePercent;
      var dy = travelDirection.y * chargePercent;
      if (!global.godmode) {
        this.translate(dx * d * this.speed, dy * d * this.speed, camera, e);
      } else {
        this._translate(dx * d * this.speed, dy * d * this.speed, camera, e);
      }
    }
  }, {
    key: 'update',
    value: function update(mob, e, camera, d, stage) {
      if (e.touches.length <= 0) {
        this.handleMouseControls(mob, e, camera, d);
      } else {
        this.handleTouchControls(mob, e, camera, d, stage);
      }
    }
  }, {
    key: 'render',
    value: function render(c, camera, e, stage) {
      // Draw player image
      if (!this.alive) return;
      var images = e.state.imageLoader.images;
      var x = this.collider.position.x + camera.position.x;
      var y = this.collider.position.y + camera.position.y;
      var width = this.collider.radius * 2;
      var height = this.collider.radius * 2;
      var mouseX = e.mouse.x + -camera.position.x;
      var mouseY = e.mouse.y + -camera.position.y;
      var direction = (0, _math.unit)((0, _math.sub)((0, _math.pt)(mouseX, mouseY), this.position));
      var degToLook = -Math.atan2(direction.x, direction.y) - Math.PI;
      if (e.touchmode && stage.rightJoystick.position) {
        var aimVector = (0, _math.sub)(stage.rightJoystick.position, stage.rightJoystick.currentPosition);
        this.lastDirectionVector = aimVector;
        degToLook = -Math.atan2(aimVector.x, aimVector.y) - Math.PI;
      } else if (e.touchmode && stage.leftJoystick.position) {
        var moveVector = (0, _math.sub)(stage.leftJoystick.currentPosition, stage.leftJoystick.position);
        this.lastDirectionVector = moveVector;
        degToLook = -Math.atan2(moveVector.x, moveVector.y) - Math.PI;
      } else if (e.touchmode && this.lastDirectionVector) {
        degToLook = -Math.atan2(this.lastDirectionVector.x, this.lastDirectionVector.y) - Math.PI;
      }
      c.save();
      c.translate(x, y);
      c.rotate(degToLook);
      x = 0;
      y = 0;
      c.drawImage(images['player'], x - width / 2, y - height / 2, width, height);
      c.restore();

      // Draw hitbox
      if (!global.debug) return;
      c.fillStyle = '#22f';
      c.beginPath();
      c.arc(this.collider.position.x + camera.position.x, this.collider.position.y + camera.position.y, this.collider.radius, 0, Math.PI * 2);
      c.fill();
    }
  }]);

  return Player;
}(_mob.Mob);

exports.default = Player;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(92)))

/***/ }),
/* 381 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.moveTo = undefined;

var _math = __webpack_require__(46);

var moveTo = exports.moveTo = function moveTo(mob, pt) {
  var directionVector = (0, _math.sub)(pt, mob.position);
  var normDv = (0, _math.unit)(directionVector);
  return normDv;
};

/***/ }),
/* 382 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.VirtualJoystick = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _math = __webpack_require__(46);

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var noop = function noop(_) {};

var VirtualJoystick = exports.VirtualJoystick = function () {
  function VirtualJoystick(_ref) {
    var _ref$maxRange = _ref.maxRange,
        maxRange = _ref$maxRange === undefined ? 200 : _ref$maxRange,
        _ref$activationRect = _ref.activationRect,
        activationRect = _ref$activationRect === undefined ? new _math.Rectangle(0, 0, 100, 100) : _ref$activationRect,
        _ref$onStart = _ref.onStart,
        onStart = _ref$onStart === undefined ? noop : _ref$onStart,
        _ref$onEnd = _ref.onEnd,
        onEnd = _ref$onEnd === undefined ? noop : _ref$onEnd;

    _classCallCheck(this, VirtualJoystick);

    this.maxRange = maxRange;
    this.activationRect = activationRect;
    this.onStart = onStart;
    this.onEnd = onEnd;
    this.position = null;
    this.currentPosition = null;
  }

  _createClass(VirtualJoystick, [{
    key: 'update',
    value: function update(e) {
      var currentTouch = null;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = e.touches[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var touch = _step.value;

          if (this.activationRect.intersectsPt(touch.position)) {
            currentTouch = touch;
            break;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      if (currentTouch) {
        if (!this.position) {
          this.onStart(this);
          this.position = (0, _math.pt)(currentTouch.position.x, currentTouch.position.y);
        }
        this.currentPosition = (0, _math.pt)(currentTouch.position.x, currentTouch.position.y);
        var dist = (0, _math.distance)(this.currentPosition, this.position);
        if (dist > this.maxRange) {
          // Clamps the current position to the maxRange relative to the position
          this.currentPosition = (0, _math.sum)((0, _math.scalar)((0, _math.unit)((0, _math.sub)(this.currentPosition, this.position)), this.maxRange), this.position);
        }
      } else {
        if (this.position) {
          this.onEnd(this);
        }
        this.position = null;
        this.currentPosition = null;
      }
    }
  }, {
    key: 'render',
    value: function render(c) {
      if (this.position) {
        c.fillStyle = 'rgba(0, 0, 0, 0.5)';
        c.beginPath();
        c.arc(this.position.x, this.position.y, 20, 0, Math.PI * 2);
        c.fill();
      }

      if (this.currentPosition) {
        c.fillStyle = 'rgba(0, 0, 0, 0.5)';
        c.beginPath();
        c.arc(this.currentPosition.x, this.currentPosition.y, 20, 0, Math.PI * 2);
        c.fill();
      }
    }
  }]);

  return VirtualJoystick;
}();

/***/ }),
/* 383 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":true,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":17,"name":"","polygon":[{"x":0,"y":0},{"x":131.468,"y":-131.468},{"x":130.529,"y":-198.141},{"x":0.939055,"y":-196.263}],"properties":{"texture":"ice"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-225,"y":-90},{"height":0,"id":20,"name":"","polygon":[{"x":0,"y":0},{"x":131.468,"y":-131.468},{"x":130.529,"y":-198.141},{"x":0.939055,"y":-196.263}],"rotation":-180,"type":"","visible":true,"width":0,"x":192.506,"y":33.806},{"height":0,"id":21,"name":"","polygon":[{"x":0,"y":-198.141},{"x":131.468,"y":-66.673},{"x":130.529,"y":0},{"x":0.939055,"y":-1.878}],"rotation":180,"type":"","visible":true,"width":0,"x":194.115,"y":-275.91},{"height":0,"id":22,"name":"","polygon":[{"x":0,"y":-198.141},{"x":131.468,"y":-66.673},{"x":130.529,"y":0},{"x":0.939055,"y":-1.878}],"rotation":0,"type":"","visible":true,"width":0,"x":-224.421,"y":223.556}],"opacity":1,"properties":{"ondeath":"../../assetloader/test.mp3"},"propertytypes":{"ondeath":"file"},"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"id":25,"properties":{"spawnTime":23},"propertytypes":{"spawnTime":"int"},"template":"templates.tx","x":-32,"y":-320},{"height":0,"id":11,"name":"0","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":0}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0}],"nextobjectid":28,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 384 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":false,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":268,"name":"","polygon":[{"x":-90.2564,"y":-107.897},{"x":261.744,"y":-107.897},{"x":453.744,"y":84.1026},{"x":453.744,"y":436.103},{"x":261.744,"y":628.103},{"x":-90.2564,"y":628.103},{"x":-282.256,"y":436.103},{"x":-282.256,"y":84.1026}],"rotation":0,"type":"","visible":true,"width":0,"x":-421.744,"y":-468.103},{"height":0,"id":272,"name":"","polygon":[{"x":12.3077,"y":38.6272},{"x":-83.6923,"y":38.6272},{"x":-83.6923,"y":166.627},{"x":12.3077,"y":166.627}],"rotation":0,"type":"","visible":true,"width":0,"x":-812.308,"y":-166.627},{"height":0,"id":273,"name":"","polygon":[{"x":0,"y":17.2308},{"x":96,"y":17.2308},{"x":352,"y":-238.769},{"x":352,"y":-334.769},{"x":0,"y":-334.769}],"rotation":0,"type":"","visible":true,"width":0,"x":-896,"y":-433.231},{"height":0,"id":275,"name":"","polygon":[{"x":56.6154,"y":12.3077},{"x":312.615,"y":268.308},{"x":408.615,"y":268.308},{"x":408.615,"y":-83.6923},{"x":56.6154,"y":-83.6923}],"rotation":0,"type":"","visible":true,"width":0,"x":-184.615,"y":-684.308},{"height":0,"id":279,"name":"","polygon":[{"x":0,"y":32},{"x":128,"y":32},{"x":128,"y":-64},{"x":0,"y":-64}],"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":320},{"height":0,"id":280,"name":"","polygon":[{"x":0,"y":16},{"x":256,"y":-240},{"x":352,"y":-240},{"x":352,"y":112},{"x":0,"y":112}],"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":240},{"height":0,"id":282,"name":"","polygon":[{"x":17.2308,"y":32},{"x":-334.769,"y":32},{"x":-334.769,"y":-320},{"x":-238.769,"y":-320},{"x":17.2308,"y":-64}],"rotation":0,"type":"","visible":true,"width":0,"x":-561.231,"y":320},{"height":0,"id":284,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":384,"y":224},{"height":0,"id":286,"name":"","polygon":[{"x":12.3077,"y":6.6272},{"x":-83.6923,"y":6.6272},{"x":-83.6923,"y":134.627},{"x":12.3077,"y":134.627}],"rotation":0,"type":"","visible":true,"width":0,"x":-812.308,"y":-422.627},{"height":0,"id":287,"name":"","polygon":[{"x":0,"y":-32},{"x":0,"y":128},{"x":96,"y":128},{"x":32,"y":96},{"x":32,"y":0},{"x":96,"y":-32}],"rotation":0,"type":"","visible":true,"width":0,"x":-896,"y":-256},{"height":0,"id":288,"name":"","polygon":[{"x":12.3077,"y":5.30177},{"x":-83.6923,"y":5.30177},{"x":-83.6923,"y":133.302},{"x":12.3077,"y":133.302}],"rotation":0,"type":"","visible":true,"width":0,"x":211.692,"y":-421.302},{"height":0,"id":289,"name":"","polygon":[{"x":12.3077,"y":5.30178},{"x":-83.6923,"y":5.30178},{"x":-83.6923,"y":133.302},{"x":12.3077,"y":133.302}],"rotation":0,"type":"","visible":true,"width":0,"x":211.692,"y":-133.302},{"height":0,"id":291,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":160},{"x":-96,"y":160},{"x":-32,"y":128},{"x":-32,"y":32},{"x":-96,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":-288},{"height":0,"id":293,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":96},{"x":128,"y":96},{"x":128,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":-768},{"height":0,"id":294,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":96},{"x":128,"y":96},{"x":128,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":-768},{"height":0,"id":295,"name":"","polygon":[{"x":0,"y":0},{"x":160,"y":0},{"x":160,"y":96},{"x":128,"y":32},{"x":32,"y":32},{"x":0,"y":96}],"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-768},{"height":0,"id":296,"name":"","polygon":[{"x":0,"y":32},{"x":128,"y":32},{"x":128,"y":-64},{"x":0,"y":-64}],"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":320},{"height":0,"id":297,"name":"","polygon":[{"x":0,"y":0},{"x":160,"y":0},{"x":160,"y":-96},{"x":128,"y":-32},{"x":32,"y":-32},{"x":0,"y":-96}],"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":352}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":58,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-608},{"height":0,"id":235,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":-224},{"height":0,"id":299,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-224},{"height":0,"id":300,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":288},{"height":0,"id":301,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-672},{"height":0,"id":314,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-192},{"height":0,"id":315,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":288},{"height":0,"id":316,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":-192},{"height":0,"id":317,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-672},{"height":0,"id":318,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":288},{"height":0,"id":319,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":-224},{"height":0,"id":320,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-672},{"height":0,"id":321,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-192},{"height":0,"id":322,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":288},{"height":0,"id":323,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":-192},{"height":0,"id":324,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-224},{"height":0,"id":325,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-672}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":302,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-640},{"height":0,"id":303,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-768,"y":-224},{"height":0,"id":304,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":224},{"height":0,"id":305,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-192},{"height":0,"id":306,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":-416},{"height":0,"id":307,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":-608},{"height":0,"id":308,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-608},{"height":0,"id":309,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-416},{"height":0,"id":310,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":0},{"height":0,"id":311,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":192},{"height":0,"id":312,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":192},{"height":0,"id":313,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":0}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[{"height":0,"id":44,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-160},{"height":0,"id":46,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-160},{"height":0,"id":47,"name":"CUSTOM WALL","polygon":[{"x":0,"y":0},{"x":32,"y":-96},{"x":64,"y":0}],"properties":{"texture":"ice"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-160}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0}],"nextobjectid":326,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 385 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":false,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":279,"name":"","polygon":[{"x":0,"y":0},{"x":128,"y":0},{"x":96,"y":64},{"x":32,"y":64}],"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-160},{"height":0,"id":280,"name":"","polygon":[{"x":0,"y":0},{"x":320,"y":0},{"x":320,"y":224},{"x":416,"y":320},{"x":416,"y":-96},{"x":-96,"y":-96},{"x":-96,"y":320},{"x":0,"y":224}],"rotation":0,"type":"","visible":true,"width":0,"x":-384,"y":-256},{"height":0,"id":281,"name":"","polygon":[{"x":0,"y":0},{"x":896,"y":0},{"x":896,"y":96},{"x":0,"y":96}],"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":160},{"height":0,"id":282,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":-512},{"x":96,"y":-512},{"x":96,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":160},{"height":0,"id":283,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":-512},{"x":-96,"y":-512},{"x":-96,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":160},{"height":0,"id":284,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":64},{"x":1088,"y":64},{"x":1088,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-768,"y":-544},{"height":0,"id":285,"name":"","polygon":[{"x":0,"y":0},{"x":-96,"y":128},{"x":0,"y":128}],"rotation":0,"type":"","visible":true,"width":0,"x":320,"y":-480},{"height":0,"id":287,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":128},{"x":96,"y":128}],"rotation":0,"type":"","visible":true,"width":0,"x":-768,"y":-480},{"height":0,"id":288,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":-32},{"x":32,"y":-32}],"rotation":0,"type":"","visible":true,"width":0,"x":-384,"y":-224},{"height":0,"id":289,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-256},{"height":0,"id":290,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":-32},{"x":32,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":160},{"height":0,"id":291,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":32},{"x":0,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":128}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":58,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-192},{"height":0,"id":59,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-384},{"height":0,"id":116,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-384},{"height":0,"id":117,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-416},{"height":0,"id":118,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-416},{"height":0,"id":124,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-384},{"height":0,"id":125,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-416},{"height":0,"id":126,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-416},{"height":0,"id":129,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-384,"y":-384},{"height":0,"id":130,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-64,"y":-384},{"height":0,"id":131,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"2","spawnTime":20},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-384,"y":-416},{"height":0,"id":132,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"2","spawnTime":20},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-64,"y":-416},{"height":0,"id":232,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-416},{"height":0,"id":233,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-416},{"height":0,"id":234,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-384},{"height":0,"id":235,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-384},{"height":0,"id":236,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-416},{"height":0,"id":237,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-384},{"height":0,"id":238,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-416},{"height":0,"id":239,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-384},{"height":0,"id":240,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-384,"y":-384},{"height":0,"id":241,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-64,"y":-384},{"height":0,"id":242,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-416},{"height":0,"id":243,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-416},{"height":0,"id":244,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-416},{"height":0,"id":245,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-416},{"height":0,"id":246,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-384}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":268,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-192},{"height":0,"id":269,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":32},{"height":0,"id":270,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":32},{"height":0,"id":271,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-192},{"height":0,"id":272,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":128},{"height":0,"id":273,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-512,"y":128},{"height":0,"id":274,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":-384},{"height":0,"id":275,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-384},{"height":0,"id":292,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-416},{"height":0,"id":295,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-192},{"height":0,"id":296,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":-192},{"height":0,"id":299,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":128}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[{"height":0,"id":44,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-160},{"height":0,"id":46,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-160},{"height":0,"id":47,"name":"CUSTOM WALL","polygon":[{"x":0,"y":0},{"x":32,"y":-96},{"x":64,"y":0}],"properties":{"texture":"ice"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-160}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0}],"nextobjectid":302,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 386 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":true,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":1,"name":"0","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":-1600},{"height":0,"id":73,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":64},{"x":-96,"y":64},{"x":-96,"y":448},{"x":-416,"y":448},{"x":-448,"y":384},{"x":-768,"y":384},{"x":-864,"y":512},{"x":-864,"y":608},{"x":-1088,"y":608},{"x":-1088,"y":992},{"x":-960,"y":992},{"x":-960,"y":1088},{"x":-800,"y":1376},{"x":-704,"y":1376},{"x":-704,"y":1536},{"x":-384,"y":1536},{"x":-320,"y":1376},{"x":-256,"y":1376},{"x":-64,"y":1600},{"x":32,"y":1600},{"x":32,"y":1856},{"x":-1216,"y":1856},{"x":-1216,"y":1280},{"x":-1408,"y":1280},{"x":-1408,"y":160},{"x":-736,"y":160},{"x":-736,"y":0},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":"12","texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"string","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-3008},{"height":0,"id":74,"name":"","polygon":[{"x":0,"y":0},{"x":128,"y":0},{"x":224,"y":-64},{"x":576,"y":-64},{"x":576,"y":96},{"x":896,"y":96},{"x":1024,"y":-224},{"x":1024,"y":-608},{"x":832,"y":-608},{"x":832,"y":-928},{"x":1088,"y":-928},{"x":1152,"y":-1120},{"x":1152,"y":-1472},{"x":832,"y":-1472},{"x":800,"y":-1408},{"x":512,"y":-1408},{"x":512,"y":-1504},{"x":256,"y":-1504},{"x":256,"y":-1152},{"x":160,"y":-1152},{"x":160,"y":-1536},{"x":-32,"y":-1536},{"x":-32,"y":-1600},{"x":256,"y":-1600},{"x":416,"y":-1824},{"x":1440,"y":-1824},{"x":1472,"y":256},{"x":0,"y":256},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-1408},{"height":0,"id":77,"name":"","polygon":[{"x":0,"y":0},{"x":-96,"y":96},{"x":-512,"y":96},{"x":-576,"y":0},{"x":-736,"y":0},{"x":-736,"y":192},{"x":-640,"y":288},{"x":64,"y":288},{"x":64,"y":0},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-2336},{"height":0,"id":83,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":192},{"x":192,"y":192},{"x":192,"y":320},{"x":288,"y":320},{"x":288,"y":0},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":480,"y":-2336},{"height":0,"id":84,"name":"","polygon":[{"x":0,"y":0},{"x":128,"y":256},{"x":224,"y":256},{"x":224,"y":128},{"x":96,"y":0},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":-2016},{"height":0,"id":90,"name":"","polygon":[{"x":0,"y":0},{"x":-128,"y":0},{"x":-128,"y":96},{"x":0,"y":96},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":-1888},{"height":0,"id":91,"name":"","polygon":[{"x":0,"y":0},{"x":-96,"y":0},{"x":-96,"y":256},{"x":0,"y":256},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":480,"y":-1952},{"height":0,"id":92,"name":"","polygon":[{"x":0,"y":0},{"x":-96,"y":0},{"x":-96,"y":224},{"x":0,"y":224},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":896,"y":-1824},{"height":0,"id":93,"name":"","polygon":[{"x":0,"y":0},{"x":-192,"y":0},{"x":-192,"y":96},{"x":0,"y":96},{"x":0,"y":0}],"properties":{"strokeColor":"#B6C948","strokeLength":12,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":960,"y":-2624}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":16,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":-2784},{"height":0,"id":17,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-2304},{"height":0,"id":18,"name":"","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":480,"y":-2784},{"height":0,"id":19,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":-1504},{"height":0,"id":20,"name":"","point":true,"properties":{"mob":"basic","spawnTime":15},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":832,"y":-1408},{"height":0,"id":21,"name":"","point":true,"properties":{"mob":"basic","spawnTime":50},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":1056,"y":-2432},{"height":0,"id":22,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":-2496},{"height":0,"id":23,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":1024,"y":-1888},{"height":0,"id":24,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":576,"y":-2048},{"height":0,"id":45,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":-2080},{"height":0,"id":49,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":-2240},{"height":0,"id":50,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":576,"y":-1568},{"height":0,"id":46,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":1088,"y":-2720}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":26,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-1632},{"height":0,"id":28,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":640,"y":-1760},{"height":0,"id":30,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":-1856},{"height":0,"id":32,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-2368},{"height":0,"id":33,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":1088,"y":-2720},{"height":0,"id":34,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":-2464},{"height":0,"id":39,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-864,"y":-2208},{"height":0,"id":40,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":544,"y":-2656},{"height":0,"id":41,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":576,"y":-2464},{"height":0,"id":42,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-2432},{"height":0,"id":88,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":864,"y":-1440},{"height":0,"id":89,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":992,"y":-1856}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0}],"nextobjectid":94,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 387 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":false,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":1,"name":"0","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":608},{"height":0,"id":3,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":-192},{"x":128,"y":-192},{"x":128,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":256,"y":384},{"height":0,"id":4,"name":"","polygon":[{"x":0,"y":0},{"x":-256,"y":0},{"x":-256,"y":-96},{"x":0,"y":-96}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":480,"y":-416},{"height":0,"id":5,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":192},{"x":-96,"y":192},{"x":-96,"y":0}],"properties":{"strokeColor":"yellow","strokeLength":20,"texture":"wall"},"propertytypes":{"strokeColor":"string","strokeLength":"int","texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-192},{"height":0,"id":7,"name":"","polygon":[{"x":0,"y":0},{"x":128,"y":0},{"x":128,"y":64},{"x":-128,"y":64},{"x":-128,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":736},{"height":0,"id":9,"name":"","polygon":[{"x":0,"y":0},{"x":192,"y":-256},{"x":192,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":736},{"height":0,"id":10,"name":"","polygon":[{"x":0,"y":0},{"x":-192,"y":-224},{"x":-192,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":736},{"height":0,"id":53,"name":"","polygon":[{"x":0,"y":0},{"x":-160,"y":0},{"x":-160,"y":96},{"x":0,"y":96},{"x":0,"y":192},{"x":160,"y":192},{"x":160,"y":64},{"x":64,"y":64},{"x":64,"y":0},{"x":0,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":192},{"height":0,"id":60,"name":"","polygon":[{"x":0,"y":0},{"x":-256,"y":0},{"x":-256,"y":-96},{"x":0,"y":-96}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-416},{"height":0,"id":61,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":192},{"x":480,"y":192},{"x":480,"y":0},{"x":384,"y":0},{"x":384,"y":128},{"x":96,"y":128},{"x":96,"y":0},{"x":0,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":false,"width":0,"x":-160,"y":-160},{"height":512,"id":62,"name":"","properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":64,"x":544,"y":-256},{"height":0,"id":68,"name":"","polygon":[{"x":0,"y":0},{"x":384,"y":0},{"x":512,"y":-160},{"x":512,"y":-800},{"x":384,"y":-896},{"x":96,"y":-896},{"x":96,"y":-992},{"x":640,"y":-992},{"x":640,"y":96},{"x":0,"y":96},{"x":0,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":480},{"height":0,"id":72,"name":"","polygon":[{"x":0,"y":0},{"x":-64,"y":0},{"x":-64,"y":160},{"x":-224,"y":160},{"x":-224,"y":224},{"x":0,"y":224},{"x":0,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":512},{"height":0,"id":66,"name":"","polygon":[{"x":0,"y":0},{"x":-224,"y":0},{"x":-224,"y":-288},{"x":-320,"y":-288},{"x":-320,"y":-448},{"x":-416,"y":-448},{"x":-416,"y":96},{"x":0,"y":96},{"x":0,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":672},{"height":0,"id":67,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":96},{"x":-224,"y":96},{"x":-224,"y":480},{"x":0,"y":480},{"x":0,"y":576},{"x":-320,"y":576},{"x":-320,"y":0},{"x":0,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-352},{"height":0,"id":70,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":-96},{"x":-512,"y":-96},{"x":-512,"y":160},{"x":-448,"y":160},{"x":-352,"y":32},{"x":0,"y":32}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-512},{"height":0,"id":118,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":-32,"y":-320},{"x":0,"y":-320}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-64,"y":-416},{"height":0,"id":119,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":-32,"y":-320},{"x":0,"y":-320}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":-416},{"height":0,"id":123,"name":"","polygon":[{"x":0,"y":0},{"x":320,"y":0},{"x":320,"y":-32},{"x":0,"y":-32}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-736}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":16,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-576},{"height":0,"id":17,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":352,"y":-288},{"height":0,"id":18,"name":"","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":-64},{"height":0,"id":19,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":576},{"height":0,"id":20,"name":"","point":true,"properties":{"mob":"basic","spawnTime":15},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":576},{"height":0,"id":21,"name":"","point":true,"properties":{"mob":"basic","spawnTime":50},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-64},{"height":0,"id":22,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-32},{"height":0,"id":23,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-864,"y":0},{"height":0,"id":24,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":640},{"height":0,"id":25,"name":"","point":true,"properties":{"mob":"basic","spawnTime":10},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":576},{"height":0,"id":45,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":64},{"height":0,"id":49,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":-64},{"height":0,"id":50,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":608,"y":448},{"height":0,"id":46,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":768,"y":-128},{"height":0,"id":73,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":-160},{"height":0,"id":74,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":96},{"height":0,"id":75,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-512,"y":544},{"height":0,"id":76,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-32,"y":544},{"height":0,"id":78,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":672,"y":352},{"height":0,"id":79,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":736,"y":32},{"height":0,"id":83,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-128},{"height":0,"id":84,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":-128},{"height":0,"id":85,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":0},{"height":0,"id":86,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":0},{"height":0,"id":87,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":1,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-384},{"height":0,"id":88,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-288},{"height":0,"id":89,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":-128},{"height":0,"id":90,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-704,"y":160},{"height":0,"id":91,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":416},{"height":0,"id":92,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":608},{"height":0,"id":93,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":736,"y":160},{"height":0,"id":94,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":5},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":736,"y":352},{"height":0,"id":96,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":736,"y":-320},{"height":0,"id":97,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-288},{"height":0,"id":98,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":128},{"height":0,"id":101,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":416,"y":-288},{"height":0,"id":102,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":128},{"height":0,"id":103,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":320},{"height":0,"id":104,"name":"BASIC MOB 2","point":true,"properties":{"mob":"basic","round":2,"spawnTime":20},"propertytypes":{"mob":"string","round":"int","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-64}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":26,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":256},{"height":0,"id":27,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-704,"y":-128},{"height":0,"id":28,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":736,"y":352},{"height":0,"id":29,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":480},{"height":0,"id":30,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":320},{"height":0,"id":31,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":576},{"height":0,"id":32,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":-224},{"height":0,"id":33,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":288,"y":-224},{"height":0,"id":34,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-288},{"height":0,"id":35,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":64},{"height":0,"id":37,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":416,"y":128},{"height":0,"id":38,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":128},{"height":0,"id":39,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-864,"y":0},{"height":0,"id":40,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":448,"y":-160},{"height":0,"id":41,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":768,"y":-192},{"height":0,"id":42,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-320},{"height":0,"id":113,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":-96},{"height":0,"id":114,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-640},{"height":0,"id":115,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-64},{"height":0,"id":127,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":128,"y":96}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[{"height":18.8438,"id":48,"name":"","rotation":0,"text":{"text":"Hello World","wrap":true},"type":"","visible":true,"width":89.5469,"x":-896,"y":-288},{"height":0,"id":105,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-64},{"height":0,"id":106,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-672}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0}],"nextobjectid":132,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 388 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":true,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":176,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":-32,"y":-1376},{"x":0,"y":-1376}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":544},{"height":0,"id":177,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":32,"y":-1376},{"x":0,"y":-1376}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":544},{"height":0,"id":222,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":32},{"x":896,"y":32},{"x":896,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":-832},{"height":0,"id":223,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":32},{"x":896,"y":32},{"x":896,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":512},{"height":0,"id":250,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":0},{"x":64,"y":448},{"x":0,"y":448}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-128},{"height":0,"id":251,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":384},{"x":64,"y":384},{"x":64,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-608},{"height":0,"id":252,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":0},{"x":64,"y":768},{"x":0,"y":768}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-384,"y":-544},{"height":0,"id":253,"name":"","polygon":[{"x":0,"y":0},{"x":-64,"y":0},{"x":-64,"y":768},{"x":0,"y":768}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-64,"y":-544},{"height":0,"id":254,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":-64},{"x":704,"y":-64},{"x":704,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":384},{"height":0,"id":257,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":0},{"x":64,"y":288},{"x":0,"y":288}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":32},{"height":0,"id":258,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":0},{"x":64,"y":-480},{"x":0,"y":-480}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-64},{"height":0,"id":259,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":64},{"x":704,"y":64},{"x":704,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-672}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":58,"name":"PLAYER SPAWN","properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-192},{"height":0,"id":117,"name":"BASIC MOB","properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":448},{"height":0,"id":118,"name":"BASIC MOB","properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":448},{"height":0,"id":242,"name":"BASIC MOB","properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-736},{"height":0,"id":243,"name":"BASIC MOB","properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-736},{"height":0,"id":272,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-736},{"height":0,"id":273,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-736},{"height":0,"id":274,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":448},{"height":0,"id":275,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":448},{"height":0,"id":277,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":-736},{"height":0,"id":281,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-736},{"height":0,"id":282,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":448},{"height":0,"id":283,"name":"BASIC MOB","properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":448},{"height":0,"id":284,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-704},{"height":0,"id":285,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-704},{"height":0,"id":286,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":416},{"height":0,"id":287,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":416},{"height":0,"id":288,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":416},{"height":0,"id":289,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":416},{"height":0,"id":290,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-704},{"height":0,"id":291,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-704},{"height":0,"id":292,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":480},{"height":0,"id":293,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":480},{"height":0,"id":294,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-768},{"height":0,"id":295,"name":"BASIC MOB","properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-768}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":228,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-480,"y":-192},{"height":0,"id":229,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":32,"y":-576},{"height":0,"id":230,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":32,"y":0},{"height":0,"id":260,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":160,"y":0},{"height":0,"id":261,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-576},{"height":0,"id":262,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-192},{"height":0,"id":263,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":160,"y":416},{"height":0,"id":264,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":416},{"height":0,"id":265,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":0,"y":288},{"height":0,"id":266,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":288},{"height":0,"id":267,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":288},{"height":0,"id":268,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-576},{"height":0,"id":269,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":-576},{"height":0,"id":270,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-704},{"height":0,"id":271,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":160,"y":-704},{"height":0,"id":278,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":480},{"height":0,"id":279,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-768},{"height":0,"id":280,"name":"","rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-128},{"height":0,"id":297,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-576},{"height":0,"id":298,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":320},{"height":0,"id":299,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":288},{"height":0,"id":300,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":192},{"height":0,"id":301,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":64},{"height":0,"id":302,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-256},{"height":0,"id":303,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":-320},{"height":0,"id":304,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-384},{"height":0,"id":305,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":64},{"height":0,"id":306,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":-416},{"height":0,"id":307,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":-416},{"height":0,"id":309,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":-704},{"height":0,"id":310,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":-704},{"height":0,"id":311,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":448},{"height":0,"id":312,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":448},{"height":0,"id":313,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":96}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[{"height":0,"id":44,"name":"PLAYER SPAWN","properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-160},{"height":0,"id":46,"name":"BASIC MOB","properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-160},{"height":0,"id":47,"name":"CUSTOM WALL","polygon":[{"x":0,"y":0},{"x":32,"y":-96},{"x":64,"y":0}],"properties":{"texture":"ice"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-160}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0}],"nextobjectid":314,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 389 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":false,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":327,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-384},{"height":0,"id":328,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-384},{"height":0,"id":329,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-160},{"height":0,"id":330,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-160},{"height":0,"id":331,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-384},{"height":0,"id":332,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-160},{"height":0,"id":333,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-608},{"height":0,"id":334,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-608},{"height":0,"id":335,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-608},{"height":0,"id":336,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-576,"y":-832},{"height":0,"id":337,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-832},{"height":0,"id":338,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-832},{"height":0,"id":339,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-608},{"height":0,"id":340,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-384},{"height":0,"id":341,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-384},{"height":0,"id":342,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":32},{"x":64,"y":64},{"x":32,"y":96},{"x":0,"y":96},{"x":-32,"y":64},{"x":-32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-608},{"height":0,"id":343,"name":"","polygon":[{"x":0,"y":0},{"x":288,"y":-288},{"x":205.714,"y":-288},{"x":0,"y":-82.2857}],"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":-640},{"height":0,"id":344,"name":"","polygon":[{"x":0,"y":0},{"x":288,"y":288},{"x":288,"y":205.714},{"x":82.2857,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-32,"y":-928},{"height":0,"id":345,"name":"","polygon":[{"x":0,"y":0},{"x":-288,"y":-288},{"x":-288,"y":-205.714},{"x":-82.2857,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":32},{"height":0,"id":346,"name":"","polygon":[{"x":0,"y":0},{"x":288,"y":-288},{"x":288,"y":-205.714},{"x":82.2857,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-32,"y":32},{"height":0,"id":352,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":64},{"x":576,"y":64},{"x":608,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":32},{"height":0,"id":353,"name":"","polygon":[{"x":0,"y":0},{"x":-64,"y":-32},{"x":-64,"y":-352},{"x":0,"y":-384}],"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":-256},{"height":0,"id":354,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":32},{"x":64,"y":352},{"x":0,"y":384}],"rotation":0,"type":"","visible":true,"width":0,"x":256,"y":-640},{"height":0,"id":355,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":-64},{"x":576,"y":-64},{"x":608,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-928}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":58,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-448},{"height":0,"id":235,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-896,"y":-384},{"height":0,"id":299,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-416},{"height":0,"id":300,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":0},{"height":0,"id":301,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-864},{"height":0,"id":314,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-448},{"height":0,"id":315,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":0},{"height":0,"id":316,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-896,"y":-384},{"height":0,"id":317,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-864},{"height":0,"id":318,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":0},{"height":0,"id":319,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-896,"y":-448},{"height":0,"id":320,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-864},{"height":0,"id":321,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-448},{"height":0,"id":322,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":0},{"height":0,"id":323,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-896,"y":-384},{"height":0,"id":324,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-416},{"height":0,"id":325,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-864},{"height":0,"id":358,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-768,"y":-160},{"height":0,"id":359,"name":"round1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-160},{"height":0,"id":360,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-736},{"height":0,"id":361,"name":"round2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":-736}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":302,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":-640},{"height":0,"id":303,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-768,"y":-224},{"height":0,"id":304,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-352,"y":224},{"height":0,"id":305,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-192},{"height":0,"id":306,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":-416},{"height":0,"id":307,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":-608},{"height":0,"id":308,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-608},{"height":0,"id":309,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-416},{"height":0,"id":310,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":0},{"height":0,"id":311,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":192},{"height":0,"id":312,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":192},{"height":0,"id":313,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":0}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[{"height":0,"id":44,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-160},{"height":0,"id":46,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-160},{"height":0,"id":47,"name":"CUSTOM WALL","polygon":[{"x":0,"y":0},{"x":32,"y":-96},{"x":64,"y":0}],"properties":{"texture":"ice"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-160}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0}],"nextobjectid":363,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 390 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":false,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":176,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":-32,"y":-1344},{"x":0,"y":-1344}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-1056,"y":576},{"height":0,"id":177,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":32,"y":-1344},{"x":0,"y":-1344}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":640,"y":576},{"height":0,"id":181,"name":"","polygon":[{"x":0,"y":0},{"x":40,"y":-64},{"x":120,"y":-64},{"x":160,"y":0},{"x":120,"y":64},{"x":40,"y":64}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":-96},{"height":0,"id":182,"name":"","polygon":[{"x":0,"y":0},{"x":40,"y":-64},{"x":120,"y":-64},{"x":160,"y":0},{"x":120,"y":64},{"x":40,"y":64}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":-96},{"height":0,"id":183,"name":"","polygon":[{"x":0,"y":0},{"x":73.1429,"y":-16},{"x":0,"y":-32},{"x":-109.714,"y":-32},{"x":-182.857,"y":-16},{"x":-109.714,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-160,"y":-256},{"height":0,"id":184,"name":"","polygon":[{"x":0,"y":0},{"x":73.1429,"y":-16},{"x":0,"y":-32},{"x":-109.714,"y":-32},{"x":-182.857,"y":-16},{"x":-109.714,"y":0}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-160,"y":96},{"height":0,"id":185,"name":"","polygon":[{"x":0,"y":0},{"x":264,"y":-32},{"x":792,"y":-32},{"x":1056,"y":0},{"x":792,"y":32},{"x":264,"y":32}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":-544},{"height":0,"id":187,"name":"","polygon":[{"x":0,"y":0},{"x":264,"y":-32},{"x":792,"y":-32},{"x":1056,"y":0},{"x":792,"y":32},{"x":264,"y":32}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-736,"y":352},{"height":0,"id":193,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":-64,"y":224}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":-384},{"height":0,"id":195,"name":"","polygon":[{"x":0,"y":0},{"x":192,"y":0},{"x":0,"y":32}],"properties":{"texture":"wall"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":-416},{"height":0,"id":199,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":-32,"y":-224}],"rotation":0,"type":"","visible":true,"width":0,"x":-704,"y":192},{"height":0,"id":200,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":-32},{"x":192,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":224},{"height":0,"id":202,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":224}],"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":-384},{"height":0,"id":203,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":32},{"x":-192,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":-416},{"height":0,"id":204,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":32},{"x":-192,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":192},{"height":0,"id":206,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":32,"y":-224}],"rotation":0,"type":"","visible":true,"width":0,"x":256,"y":192},{"height":0,"id":207,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":64,"y":-64},{"x":0,"y":-32}],"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":-384},{"height":0,"id":208,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":-64},{"x":32,"y":-32},{"x":32,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-704,"y":-384},{"height":0,"id":209,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":64},{"x":32,"y":32},{"x":32,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-704,"y":192},{"height":0,"id":210,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":32},{"x":64,"y":64},{"x":32,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":192},{"height":0,"id":215,"name":"","polygon":[{"x":0,"y":0},{"x":40,"y":-24},{"x":40,"y":24}],"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-96},{"height":0,"id":216,"name":"","polygon":[{"x":0,"y":0},{"x":24,"y":-40},{"x":48,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-248,"y":-120},{"height":0,"id":217,"name":"","polygon":[{"x":0,"y":0},{"x":24,"y":40},{"x":48,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-248,"y":-72},{"height":0,"id":218,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":48},{"x":40,"y":24}],"rotation":0,"type":"","visible":true,"width":0,"x":-200,"y":-120},{"height":0,"id":222,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":32},{"x":1696,"y":32},{"x":1696,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-1056,"y":-768},{"height":0,"id":223,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":32},{"x":1696,"y":32},{"x":1696,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-1056,"y":544}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":58,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-192},{"height":0,"id":59,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-448},{"height":0,"id":116,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":-448},{"height":0,"id":117,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":288},{"height":0,"id":118,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":288},{"height":0,"id":124,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":320},{"height":0,"id":125,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":-480},{"height":0,"id":126,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":416,"y":-480},{"height":0,"id":129,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":320},{"height":0,"id":130,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"1","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":416,"y":320},{"height":0,"id":131,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"2","spawnTime":20},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":288},{"height":0,"id":132,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"2","spawnTime":20},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":416,"y":288},{"height":0,"id":232,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":288},{"height":0,"id":233,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":288},{"height":0,"id":234,"name":"round 1","point":true,"properties":{"mob":"basic","round":"1","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":-448},{"height":0,"id":235,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","round":"0","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-448},{"height":0,"id":236,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":288},{"height":0,"id":237,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-448},{"height":0,"id":238,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":288},{"height":0,"id":239,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":5},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":-448},{"height":0,"id":240,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":320},{"height":0,"id":241,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":416,"y":320},{"height":0,"id":242,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-832,"y":-480},{"height":0,"id":243,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":10},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":416,"y":-480},{"height":0,"id":244,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-480},{"height":0,"id":245,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":-480},{"height":0,"id":246,"name":"round 2","point":true,"properties":{"mob":"basic","round":"2","spawnTime":15},"propertytypes":{"mob":"string","round":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":320}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":227,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-768,"y":-160},{"height":0,"id":230,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":320},{"height":0,"id":231,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":288},{"height":0,"id":251,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":352,"y":320},{"height":0,"id":252,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-448,"y":-448},{"height":0,"id":253,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":-512},{"height":0,"id":254,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":352,"y":-512},{"height":0,"id":255,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":320,"y":-160},{"height":0,"id":260,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-768,"y":-32},{"height":0,"id":261,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":320,"y":-32},{"height":0,"id":262,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":-448},{"height":0,"id":263,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":288},{"height":0,"id":268,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":-160},{"height":0,"id":269,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":-288},{"height":0,"id":270,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":-320},{"height":0,"id":271,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":320,"y":-320},{"height":0,"id":272,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":256,"y":-480},{"height":0,"id":273,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":352,"y":128},{"height":0,"id":274,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":352,"y":224},{"height":0,"id":275,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":288},{"height":0,"id":276,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":160,"y":160},{"height":0,"id":277,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":192,"y":64},{"height":0,"id":278,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":160},{"height":0,"id":279,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-608,"y":128},{"height":0,"id":280,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":160},{"height":0,"id":281,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":32},{"height":0,"id":282,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":64},{"height":0,"id":283,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-800,"y":160},{"height":0,"id":284,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-640,"y":288},{"height":0,"id":285,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-672,"y":-640},{"height":0,"id":286,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":-640},{"height":0,"id":287,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":-672},{"height":0,"id":288,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":384,"y":-640},{"height":0,"id":289,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":480,"y":-320},{"height":0,"id":290,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":512,"y":-288},{"height":0,"id":291,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":512,"y":128},{"height":0,"id":292,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":512,"y":352},{"height":0,"id":293,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":224,"y":512},{"height":0,"id":294,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-320,"y":480},{"height":0,"id":295,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-704,"y":480},{"height":0,"id":296,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-960,"y":-352},{"height":0,"id":297,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":-64},{"height":0,"id":298,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-928,"y":256}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[{"height":0,"id":44,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-160},{"height":0,"id":46,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-160},{"height":0,"id":47,"name":"CUSTOM WALL","polygon":[{"x":0,"y":0},{"x":32,"y":-96},{"x":64,"y":0}],"properties":{"texture":"ice"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-160}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0}],"nextobjectid":299,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 391 */
/***/ (function(module, exports) {

module.exports = {"height":16,"infinite":true,"layers":[{"chunks":[],"height":0,"name":"Tile Layer 1","opacity":1,"startx":0,"starty":0,"type":"tilelayer","visible":false,"width":0,"x":0,"y":0},{"draworder":"topdown","name":"geometry","objects":[{"height":0,"id":363,"name":"","polygon":[{"x":0,"y":0},{"x":256,"y":0},{"x":256,"y":64},{"x":0,"y":64}],"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":288},{"height":0,"id":364,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":0},{"x":64,"y":-192},{"x":0,"y":-192}],"rotation":0,"type":"","visible":true,"width":0,"x":-32,"y":288},{"height":0,"id":365,"name":"","polygon":[{"x":0,"y":0},{"x":-64,"y":0},{"x":-64,"y":-192},{"x":0,"y":-192}],"rotation":0,"type":"","visible":true,"width":0,"x":-160,"y":288},{"height":0,"id":366,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":64},{"x":64,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-32,"y":-96},{"height":0,"id":367,"name":"","polygon":[{"x":0,"y":0},{"x":64,"y":-64},{"x":0,"y":-64}],"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":-32},{"height":0,"id":373,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":-32,"y":-448},{"x":0,"y":-448}],"rotation":0,"type":"","visible":true,"width":0,"x":-224,"y":96},{"height":0,"id":374,"name":"","polygon":[{"x":0,"y":0},{"x":96,"y":0},{"x":96,"y":-64},{"x":0,"y":-64}],"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":-352},{"height":0,"id":375,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":32,"y":-448},{"x":0,"y":-448}],"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":96},{"height":0,"id":376,"name":"","polygon":[{"x":0,"y":0},{"x":-96,"y":0},{"x":-96,"y":-64},{"x":0,"y":-64}],"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-352},{"height":0,"id":377,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":-32},{"x":0,"y":-32}],"rotation":0,"type":"","visible":true,"width":0,"x":-160,"y":-416},{"height":0,"id":378,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":32},{"x":32,"y":0}],"rotation":0,"type":"","visible":true,"width":0,"x":-64,"y":-448},{"height":0,"id":380,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":0},{"x":-32,"y":-96},{"x":96,"y":-96},{"x":96,"y":0},{"x":64,"y":0},{"x":32,"y":-64},{"x":32,"y":-64}],"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-448},{"height":0,"id":389,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":160},{"x":224,"y":160},{"x":224,"y":0}],"properties":{"texture":"tut_ricochet"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-512,"y":-288},{"height":0,"id":390,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":224},{"x":224,"y":224},{"x":224,"y":0}],"properties":{"texture":"tut_enemy"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":64,"y":-416},{"height":0,"id":391,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":224},{"x":224,"y":224},{"x":224,"y":0}],"properties":{"texture":"tut_boost"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":96,"y":128},{"height":0,"id":392,"name":"","polygon":[{"x":0,"y":0},{"x":0,"y":224},{"x":224,"y":224},{"x":224,"y":0}],"properties":{"texture":"tut_wasd"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-544,"y":128},{"height":0,"id":393,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":32,"y":64},{"x":0,"y":64}],"rotation":0,"type":"","visible":true,"width":0,"x":32,"y":96},{"height":0,"id":394,"name":"","polygon":[{"x":0,"y":0},{"x":32,"y":0},{"x":32,"y":64},{"x":0,"y":64}],"rotation":0,"type":"","visible":true,"width":0,"x":-256,"y":96},{"height":0,"id":397,"name":"","polygon":[{"x":0,"y":0},{"x":-32,"y":32},{"x":0,"y":64},{"x":32,"y":32}],"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-256}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"mobs","objects":[{"height":0,"id":58,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":256},{"height":0,"id":388,"name":"tutorial","point":true,"properties":{"mob":"basic"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-96,"y":-480}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"navmesh","objects":[{"height":0,"id":381,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-128,"y":-576},{"height":0,"id":382,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-64,"y":-576},{"height":0,"id":383,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-512},{"height":0,"id":384,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":-512},{"height":0,"id":385,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-480},{"height":0,"id":386,"name":"","point":true,"rotation":0,"type":"","visible":true,"width":0,"x":0,"y":-480}],"opacity":1,"type":"objectgroup","visible":true,"x":0,"y":0},{"draworder":"topdown","name":"Templates","objects":[{"height":0,"id":44,"name":"PLAYER SPAWN","point":true,"properties":{"mob":"player"},"propertytypes":{"mob":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-416,"y":-160},{"height":0,"id":46,"name":"BASIC MOB","point":true,"properties":{"mob":"basic","spawnTime":5},"propertytypes":{"mob":"string","spawnTime":"int"},"rotation":0,"type":"","visible":true,"width":0,"x":-288,"y":-160},{"height":0,"id":47,"name":"CUSTOM WALL","polygon":[{"x":0,"y":0},{"x":32,"y":-96},{"x":64,"y":0}],"properties":{"texture":"ice"},"propertytypes":{"texture":"string"},"rotation":0,"type":"","visible":true,"width":0,"x":-192,"y":-160}],"opacity":1,"type":"objectgroup","visible":false,"x":0,"y":0}],"nextobjectid":400,"orientation":"orthogonal","renderorder":"right-down","tiledversion":"2017.11.22","tileheight":32,"tilesets":[],"tilewidth":32,"type":"map","version":1,"width":16}

/***/ }),
/* 392 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scene = __webpack_require__(340);

var _math = __webpack_require__(46);

var _UI = __webpack_require__(341);

var _keys = __webpack_require__(130);

var keys = _interopRequireWildcard(_keys);

var _game = __webpack_require__(353);

var _game2 = _interopRequireDefault(_game);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var levelSelect = new _scene.Scene();
levelSelect.onEnter = function (_) {
  // alert(game.state.currentLevel)
};

var levelSelectContainer = new _UI.Container({
  dimensions: (0, _math.rectToPolygon)(0, 0, 900, 500),
  position: (0, _math.pt)(0, 0)
});

var levels = {
  tutorial: 'Tutorial',
  level1: 'Level 1',
  level2: 'Level 2',
  level3: 'Level 3',
  level4: 'Level 4',
  level5: 'Level 5',
  level6: 'Level 6',
  level7: 'Level 7'
};

var keyM = new _UI.KeyBoardButtonManager({});

var i = 0;
var height = 100;
var padding = 25;
var rows = 4;

var _loop = function _loop(cl) {
  var _keyM$addEdge;

  var btn = new _UI.ImageButton({
    position: (0, _math.pt)(40 + Math.floor(i / rows) * 400, 100 + i % rows * height + i % rows * padding),
    text: levels[cl],
    fontSize: 50,
    onClick: function onClick(_) {
      _game2.default.state.currentLevel = cl;
      levelSelect.goto('game');
    },
    dimensions: (0, _math.rectToPolygon)(0, 0, 300, height)
  });
  levelSelectContainer.addChildren(btn);
  var topButton = null;
  var bottomButton = null;
  if (i === 0) {
    topButton = btn;
    bottomButton = btn;
  } else {
    levelSelectContainer.children[i - 1].buttons[keys.KEY_DOWN] = btn;
    levelSelectContainer.children[0].buttons[keys.KEY_UP] = btn;
    topButton = levelSelectContainer.children[i - 1];
    bottomButton = levelSelectContainer.children[0];
  }
  keyM.addEdge(btn, (_keyM$addEdge = {}, _defineProperty(_keyM$addEdge, keys.KEY_UP, topButton), _defineProperty(_keyM$addEdge, keys.KEY_DOWN, bottomButton), _defineProperty(_keyM$addEdge, keys.ENTER, function (btn) {
    return btn.onClick();
  }), _keyM$addEdge));
  i++;
};

for (var cl in levels) {
  _loop(cl);
}

var render = function render(e, c) {
  c.clearRect(0, 0, e.width, e.height);

  var bgimg = e.state.imageLoader.images.floor2;
  var tileSize = 512;
  var x = Math.ceil(e.width / tileSize) + 1;
  var y = Math.ceil(e.height / tileSize) + 1;
  for (var _i = 0; _i < x; _i++) {
    for (var j = 0; j < y; j++) {
      c.drawImage(bgimg, _i * tileSize, j * tileSize, tileSize, tileSize);
    }
  }

  levelSelectContainer.render(c, e);

  c.fillStyle = '#f00';
  c.fillRect(e.mouse.x - 1, e.mouse.y - 1, 3, 3);
};

var update = function update(e) {
  levelSelectContainer.handleUpdate(e);
  keyM.handleUpdate(e);
};

var keyUp = function keyUp(e, key, evt) {
  keyM.handleKey(e, key, evt);
  if (!keyM.selected) {
    keyM.select(keyM.children[0]);
  }
};

levelSelect.render = render;
levelSelect.update = update;
levelSelect.onClick = function (e) {
  return levelSelectContainer.handleClick(e);
};
levelSelect.keyUp = keyUp;
exports.default = levelSelect;

/***/ }),
/* 393 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _scene = __webpack_require__(340);

var _math = __webpack_require__(46);

var _UI = __webpack_require__(341);

var _keys = __webpack_require__(130);

var keys = _interopRequireWildcard(_keys);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var pause = new _scene.Scene();

var centerButton = function centerButton(margins) {
  return function (e) {
    this.position.x = e.width * margins;
    this.dimensions = (0, _math.rectToPolygon)(0, 0, e.width * (1 - margins * 2), this.dimensions.verticies[2].y);
  };
};

var pauseContainer = new _UI.Container({
  dimensions: (0, _math.rectToPolygon)(0, 0, 900, 500),
  position: (0, _math.pt)(0, 0)
});

var pauseButton = new _UI.Button({
  position: (0, _math.pt)(40, 250),
  text: 'Resume',
  update: centerButton(0.25),
  fontSize: 50,
  onClick: function onClick(_) {
    return setTimeout(function (_) {
      return pause.goto('game', true);
    }, 20);
  },
  dimensions: (0, _math.rectToPolygon)(0, 0, 500, 150)
});

var settingsButton = new _UI.Button({
  position: (0, _math.pt)(40, 450),
  text: 'Main Menu',
  update: centerButton(0.25),
  onClick: function onClick(_) {
    return setTimeout(function (_) {
      return pause.goto('start');
    }, 200);
  },
  fontSize: 50,
  dimensions: (0, _math.rectToPolygon)(0, 0, 500, 150)
});

var keyM = new _UI.KeyBoardButtonManager({});

pause.onEnter = function (_) {
  var _keyM$addEdge, _keyM$addEdge2;

  pauseContainer.children = [];
  keyM.children = [];
  keyM.selected = null;

  keyM.addEdge(pauseButton, (_keyM$addEdge = {}, _defineProperty(_keyM$addEdge, keys.KEY_UP, settingsButton), _defineProperty(_keyM$addEdge, keys.KEY_DOWN, settingsButton), _defineProperty(_keyM$addEdge, keys.ENTER, function (btn) {
    return btn.onClick();
  }), _keyM$addEdge));

  keyM.addEdge(settingsButton, (_keyM$addEdge2 = {}, _defineProperty(_keyM$addEdge2, keys.KEY_UP, pauseButton), _defineProperty(_keyM$addEdge2, keys.KEY_DOWN, pauseButton), _defineProperty(_keyM$addEdge2, keys.ENTER, function (btn) {
    return btn.onClick();
  }), _keyM$addEdge2));

  // keyM.select(pauseButton)

  pauseContainer.addChildren(pauseButton, settingsButton);
};

var render = function render(e, c) {
  c.clearRect(0, 0, e.width, e.height);

  var bgimg = e.state.imageLoader.images.floor2;
  var tileSize = 512;
  var x = Math.ceil(e.width / tileSize) + 1;
  var y = Math.ceil(e.height / tileSize) + 1;
  for (var i = 0; i < x; i++) {
    for (var j = 0; j < y; j++) {
      c.drawImage(bgimg, i * tileSize, j * tileSize, tileSize, tileSize);
    }
  }

  pauseContainer.render(c, e);

  c.fillStyle = '#f00';
  c.fillRect(e.mouse.x - 1, e.mouse.y - 1, 3, 3);
};

var update = function update(e) {
  pauseContainer.handleUpdate(e);
  keyM.handleUpdate(e);
};

var keyUp = function keyUp(e, key, evt) {
  keyM.handleKey(e, key, evt);
  if (!keyM.selected) {
    keyM.select(keyM.children[0]);
  }
};

pause.render = render;
pause.update = update;
pause.onClick = function (e) {
  return pauseContainer.handleClick(e);
};
pause.keyUp = keyUp;
exports.default = pause;

/***/ })
/******/ ]);
//# sourceMappingURL=minegame.js.map